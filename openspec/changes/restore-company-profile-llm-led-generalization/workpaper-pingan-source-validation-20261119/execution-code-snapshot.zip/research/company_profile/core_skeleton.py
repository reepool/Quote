"""Form the all-industry three-dimension skeleton from existing core owners.

This module does not add ChapterTask values or manufacturing-only required
fields. Quantity tasks stay enhancements. Material inputs activate only when
the source names a production or operating input.
"""

from __future__ import annotations

import re
from collections.abc import Mapping, Sequence
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict

from .contracts import CompanyProfileTaskResult
from .core_assessment_projection import (
    COMMON_CORE_MAPPING_VERSION,
    CompanyProfileCoreAssessment,
    project_core_assessment,
)
from .core_evidence_selection import (
    CORE_FINANCIAL_HEADINGS,
    CoreEvidenceSelection,
    ReportPageText,
    explicit_material_input_names,
    owned_section_heading,
    select_core_evidence,
)
from .models import (
    PRODUCTION_AUTHORIZATION,
    ChapterTask,
    ReportIdentity,
)

COMMON_CORE_CHAPTERS = (
    ChapterTask.EXTRACT_BUSINESS_OVERVIEW,
    ChapterTask.EXTRACT_SEGMENT_FINANCIALS,
    ChapterTask.EXTRACT_MATERIAL_INPUTS,
)
_QUANTITY_HEADINGS = (
    "主要产品的产销量情况",
    "主要产品产销量情况",
    "产销量情况分析表",
    "公司实物销售收入是否大于劳务收入",
)
_QUANTITY_NEGATED = re.compile(
    r"公司实物销售收入是否大于劳务收入"
    r"(?:[:：](?:否|不适用)|(?:否|不适用)|.{0,80}[√☑](?:否|不适用))"
)
_SLICE_DISABLED_CHAPTERS = (
    ChapterTask.EXTRACT_COUNTERPARTIES_AND_CONCENTRATION,
    ChapterTask.EXTRACT_BUSINESS_REGIME,
)


class _StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)


class ActivatedChapter(_StrictModel):
    chapter_task: ChapterTask
    role: Literal["common_core", "enhancement"]
    status: Literal["activated", "not_applicable", "not_activated"]
    reason: Literal[
        "common_core_overview",
        "owned_heading",
        "no_owned_heading",
        "explicit_negation",
        "not_enabled_in_this_slice",
    ]


class CoreSkeletonResult(_StrictModel):
    mapping_version: Literal["company_profile_common_core_mapping.v1"] = (
        COMMON_CORE_MAPPING_VERSION
    )
    production_authorization: Literal["not_authorized"] = PRODUCTION_AUTHORIZATION
    report: ReportIdentity
    evidence: CoreEvidenceSelection
    assessment: CompanyProfileCoreAssessment
    activated_chapters: tuple[ActivatedChapter, ...]


def form_core_skeleton(
    *,
    report: ReportIdentity,
    pages: Sequence[ReportPageText | Mapping[str, Any]],
    task_results: Sequence[CompanyProfileTaskResult],
) -> CoreSkeletonResult:
    """Select common-core Evidence, assess the three dimensions, and name tasks."""

    accepted = tuple(
        record
        for result in task_results
        for record in result.accepted_records()
    )
    evidence = select_core_evidence(
        report=report,
        pages=pages,
        accepted_records=accepted,
    )
    return CoreSkeletonResult(
        report=report,
        evidence=evidence,
        assessment=project_core_assessment(
            report=report,
            task_results=task_results,
        ),
        activated_chapters=select_activated_chapters(pages),
    )


def select_activated_chapters(
    pages: Sequence[ReportPageText | Mapping[str, Any]],
    *,
    source_delivery_repair: bool = False,
) -> tuple[ActivatedChapter, ...]:
    """Return which existing chapter tasks the source actually supports."""

    texts = tuple(
        item.text if isinstance(item, ReportPageText) else str(item.get("text") or "")
        for item in pages
    )
    has_segment = any(
        owned_section_heading(text, CORE_FINANCIAL_HEADINGS) for text in texts
    )
    has_material = any(
        explicit_material_input_names(
            text, source_delivery_repair=source_delivery_repair
        )
        for text in texts
    )
    has_quantity, quantity_negated = _quantity_heading_state(texts)
    activated: list[ActivatedChapter] = []
    for chapter in ChapterTask:
        activated.append(
            _activate_chapter(
                chapter,
                has_segment=has_segment,
                has_material=has_material,
                has_quantity=has_quantity,
                quantity_negated=quantity_negated,
            )
        )
    return tuple(activated)


def _quantity_heading_state(texts: Sequence[str]) -> tuple[bool, bool]:
    """Prefer a live owned heading over a negation found on another page."""

    has_live_heading = False
    saw_negation = False
    for text in texts:
        owned = owned_section_heading(text, _QUANTITY_HEADINGS)
        negated = _QUANTITY_NEGATED.search(re.sub(r"\s+", "", text)) is not None
        if owned and not negated:
            has_live_heading = True
        elif negated:
            saw_negation = True
    return has_live_heading, saw_negation and not has_live_heading


def _activate_chapter(
    chapter: ChapterTask,
    *,
    has_segment: bool,
    has_material: bool,
    has_quantity: bool,
    quantity_negated: bool,
) -> ActivatedChapter:
    if chapter in _SLICE_DISABLED_CHAPTERS:
        return ActivatedChapter(
            chapter_task=chapter,
            role="enhancement",
            status="not_activated",
            reason="not_enabled_in_this_slice",
        )
    if chapter is ChapterTask.EXTRACT_BUSINESS_OVERVIEW:
        return ActivatedChapter(
            chapter_task=chapter,
            role="common_core",
            status="activated",
            reason="common_core_overview",
        )
    if chapter is ChapterTask.EXTRACT_SEGMENT_FINANCIALS:
        return ActivatedChapter(
            chapter_task=chapter,
            role="common_core",
            status="activated" if has_segment else "not_applicable",
            reason="owned_heading" if has_segment else "no_owned_heading",
        )
    if chapter is ChapterTask.EXTRACT_MATERIAL_INPUTS:
        return ActivatedChapter(
            chapter_task=chapter,
            role="common_core",
            status="activated" if has_material else "not_applicable",
            reason="owned_heading" if has_material else "no_owned_heading",
        )
    if quantity_negated:
        status: Literal["activated", "not_applicable"] = "not_applicable"
        reason: Literal["owned_heading", "no_owned_heading", "explicit_negation"] = (
            "explicit_negation"
        )
    elif has_quantity:
        status = "activated"
        reason = "owned_heading"
    else:
        status = "not_applicable"
        reason = "no_owned_heading"
    return ActivatedChapter(
        chapter_task=chapter,
        role="enhancement",
        status=status,
        reason=reason,
    )
