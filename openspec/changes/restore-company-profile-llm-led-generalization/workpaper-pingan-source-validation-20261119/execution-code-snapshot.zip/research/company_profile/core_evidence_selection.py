"""Automatic common-core Evidence selection.

This owner locates overview and segment text for the three core dimensions. It
reuses accepted structured facts and does not require a frozen per-company page
plan or an LLM call.
"""

from __future__ import annotations

import hashlib
import re
from collections.abc import Mapping, Sequence
from decimal import Decimal
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field

from .contracts import PreparedEvidence
from .core_assessment_projection import (
    _REVENUE_BLOCK_PATTERN,
    BUSINESS_DESCRIPTION_CONFLICT,
    COMMON_CORE_MAPPING_VERSION,
    _overview_states_revenue,
    core_record_is_reusable,
    overview_dimension_hits,
)
from .models import (
    PRODUCTION_AUTHORIZATION,
    Activity,
    ActivityAction,
    AssertionClass,
    BusinessOverview,
    ChapterTask,
    Evidence,
    LogicalSlot,
    Measurement,
    MetricType,
    PeriodType,
    Relationship,
    RelationshipType,
    ReportIdentity,
    RowClass,
    Segment,
    SemanticRecord,
    SourceNativeValue,
    SubjectBasis,
    SubjectScope,
    TextAnchor,
)

CORE_EVIDENCE_SCHEMA_VERSION = "company_profile_common_core_evidence.v1"
CORE_SOURCE_FIELD_IDS = (
    "business_overview_source",
    "explicit_activity",
    "segment_dimension",
    "operating_revenue",
    "material_input",
)
_OVERVIEW_HEADINGS = (
    "报告期内公司从事的业务情况",
    "报告期内公司从事的主要业务",
    "公司从事的主要业务",
    "主营业务分析",
    "主要产品及服务",
    "主要产品",
    "经营模式",
    "主营业务",
    "公司主要业务情况",
    "公司金融业务",
    "主要业务",
)
_OVERVIEW_FIELD_LABELS = ("经营范围",)
_SEGMENT_HEADINGS = (
    "占公司营业收入或营业利润10%以上",
    "主营业务分行业情况",
    "主营业务/产品分行业情况",
    "主营业务主要地区情况",
    "主营业务分产品情况",
    "主营业务分地区情况",
    "主营业务分销售模式情况",
    "收入和成本分析",
    "主营业务分行业",
    "主营业务分产品",
    "分部报告",
    "分部信息",
    "分行业",
    "分产品",
)
_INCOME_ANALYSIS_HEADINGS = (
    "利润表分析",
    "营业收入构成",
)
CORE_SEGMENT_HEADINGS = _SEGMENT_HEADINGS
CORE_FINANCIAL_HEADINGS = _SEGMENT_HEADINGS + _INCOME_ANALYSIS_HEADINGS
_ALL_HEADINGS = (
    _OVERVIEW_HEADINGS
    + _OVERVIEW_FIELD_LABELS
    + _SEGMENT_HEADINGS
    + _INCOME_ANALYSIS_HEADINGS
)
_HEADING_PREFIX = re.compile(
    r"^(?:第[一二三四五六七八九十百]+[节章]"
    r"|[一二三四五六七八九十]+、"
    r"|[（(][一二三四五六七八九十\d]+[)）]"
    r"|[0-9]+(?:[.、．][0-9]+)*[.、．]?)"
)
_SECTION_BOUNDARY = re.compile(
    r"(?:^|\n|(?<=[。；;]))\s*(?:第[一二三四五六七八九十百]+[节章]"
    r"|[二三四五六七八九十]+、)"
)
_CONTINUATION_TAIL = re.compile(r"(如下[:：]?|见表|详见|续[见表]|：$)$")
_OVERVIEW_SUBSTANCE = re.compile(
    r"(?:公司|本公司).{0,40}(?:主营|主要从事|经营|生产|销售|提供|研发)|"
    r"作为[^。]{2,60}核心提供商|"
    r"取得货款|收入来[源于自]|向客户收取|主要产品为"
)
_COMPANY_BUSINESS_SENTENCE = re.compile(
    r"(?<![\u4e00-\u9fff])(?:本公司|公司)(?:业务覆盖|专注于)[^。；;]{2,160}"
)
_STEEL_BUSINESS_SENTENCE = re.compile(
    r"(?<![\u4e00-\u9fff])公司是[^。]{8,260}主要产品有[^。]{2,80}"
)
_MAIN_BUSINESS_SENTENCE = re.compile(
    r"(?<![\u4e00-\u9fff])(?:本公司|公司)的主要业务是[^。]{8,500}"
)
_INTEGRATED_BUSINESS_SENTENCE = re.compile(
    r"(?:中国石化是|公司是)[^。]{8,900}主要从事[^。]{8,900}"
)
_TOLL_SERVICE_SENTENCE = re.compile(
    r"公司的主营业务为[^。]{4,120}。[^。]{0,120}?通行服务[^。]{2,160}"
)
_MAIN_OPERATION_SENTENCE = re.compile(
    # The operating-model sentence may sit behind a short development
    # narrative, so the bridge to 经营模式 allows bounded intermediate text.
    r"主要经营[^。]{8,220}(?:。[\s\S]{0,400}?经营模式[^。]{2,220})?"
)
_OPERATING_MODEL_SENTENCE = re.compile(
    r"(?<![\u4e00-\u9fff])(?:本公司|公司)的?经营模式主要为[:：][^。]{2,300}"
)
_COMPANY_AS_NARRATIVE = re.compile(
    r"[^。\n]{2,40}作为[^。]{2,80}(?:上市公司|工业企业)"
    r"[^。]{2,300}研发制造[^。]{4,300}"
    r"(?:。[^。\n]{2,200}涉足[^。]{2,200})?"
)
_PROVIDER_NARRATIVE = re.compile(
    r"作为[^。；;\n]{2,60}核心提供商[，,]\s*(?:本公司|公司)[^。；;]{8,300}"
)
_CURRENT_BUSINESS_NARRATIVE = re.compile(
    r"(?<![\u4e00-\u9fff])(?:本公司|公司)坚持以[^。]{2,150}为核心[^。]*。\s*"
    r"(?:本公司|公司)持续深耕[^。]{2,1000}"
)
_CORE_ANSWER_SUBSTANCE = re.compile(
    _COMPANY_BUSINESS_SENTENCE.pattern + "|" + _STEEL_BUSINESS_SENTENCE.pattern
)
_SOURCE_DELIVERY_SUBSTANCE = re.compile(
    _CORE_ANSWER_SUBSTANCE.pattern
    + "|"
    + _MAIN_BUSINESS_SENTENCE.pattern
    + "|"
    + _INTEGRATED_BUSINESS_SENTENCE.pattern
    + "|"
    + _OPERATING_MODEL_SENTENCE.pattern
    + "|"
    + _PROVIDER_NARRATIVE.pattern
    + "|"
    + _CURRENT_BUSINESS_NARRATIVE.pattern
    + r"|本集团以[^。]+为两大核心主业|公司建成[^。]+四大产业板块"
)
_SPEC_OBJECT = re.compile(r"^(?:厚度|宽度|长度)")
_REVENUE_PARENT_LABELS = frozenset({"航空性收入", "非航空性收入"})
_AUDIT_PROCEDURE = re.compile(r"函证|截止测试|选取样本|关键审计事项|审计中的应对")
_RESUME_CLAUSE = re.compile(r"历任|曾任")
_PSEUDO_SALES = re.compile(r"销售(?:模式|区域|部)")
_REVENUE_OBJECT = re.compile(
    r"([\u4e00-\u9fffA-Za-z0-9（）()]{2,40}?)\s*"
    r"(?:营业收入|主营业务收入)"
)
_ACTIVITY_OBJECTS = re.compile(
    r"主要从事(.+?)(?:的研发|的生产|的制造|的加工|的销售|服务)"
)
_DISPLAY_QUOTE_LIMIT = 180
_MAX_SECTION_PAGES = 8


class _StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)


class ReportPageText(_StrictModel):
    page: int = Field(ge=1)
    text: str = ""
    readable: bool = True
    layout_text: str = ""


class CoreEvidenceSpan(_StrictModel):
    page: int = Field(ge=1)
    continuation_pages: tuple[int, ...] = ()
    section_title: str = Field(min_length=1)
    excerpt: str = Field(min_length=1)
    bounded_quote: str = Field(min_length=1)
    chapter_task: Literal[
        "extract_business_overview",
        "extract_segment_financials",
        "extract_material_inputs",
    ]
    field_ids: tuple[str, ...]
    dimension_ids: tuple[str, ...] = ()
    context_complete: bool = True


class ReusedStructuredFact(_StrictModel):
    record_id: str = Field(min_length=1)
    field_id: str = Field(min_length=1)
    requires_llm: Literal[False] = False


class CoreEvidenceGap(_StrictModel):
    code: Literal["page_unreadable", "chapter_missing", "extraction_failed"]
    chapter_task: Literal[
        "extract_business_overview",
        "extract_segment_financials",
        "extract_material_inputs",
    ]
    page: int | None = None
    message: str = Field(min_length=1)


class CoreEvidenceSelection(_StrictModel):
    schema_version: Literal["company_profile_common_core_evidence.v1"] = (
        CORE_EVIDENCE_SCHEMA_VERSION
    )
    mapping_version: Literal["company_profile_common_core_mapping.v1"] = (
        COMMON_CORE_MAPPING_VERSION
    )
    production_authorization: Literal["not_authorized"] = PRODUCTION_AUTHORIZATION
    report: ReportIdentity
    spans: tuple[CoreEvidenceSpan, ...]
    reused_facts: tuple[ReusedStructuredFact, ...]
    unresolved_field_ids: tuple[str, ...]
    gaps: tuple[CoreEvidenceGap, ...]
    prepared_evidence: tuple[PreparedEvidence, ...]


def core_evidence_schema_manifest() -> dict[str, Any]:
    schema = CoreEvidenceSelection.model_json_schema()
    return {
        "schema_version": CORE_EVIDENCE_SCHEMA_VERSION,
        "mapping_version": COMMON_CORE_MAPPING_VERSION,
        "chapter_tasks": (
            "extract_business_overview",
            "extract_segment_financials",
            "extract_material_inputs",
        ),
        "source_field_ids": CORE_SOURCE_FIELD_IDS,
        "title": schema.get("title", "CoreEvidenceSelection"),
        "schema": schema,
    }


def select_core_evidence(
    *,
    report: ReportIdentity,
    pages: Sequence[ReportPageText | Mapping[str, Any]],
    accepted_records: Sequence[SemanticRecord] = (),
    repair_revenue_sentence: bool = False,
    named_role_repair: bool = False,
    service_operating_energy: bool = False,
    core_answer_repair: bool = False,
    source_delivery_repair: bool = False,
) -> CoreEvidenceSelection:
    """Select bounded core Evidence without a frozen per-company page plan."""

    for record in accepted_records:
        if record.report != report:
            raise ValueError("core evidence cannot reuse records from another report")
    normalized = tuple(_normalize_page(item) for item in pages)
    spans: list[CoreEvidenceSpan] = []
    gaps: list[CoreEvidenceGap] = []

    overview = _select_owned_span(
        normalized,
        headings=(
            (("公司简介",) + _OVERVIEW_HEADINGS)
            if source_delivery_repair
            else _OVERVIEW_HEADINGS
        ),
        chapter_task=ChapterTask.EXTRACT_BUSINESS_OVERVIEW,
        field_ids=("business_overview_source", "explicit_activity"),
        require_substance=True,
        substance_extra=(
            _SOURCE_DELIVERY_SUBSTANCE
            if source_delivery_repair
            else (
                _CORE_ANSWER_SUBSTANCE
                if core_answer_repair
                else _COMPANY_BUSINESS_SENTENCE
                if named_role_repair
                else None
            )
        ),
    )
    if overview.span is None:
        labeled = _select_owned_span(
            normalized,
            headings=(),
            field_labels=_OVERVIEW_FIELD_LABELS,
            chapter_task=ChapterTask.EXTRACT_BUSINESS_OVERVIEW,
            field_ids=("business_overview_source", "explicit_activity"),
            require_substance=False,
        )
        if labeled.span is not None:
            overview = labeled
        else:
            gaps.extend(labeled.gaps)
    if overview.span is not None:
        spans.append(overview.span)
    gaps.extend(overview.gaps)

    segment = _select_owned_span(
        normalized,
        headings=_SEGMENT_HEADINGS,
        chapter_task=ChapterTask.EXTRACT_SEGMENT_FINANCIALS,
        field_ids=("segment_dimension", "operating_revenue"),
        require_substance=False,
    )
    if segment.span is not None:
        spans.append(segment.span)
    gaps.extend(segment.gaps)

    income = _select_owned_span(
        normalized,
        headings=_INCOME_ANALYSIS_HEADINGS,
        chapter_task=ChapterTask.EXTRACT_SEGMENT_FINANCIALS,
        field_ids=("segment_dimension", "operating_revenue"),
        require_substance=False,
    )
    if income.span is not None:
        spans.append(income.span)
    gaps.extend(income.gaps)

    if source_delivery_repair:
        relation_continuation = False
        for page in normalized:
            continuation = (
                relation_continuation
                and re.search(r"(?m)^\s*[^\n]+公司\s*(?:\n|\d)", page.text) is not None
            )
            relation_continuation = (
                "被投资单位" in page.text and "合营企业" in page.text
            )
            if continuation:
                text = page.layout_text or page.text
                spans.append(
                    CoreEvidenceSpan(
                        page=page.page,
                        section_title="原始关系说明",
                        excerpt=text,
                        bounded_quote=text,
                        chapter_task=ChapterTask.EXTRACT_BUSINESS_OVERVIEW.value,
                        field_ids=(),
                        context_complete=True,
                    )
                )
            if (
                (
                    "与本企业关系" in re.sub(r"\s+", "", page.text)
                    and "合营或联营企业名称" in re.sub(r"\s+", "", page.text)
                )
                or ("被投资单位" in page.text and "合营企业" in page.text)
                or (
                    "本期增减变动" in page.text
                    and "投资收益" in page.text
                    and "公司" in page.text
                )
            ):
                text = page.layout_text or page.text
                spans.append(
                    CoreEvidenceSpan(
                        page=page.page,
                        section_title="原始关系说明",
                        excerpt=text,
                        bounded_quote=text,
                        chapter_task=ChapterTask.EXTRACT_BUSINESS_OVERVIEW.value,
                        field_ids=(),
                        context_complete=True,
                    )
                )
        spans.extend(_native_income_spans(normalized))
        spans.extend(_current_native_extra_income_spans(normalized))
        spans.extend(_accounting_supplement_spans(normalized, report.report_period[:4]))
        supplemental = _supplemental_income_spans(normalized)
        spans.extend(supplemental)
        spans.extend(
            span.model_copy(
                update={
                    "section_title": "当期产品及服务披露",
                    "chapter_task": ChapterTask.EXTRACT_BUSINESS_OVERVIEW.value,
                    "field_ids": ("business_overview_source",),
                }
            )
            for span in supplemental
            if span.section_title == "关联服务及出租收入"
        )

    if source_delivery_repair and segment.span is not None:
        income_source = _company_income_source(segment.span.excerpt)
        if income_source:
            spans.append(
                CoreEvidenceSpan(
                    page=segment.span.page,
                    section_title="主营业务收入说明",
                    excerpt=income_source,
                    bounded_quote=segment.span.excerpt,
                    continuation_pages=segment.span.continuation_pages,
                    chapter_task=ChapterTask.EXTRACT_BUSINESS_OVERVIEW.value,
                    field_ids=("business_overview_source", "explicit_activity"),
                    context_complete=True,
                )
            )

    if source_delivery_repair:
        for page in normalized:
            source = _company_sales_mechanism_source(page.text) if page.readable else ""
            if source:
                spans.append(
                    CoreEvidenceSpan(
                        page=page.page,
                        section_title="销售客户及市场化交易",
                        excerpt=source,
                        bounded_quote=source,
                        chapter_task=ChapterTask.EXTRACT_BUSINESS_OVERVIEW.value,
                        field_ids=("business_overview_source",),
                        context_complete=True,
                    )
                )

    if source_delivery_repair:
        for page in normalized:
            if not page.readable:
                continue
            source_text = page.text
            source_continuations = set()
            if "公司作为出租人" in source_text:
                following = next(
                    (p for p in normalized if p.page == page.page + 1 and p.readable),
                    None,
                )
                if following and "售后租回" in following.text:
                    source_text += (
                        "\n"
                        + re.split(
                            r"[（(]3[)）]\s*售后租回", following.text, maxsplit=1
                        )[0]
                    )
                    source_continuations.add(following.page)
            if re.search(
                r"\d+[、．]\s*收入(?:确认)?\s*(?:\n|$)", source_text
            ) or re.search(
                r"本(?:公司|集团)收入确认(?:的)?具体方法如下",
                re.sub(r"\s+", "", source_text),
            ):
                cursor = page.page + 1
                while cursor <= page.page + _MAX_SECTION_PAGES:
                    following = next(
                        (p for p in normalized if p.page == cursor and p.readable), None
                    )
                    if following is None:
                        break
                    source_text += "\n" + following.text
                    source_continuations.add(following.page)
                    cursor += 1
                    if re.search(
                        r"\n\s*\d+[、．](?!\s*收入确认)\s*[^\n]+", following.text
                    ):
                        break
            nxt = next(
                (p for p in normalized if p.page == page.page + 1 and p.readable), None
            )
            if (
                nxt
                and re.search(r"[（(]三[)）]\s*智慧能源", source_text)
                and re.search(r"[（(]2[)）]\.\s*产销量情况", nxt.text)
            ):
                source_continuations.add(nxt.page)
                source_text += (
                    "\n"
                    + re.split(r"[（(]2[)）]\.\s*产销量情况", nxt.text, maxsplit=1)[0]
                )
            if nxt and (
                "主要经营模式" in source_text or "公司以化肥产业为基础" in source_text
            ):
                cursor = page.page + 1
                while not re.search(
                    "报告期内调整经营模式|二、报告期内公司所处行业",
                    re.sub(r"\s+", "", source_text),
                ):
                    following = next(
                        (p for p in normalized if p.page == cursor and p.readable), None
                    )
                    if following is None or cursor > page.page + _MAX_SECTION_PAGES:
                        break
                    source_text += (
                        "\n"
                        + re.split(
                            r"报告期内调整经营模式|二、\s*报告期内公司所处行业",
                            following.text,
                            maxsplit=1,
                        )[0]
                    )
                    source_continuations.add(cursor)
                    cursor += 1
                    if re.search(
                        "报告期内调整经营模式|二、报告期内公司所处行业",
                        re.sub(r"\s+", "", following.text),
                    ):
                        break
            if (
                nxt
                and "关联托管/承包情况说明" in source_text
                and "受托方由" in nxt.text
            ):
                source_continuations.add(nxt.page)
                source_text += (
                    "\n" + re.split(r"本公司委托管理", nxt.text, maxsplit=1)[0]
                )
            if nxt and "持续加大公司产品在海外注册" in re.sub(r"\s+", "", source_text):
                source_continuations.add(nxt.page)
                source_text += (
                    "\n" + re.split(r"四、报告期内核心竞争力", nxt.text, maxsplit=1)[0]
                )
            if nxt and "公司作为国内领先的集" in source_text:
                source_continuations.add(nxt.page)
                source_text += (
                    "\n"
                    + re.split(r"五、报告期内主要经营情况", nxt.text, maxsplit=1)[0]
                )
            if nxt and re.search(r"注\s*3：[^。]+成立于", source_text):
                source_continuations.add(nxt.page)
                source_text += (
                    "\n" + re.split(r"六、|注\s*4：", nxt.text, maxsplit=1)[0]
                )
            if nxt and "主要研发项目基本情况" in source_text:
                source_continuations.add(nxt.page)
                source_text += "\n" + re.split(r"[（(]3[)）]", nxt.text, maxsplit=1)[0]
            if nxt and "三、经营情况讨论与分析" in source_text:
                source_continuations.add(nxt.page)
                source_text += (
                    "\n" + re.split(r"四、报告期内核心竞争力", nxt.text, maxsplit=1)[0]
                )
            if nxt and "公司药（产）品销售情况" in source_text:
                source_continuations.add(nxt.page)
                source_text += (
                    "\n" + re.split(r"[（(]2[)）]\.销售费用", nxt.text, maxsplit=1)[0]
                )
            if nxt and re.search(
                r"(?:本集团的营业收入|本公司的营业收入|公司(?:的|营业)?收入)主要包括",
                re.sub(r"\s+", "", source_text),
            ):
                source_continuations.add(nxt.page)
                source_text += "\n" + re.split(r"\n\s*\d+、", nxt.text, maxsplit=1)[0]
            if nxt and "作为出租方的租赁分类标准和会计处理方法" in source_text:
                source_continuations.add(nxt.page)
                source_text += (
                    "\n"
                    + re.split(r"[（(](?:二|3)[)）]|售后租回", nxt.text, maxsplit=1)[0]
                )
            if nxt and "履约义务的说明" in source_text and "款到发" in source_text:
                source_continuations.add(nxt.page)
                source_text += "\n" + re.split(r"[（(]4[)）]", nxt.text, maxsplit=1)[0]
            if nxt and (
                "公司从事的业务情况" in source_text
                and "报告期内公司新增重要非主营业务" not in source_text
                or "其他资产置换" in source_text
                and "交易完成" not in source_text
                or "主要控股参股公司分析" in source_text
            ):
                source_continuations.add(nxt.page)
                source_text += "\n" + nxt.text
            if nxt and re.search(r"注\s*\d+：[^。]+成立于\s*\d{4}年", source_text):
                source_text += "\n" + re.split(r"(?m)^\s*六、", nxt.text, maxsplit=1)[0]
                source_continuations.add(nxt.page)
            if "企业集团的构成" in source_text:
                cursor = page.page + 1
                # The rows and their numbered consolidation notes form one
                # disclosure; a page boundary does not end its original actors.
                while "在子公司的持股比例不同于表决权比例" not in source_text:
                    following = next(
                        (p for p in normalized if p.page == cursor and p.readable), None
                    )
                    if following is None:
                        break
                    source_text += "\n" + following.text
                    source_continuations.add(following.page)
                    cursor += 1
                    if cursor - page.page > _MAX_SECTION_PAGES:
                        break
                if "在子公司的持股比例不同于表决权比例" in source_text:
                    source_text = re.split(
                        r"[（(]2[)）]\.?重要的非全资子公司", source_text, maxsplit=1
                    )[0]
            if "零部件产销量" in source_text and nxt:
                source_continuations.add(nxt.page)
                source_text += (
                    "\n" + re.split(r"产品销售|其他说明", nxt.text, maxsplit=1)[0]
                )
            for source in (
                *_current_product_sources(source_text),
                *_owned_business_sources(source_text),
                *_owned_operating_passages(source_text),
            ):
                passage_continuations = set(source_continuations)
                passage_context = source_text
                note = re.match(r"注\d+：([^。]+?)成立于", source)
                if note:
                    for context in normalized:
                        ownership = re.search(
                            r"截至报告日[^。]+"
                            + re.escape(note[1])
                            + r"[^。]+参股项目[^。]+未纳入合并[^。]+。",
                            re.sub(r"\s+", "", context.text),
                        )
                        if ownership:
                            original = _original_span_matching(
                                context.text, ownership.group()
                            )
                            source += "\n" + original
                            passage_context += "\n" + original
                            passage_continuations.add(context.page)
                            break
                spans.append(
                    CoreEvidenceSpan(
                        page=page.page,
                        section_title="当期产品及服务披露",
                        excerpt=source,
                        bounded_quote=passage_context,
                        continuation_pages=tuple(sorted(passage_continuations)),
                        chapter_task=ChapterTask.EXTRACT_BUSINESS_OVERVIEW.value,
                        field_ids=("business_overview_source",),
                        context_complete=True,
                    )
                )
    material = _select_material_span(
        normalized, source_delivery_repair=source_delivery_repair
    )
    if material is not None:
        spans.append(material)
    if source_delivery_repair:
        for page in normalized:
            if not page.readable or not (
                any(verb == "投入" for _, verb, _ in _native_input_bindings(page.text))
                or any(
                    b.get("header") in {"能源", "实际加工原料"}
                    and b.get("action") is None
                    for b in _explicit_current_commodity_bindings(
                        page.layout_text or page.text
                    )
                )
            ):
                continue
            # An upstream column establishes use, not an external purchase.
            # Keep the complete owned table in the existing material chapter.
            if any(
                span.page == page.page
                and span.chapter_task == ChapterTask.EXTRACT_MATERIAL_INPUTS.value
                and span.excerpt.strip() == page.text.strip()
                for span in spans
            ):
                continue
            spans.append(
                CoreEvidenceSpan(
                    page=page.page,
                    section_title="主要上游原材料",
                    excerpt=page.text,
                    bounded_quote=page.text,
                    chapter_task=ChapterTask.EXTRACT_MATERIAL_INPUTS.value,
                    field_ids=("material_input",),
                    context_complete=True,
                )
            )
    if repair_revenue_sentence:
        spans.extend(
            _repair_commodity_spans(
                normalized,
                covered=spans,
                service_operating_energy=service_operating_energy,
            )
        )

    if overview.span is None and not any(
        gap.code == "chapter_missing"
        and gap.chapter_task == ChapterTask.EXTRACT_BUSINESS_OVERVIEW.value
        for gap in gaps
    ):
        gaps.append(
            CoreEvidenceGap(
                code="chapter_missing",
                chapter_task="extract_business_overview",
                message="no owned business-overview section was located",
            )
        )

    reused_facts = tuple(
        ReusedStructuredFact(record_id=record.record_id, field_id=record.field_id)
        for record in accepted_records
        if core_record_is_reusable(record)
        and any(_record_matches_span(record, report, span) for span in spans)
    )
    reused_records = [
        record
        for record in accepted_records
        if any(item.record_id == record.record_id for item in reused_facts)
    ]
    unresolved: list[str] = []
    seen_fields: set[str] = set()
    for span in spans:
        for field_id in span.field_ids:
            if field_id in seen_fields:
                continue
            if not _field_covered_for_span(field_id, span, report, reused_records):
                unresolved.append(field_id)
            seen_fields.add(field_id)

    prepared = _prepared_evidence_for_spans(report, spans)
    return CoreEvidenceSelection(
        report=report,
        spans=tuple(spans),
        reused_facts=reused_facts,
        unresolved_field_ids=tuple(unresolved),
        gaps=tuple(gaps),
        prepared_evidence=tuple(prepared),
    )


class _OwnedSelection:
    def __init__(
        self,
        span: CoreEvidenceSpan | None,
        gaps: list[CoreEvidenceGap],
    ) -> None:
        self.span = span
        self.gaps = gaps


def _normalize_page(page: ReportPageText | Mapping[str, Any]) -> ReportPageText:
    if isinstance(page, ReportPageText):
        return page
    return ReportPageText(
        page=int(page["page"]),
        text=str(page.get("text") or ""),
        readable=bool(page.get("readable", True)),
        layout_text=str(page.get("layout_text") or ""),
    )


def _select_owned_span(
    pages: Sequence[ReportPageText],
    *,
    headings: tuple[str, ...],
    chapter_task: ChapterTask,
    field_ids: tuple[str, ...],
    require_substance: bool,
    field_labels: tuple[str, ...] = (),
    substance_extra: re.Pattern[str] | None = None,
) -> _OwnedSelection:
    by_page = {item.page: item for item in pages}
    gaps: list[CoreEvidenceGap] = []
    for page in pages:
        owned_headings = _iter_owned_headings(
            page.text, headings, field_labels=field_labels
        )
        if not owned_headings:
            continue
        for heading, _line_start, line_end in owned_headings:
            selected = _selection_for_owned_heading(
                page,
                by_page=by_page,
                heading=heading,
                line_end=line_end,
                chapter_task=chapter_task,
                field_ids=field_ids,
                require_substance=require_substance,
                field_labels=field_labels,
                gaps=gaps,
                substance_extra=substance_extra,
            )
            if selected is _SKIP_OWNED_HEADING:
                continue
            return selected
    return _OwnedSelection(None, gaps)


_SKIP_OWNED_HEADING = object()


def _selection_for_owned_heading(
    page: ReportPageText,
    *,
    by_page: Mapping[int, ReportPageText],
    heading: str,
    line_end: int,
    chapter_task: ChapterTask,
    field_ids: tuple[str, ...],
    require_substance: bool,
    field_labels: tuple[str, ...],
    gaps: list[CoreEvidenceGap],
    substance_extra: re.Pattern[str] | None = None,
) -> _OwnedSelection | object:
    if not page.readable:
        gaps.append(
            CoreEvidenceGap(
                code="page_unreadable",
                chapter_task=chapter_task.value,
                page=page.page,
                message=f"owned section page is unreadable: {page.page}",
            )
        )
        return _OwnedSelection(None, gaps)
    if heading in field_labels:
        excerpt, continuations, closed, gap = _collect_field_label(
            page,
            heading=heading,
            line_end=line_end,
        )
    else:
        preview = f"{heading}\n{_cut_at_boundary(page.text[line_end:]).text}".strip()
        if _usable_excerpt(
            preview,
            heading,
            require_substance,
            substance_extra=substance_extra,
        ) and (
            _excerpt_states_owned_overview(preview)
            or (
                substance_extra is not None
                and (
                    substance_extra.search(preview) is not None
                    or substance_extra.search(_join_pdf_soft_breaks(preview))
                    is not None
                )
            )
        ):
            # An already usable first page may still own a product matrix or
            # operating model on the following page. Follow that section's
            # real boundary before choosing its delivered sentences.
            if (
                substance_extra is _SOURCE_DELIVERY_SUBSTANCE
                and not _cut_at_boundary(page.text[line_end:]).closed
                and page.page + 1 in by_page
            ):
                excerpt, continuations, closed, gap = _collect_section(
                    page,
                    heading=heading,
                    line_end=line_end,
                    by_page=by_page,
                    chapter_task=chapter_task,
                )
            else:
                excerpt, continuations, closed, gap = preview, [], True, None
        else:
            excerpt, continuations, closed, gap = _collect_section(
                page,
                heading=heading,
                line_end=line_end,
                by_page=by_page,
                chapter_task=chapter_task,
            )
    if chapter_task is ChapterTask.EXTRACT_SEGMENT_FINANCIALS:
        declared = _unit_declaration(page.text)
        if declared and declared not in excerpt:
            excerpt = f"{declared}\n{excerpt}"
    if heading in _INCOME_ANALYSIS_HEADINGS:
        excerpt = _clip_income_analysis_excerpt(excerpt)
        if not _income_analysis_excerpt_ready(excerpt):
            return _SKIP_OWNED_HEADING
        closed = True
        gap = None
    if heading in _MDA_REVENUE_HEADINGS:
        table_lines = excerpt.splitlines()
        table_start = next(
            (
                i
                for i, line in enumerate(table_lines)
                if _dimension_from_heading(line) is not None
            ),
            len(table_lines),
        )
        table_tail = any(
            _is_revenue_table_stop(line) for line in table_lines[table_start + 1 :]
        )
        excerpt = _clip_before_later_segment_template(excerpt)
        if not _formal_segment_table_ready(excerpt):
            return _SKIP_OWNED_HEADING
        # A truncated continuation must not be made complete just because an
        # earlier row was parseable. A real table tail can close the section.
        normalized = _join_segment_label_amounts(
            _join_rmb_column_header(_join_pdf_soft_breaks(excerpt))
        )
        last_block = 0
        for index, line in enumerate(normalized.splitlines()):
            if _dimension_from_heading(line) is not None:
                last_block = index + 1
        final_block_has_rows = any(
            _parse_segment_row(line) is not None
            for line in normalized.splitlines()[last_block:]
        )
        closed = closed or table_tail or final_block_has_rows
        if gap is None or closed:
            gap = None
    elif heading in {"分部报告", "分部信息"} and _formal_segment_table_ready(excerpt):
        closed = True
        gap = None
    usable = _usable_excerpt(
        excerpt,
        heading,
        require_substance,
        substance_extra=substance_extra,
    )
    if usable and _excerpt_states_owned_overview(excerpt):
        closed = True
        gap = None
    if gap is not None and not usable:
        gaps.append(gap)
        return _OwnedSelection(None, gaps)
    if gap is not None:
        gaps.append(gap)
    if not excerpt.strip() or excerpt.strip() == heading:
        gaps.append(
            CoreEvidenceGap(
                code="extraction_failed",
                chapter_task=chapter_task.value,
                page=page.page,
                message="owned heading has no usable context",
            )
        )
        return _OwnedSelection(None, gaps)
    if not usable:
        return _SKIP_OWNED_HEADING
    dimensions = overview_dimension_hits(excerpt)
    if chapter_task is ChapterTask.EXTRACT_SEGMENT_FINANCIALS:
        dimensions = ("products_services", "revenue_model")
    return _OwnedSelection(
        CoreEvidenceSpan(
            page=page.page,
            continuation_pages=tuple(continuations),
            section_title=heading,
            excerpt=excerpt,
            bounded_quote=_display_quote(excerpt, heading),
            chapter_task=chapter_task.value,
            field_ids=field_ids,
            dimension_ids=dimensions,
            context_complete=closed,
        ),
        gaps,
    )


def owned_section_heading(
    text: str,
    headings: Sequence[str],
) -> str | None:
    """Return the first title-line heading owned by this page, if any."""

    owned = _owned_heading(text, tuple(headings))
    return None if owned is None else owned[0]


def _owned_heading(
    text: str,
    headings: tuple[str, ...],
    *,
    field_labels: tuple[str, ...] = (),
) -> tuple[str, int, int] | None:
    found = _iter_owned_headings(text, headings, field_labels=field_labels)
    return found[0] if found else None


def _iter_owned_headings(
    text: str,
    headings: tuple[str, ...],
    *,
    field_labels: tuple[str, ...] = (),
) -> list[tuple[str, int, int]]:
    if _is_toc_page(text):
        return []
    found: list[tuple[str, int, int]] = []
    offset = 0
    for line in text.splitlines(keepends=True):
        heading = _heading_if_title_line(line, headings)
        if heading is not None:
            found.append((heading, offset, offset + len(line)))
        else:
            heading = _heading_if_field_label(line, field_labels)
            if heading is not None:
                found.append(
                    (heading, offset, offset + _heading_end_in_line(line, heading))
                )
        offset += len(line)
    return found


def _heading_if_title_line(line: str, headings: tuple[str, ...]) -> str | None:
    stripped = line.strip()
    if not stripped or _is_toc_line(stripped, headings):
        return None
    compact = re.sub(r"\s+", "", stripped)
    compact = _HEADING_PREFIX.sub("", compact, count=1)
    for heading in sorted(headings, key=len, reverse=True):
        if compact == heading:
            return heading
        if compact.startswith(heading):
            rest = compact[len(heading) :]
            if re.fullmatch(r"[:：.。]*", rest or ""):
                return heading
            return None
    return None


_FIELD_LABEL_VALUE = re.compile(r"[\u4e00-\u9fffA-Za-z]{2,}")


def _heading_if_field_label(line: str, headings: tuple[str, ...]) -> str | None:
    stripped = line.strip()
    if not stripped or not headings or _is_toc_line(stripped, headings):
        return None
    compact = _HEADING_PREFIX.sub("", re.sub(r"\s+", "", stripped), count=1)
    for heading in sorted(headings, key=len, reverse=True):
        if not compact.startswith(heading):
            continue
        rest = compact[len(heading) :]
        if heading == "经营范围" and rest.startswith("内"):
            continue
        if (
            rest
            and _FIELD_LABEL_VALUE.search(rest)
            and not re.fullmatch(r"[:：.。]+", rest)
        ):
            return heading
    return None


def _heading_end_in_line(line: str, heading: str) -> int:
    compact_chars: list[tuple[int, str]] = [
        (index, char) for index, char in enumerate(line) if not char.isspace()
    ]
    compact = "".join(char for _, char in compact_chars)
    prefix = _HEADING_PREFIX.match(compact)
    start = prefix.end() if prefix else 0
    if compact[start : start + len(heading)] != heading:
        start = compact.find(heading)
        if start < 0:
            return len(line)
    end_index = start + len(heading) - 1
    if end_index >= len(compact_chars):
        return len(line)
    return compact_chars[end_index][0] + 1


def _is_toc_page(text: str) -> bool:
    head = text[:200]
    if re.search(r"(?:^|\n)\s*目录\s*(?:\n|$)", head):
        return True
    return "......" in text[:400] or "……" in text[:400]


def _is_toc_line(line: str, headings: Sequence[str] = ()) -> bool:
    if "......" in line or "……" in line:
        return True
    compact = re.sub(r"\s+", "", line)
    if not re.search(r"\d{1,4}$", compact):
        return False
    body = _HEADING_PREFIX.sub("", compact, count=1)
    known = tuple(dict.fromkeys((*_ALL_HEADINGS, *headings)))
    return any(heading in body for heading in known)


def _collect_field_label(
    page: ReportPageText,
    *,
    heading: str,
    line_end: int,
) -> tuple[str, list[int], bool, CoreEvidenceGap | None]:
    rest = page.text[line_end:]
    line = rest.split("\n", 1)[0]
    excerpt = f"{heading}{line}".strip()
    if not _FIELD_LABEL_VALUE.search(line):
        return excerpt, [], False, None
    return excerpt, [], True, None


def _collect_section(
    page: ReportPageText,
    *,
    heading: str,
    line_end: int,
    by_page: dict[int, ReportPageText],
    chapter_task: ChapterTask,
) -> tuple[str, list[int], bool, CoreEvidenceGap | None]:
    first = _cut_at_boundary(page.text[line_end:])
    excerpt = f"{heading}\n{first.text}".strip()
    continuations: list[int] = []
    if first.closed:
        return excerpt, continuations, True, None

    current = page.page
    while len(continuations) + 1 < _MAX_SECTION_PAGES:
        nxt = by_page.get(current + 1)
        if nxt is None:
            if excerpt.strip() in {"", heading}:
                return "", continuations, False, None
            if _looks_incomplete(excerpt, heading):
                return (
                    excerpt,
                    continuations,
                    False,
                    CoreEvidenceGap(
                        code="page_unreadable",
                        chapter_task=chapter_task.value,
                        page=current + 1,
                        message=f"continuation page is missing: {current + 1}",
                    ),
                )
            return excerpt, continuations, False, None
        if not nxt.readable:
            empty = excerpt.strip() in {"", heading}
            return (
                "" if empty else excerpt,
                continuations,
                False,
                CoreEvidenceGap(
                    code="page_unreadable",
                    chapter_task=chapter_task.value,
                    page=nxt.page,
                    message=f"continuation page is unreadable: {nxt.page}",
                ),
            )
        chunk = _cut_at_boundary(nxt.text)
        if not chunk.text.strip() and chunk.closed:
            return excerpt, continuations, True, None
        if chunk.text.strip():
            excerpt = f"{excerpt}\n{chunk.text.strip()}".strip()
            continuations.append(nxt.page)
        current = nxt.page
        if chunk.closed:
            return excerpt, continuations, True, None
    return excerpt, continuations, False, None


class _PageChunk:
    def __init__(self, text: str, closed: bool) -> None:
        self.text = text
        self.closed = closed


def _cut_at_boundary(text: str) -> _PageChunk:
    cursor = 0
    while True:
        match = _SECTION_BOUNDARY.search(text, cursor)
        if match is None:
            return _PageChunk(text.strip(), False)
        line_start = match.start()
        if line_start < len(text) and text[line_start] == "\n":
            line_start += 1
        line_end = text.find("\n", line_start)
        line = text[line_start : line_end if line_end >= 0 else None]
        if re.search(r"\d", line):
            cursor = match.end()
            continue
        if match.start() == 0:
            return _PageChunk("", True)
        return _PageChunk(text[: match.start()].strip(), True)


def _usable_excerpt(
    excerpt: str,
    heading: str,
    require_substance: bool,
    *,
    substance_extra: re.Pattern[str] | None = None,
) -> bool:
    if not excerpt.strip() or excerpt.strip() == heading:
        return False
    if require_substance:
        joined = _join_pdf_soft_breaks(excerpt)
        if _OVERVIEW_SUBSTANCE.search(joined):
            return True
        return substance_extra is not None and (
            substance_extra.search(excerpt) is not None
            or substance_extra.search(joined) is not None
        )
    return True


def _looks_incomplete(excerpt: str, heading: str) -> bool:
    compact = re.sub(r"\s+", "", excerpt)
    if not compact or compact == heading:
        return True
    if _CONTINUATION_TAIL.search(compact):
        return True
    return compact[-1] not in "。！？；;"


def _display_quote(excerpt: str, heading: str) -> str:
    compact = re.sub(r"\s+", "", excerpt)
    for sentence in re.split(r"[。；;\n]", excerpt):
        sentence = sentence.strip()
        if (heading in sentence or heading in re.sub(r"\s+", "", sentence)) and len(
            re.sub(r"\s+", "", sentence)
        ) > len(heading):
            return sentence[:_DISPLAY_QUOTE_LIMIT]
    if heading in excerpt:
        start = excerpt.find(heading)
        return excerpt[start : start + _DISPLAY_QUOTE_LIMIT].strip()
    return compact[:_DISPLAY_QUOTE_LIMIT] or heading


def _record_matches_span(
    record: SemanticRecord,
    report: ReportIdentity,
    span: CoreEvidenceSpan,
) -> bool:
    if record.field_id not in span.field_ids:
        return False
    if not _period_matches(record, report):
        return False
    if not _source_range_matches(record, span):
        return False
    objects = _record_objects(record)
    if not objects:
        return True
    compact = re.sub(r"\s+", "", span.excerpt)
    return any(_object_mentioned(item, compact) for item in objects)


def _field_covered_for_span(
    field_id: str,
    span: CoreEvidenceSpan,
    report: ReportIdentity,
    reused_records: Sequence[SemanticRecord],
) -> bool:
    covering = [
        record
        for record in reused_records
        if record.field_id == field_id and _record_matches_span(record, report, span)
    ]
    if not covering:
        return False
    if field_id == "business_overview_source":
        return _overview_covers_excerpt(covering, span)
    demanded = _demanded_objects(field_id, span.excerpt)
    if not demanded:
        return False
    covered: set[str] = set()
    for record in covering:
        covered.update(_record_objects(record))
    return all(
        any(
            _object_mentioned(item, covered_item)
            or _object_mentioned(covered_item, item)
            for covered_item in covered
        )
        for item in demanded
    )


def _period_matches(record: SemanticRecord, report: ReportIdentity) -> bool:
    """Reuse the annual-duration alias already used by Stage 5 adapters."""

    reported = record.reported_period.strip()
    expected = report.report_period.strip()
    if not reported or not expected:
        return False
    if reported == expected:
        return True
    if record.period_type is not PeriodType.DURATION:
        return False
    left = _annual_duration_year(reported)
    right = _annual_duration_year(expected)
    return bool(left and right and left == right)


def _annual_duration_year(value: str) -> str | None:
    # Same closed annual aliases as
    # stage5_provider._normalize_segment_partition_reported_period.
    match = re.fullmatch(r"(\d{4})(?:年|年度|-12-31)?", re.sub(r"\s+", "", value))
    return match.group(1) if match else None


def _source_range_matches(record: SemanticRecord, span: CoreEvidenceSpan) -> bool:
    span_pages = {span.page, *span.continuation_pages}
    record_pages: set[int] = set()
    for item in record.evidence:
        record_pages.add(item.page)
        record_pages.update(item.continuation_pages)
    return bool(record_pages & span_pages)


def _overview_covers_excerpt(
    records: Sequence[SemanticRecord],
    span: CoreEvidenceSpan,
) -> bool:
    body = _compact_overview_body(span.excerpt, span.section_title)
    if not body:
        return False
    for record in records:
        if not isinstance(record, BusinessOverview):
            continue
        accepted = _strip_company_prefix(_compact_source_text(record.source_text))
        if accepted and (body == accepted or body in accepted):
            return True
    return False


def _compact_overview_body(excerpt: str, heading: str) -> str:
    compact = _compact_source_text(excerpt)
    heading_compact = _compact_source_text(heading)
    if heading_compact and compact.startswith(heading_compact):
        compact = compact[len(heading_compact) :]
    return _strip_company_prefix(compact)


def _compact_source_text(value: str) -> str:
    return re.sub(r"[\s。；;，,：:]+$", "", re.sub(r"\s+", "", value))


def _strip_company_prefix(value: str) -> str:
    return re.sub(r"^(?:公司|本公司)", "", value)


def _record_objects(record: SemanticRecord) -> set[str]:
    if isinstance(record, Measurement):
        return {
            re.sub(r"\s+", "", value)
            for value in (record.segment_label, record.measured_object)
            if value
        }
    if isinstance(record, Segment):
        return {re.sub(r"\s+", "", record.label)} if record.label else set()
    if isinstance(record, Activity):
        return {re.sub(r"\s+", "", record.object_name)} if record.object_name else set()
    if isinstance(record, BusinessOverview):
        return set()
    return set()


def _demanded_objects(field_id: str, excerpt: str) -> set[str]:
    if field_id in {"operating_revenue", "segment_dimension"}:
        objects = {
            re.sub(r"\s+", "", match.group(1))
            for match in _REVENUE_OBJECT.finditer(excerpt)
        }
        return {
            item
            for item in objects
            if item not in {"项目", "其中", "合计", "总计", "小计"}
        }
    if field_id == "explicit_activity":
        match = _ACTIVITY_OBJECTS.search(re.sub(r"\s+", "", excerpt))
        if match is None:
            return set()
        return {
            part for part in re.split(r"[、，,和及]", match.group(1)) if len(part) >= 2
        }
    return set()


def _object_mentioned(needle: str, haystack: str) -> bool:
    if not needle:
        return False
    return needle in haystack


def _prepared_evidence_for_spans(
    report: ReportIdentity,
    spans: Sequence[CoreEvidenceSpan],
) -> tuple[PreparedEvidence, ...]:
    complete_chapters = {span.chapter_task for span in spans if span.context_complete}
    prepared: list[PreparedEvidence] = []
    for span in spans:
        if not span.context_complete and span.chapter_task in complete_chapters:
            continue
        prepared.extend(_prepared_evidence(report, span))
    return tuple(prepared)


def _prepared_evidence(
    report: ReportIdentity,
    span: CoreEvidenceSpan,
) -> tuple[PreparedEvidence, ...]:
    items: list[PreparedEvidence] = []
    for field_id in span.field_ids:
        digest = hashlib.sha256(
            f"{report.report_id}:{span.chapter_task}:{field_id}:"
            f"{span.page}:{span.section_title}:{span.excerpt}".encode()
        ).hexdigest()[:16]
        items.append(
            PreparedEvidence(
                evidence=Evidence(
                    evidence_id=f"core-ev-{digest}",
                    report=report,
                    page=span.page,
                    section_title=span.section_title,
                    continuation_pages=span.continuation_pages,
                    anchor=TextAnchor(bounded_quote=span.excerpt),
                ),
                field_id=field_id,
                context_complete=span.context_complete,
                continuation_complete=span.context_complete,
                source_readable=True,
            )
        )
    return tuple(items)


_CLAUSE_PATTERNS = (
    re.compile(r"经营模式主要为[:：]\s*([^。；;]{2,300})"),
    re.compile(r"主营业务为\s*([^。；;]{2,80})"),
    re.compile(r"主要从事\s*([^。；;]{2,400})"),
    re.compile(r"主要产品包括\s*([^。；;]{2,600})"),
    re.compile(r"主要产品为\s*([^。；;]{2,80})"),
    re.compile(r"(?:^|[\n\r])经营范围(?!内)\s*[:：]?\s*([^。；;\n]{2,120})"),
    re.compile(r"涵盖\s*([^。；;]{2,80})"),
)
_UNIT_DECLARATION = re.compile(r"单位[:：]\s*(?:人民币)?(百万元|千元|亿元|万元|元)")
_PERCENT_UNIT = re.compile(r"单位[:：]\s*%")
_PDF_AMOUNT_WRAP = re.compile(r"([0-9,]+\.)\s*[\r\n]+\s*(\d+)")
_ACTION_TOKEN = re.compile(r"(研发|开发|制造|生产|加工|销售|维修|服务保障)")
_VAGUE_OBJECT = re.compile(r"^(?:经批准的)?(?:其它|其他)业务$")
_SKIP_SEGMENT_LABELS = frozenset(
    {
        "营业收入",
        "营业成本",
        "毛利率",
        "项目",
        "分行业",
        "分产品",
        "分地区",
        "同比增减",
        "其中",
        "合计",
        "总计",
        "小计",
        "汇总",
    }
)


REVENUE_SENTENCE_REPAIR = "revenue_sentence_repair"
REVENUE_SENTENCE_REPAIR_V1 = "v1"
REVENUE_SENTENCE_REPAIR_V2 = "v2"
REVENUE_SENTENCE_REPAIR_V3 = "v3"
REVENUE_SENTENCE_REPAIR_V4 = "v4"
REVENUE_SENTENCE_REPAIR_V5 = "v5"
REVENUE_SENTENCE_REPAIR_V6 = "v6"
REVENUE_SENTENCE_REPAIR_V7 = "v7"
REVENUE_SENTENCE_REPAIR_V8 = "v8"
REVENUE_SENTENCE_REPAIR_V9 = "v9"
REVENUE_SENTENCE_REPAIR_V10 = "v10"
REVENUE_SENTENCE_REPAIR_V11 = "v11"
REVENUE_SENTENCE_REPAIR_V12 = "v12"
REVENUE_SENTENCE_REPAIR_V13 = "v13"
REVENUE_SENTENCE_REPAIR_V14 = "v14"
REVENUE_SENTENCE_REPAIR_V15 = "v15"
REVENUE_SENTENCE_REPAIR_V16 = "v16"
REVENUE_SENTENCE_REPAIR_V17 = "v17"
REVENUE_SENTENCE_REPAIR_V18 = "v18"
REVENUE_SENTENCE_REPAIR_V19 = "v19"
REVENUE_SENTENCE_REPAIR_V20 = "v20"
REVENUE_SENTENCE_REPAIR_V21 = "v21"
REVENUE_SENTENCE_REPAIR_V22 = "v22"
REVENUE_SENTENCE_REPAIR_V23 = "v23"
REVENUE_SENTENCE_REPAIR_V24 = "v24"
REVENUE_SENTENCE_REPAIR_V25 = "v25"
REVENUE_SENTENCE_REPAIR_V26 = "v26"
REVENUE_SENTENCE_REPAIR_V27 = "v27"
REVENUE_SENTENCE_REPAIR_V28 = "v28"
REVENUE_SENTENCE_REPAIR_V29 = "v29"
REVENUE_SENTENCE_REPAIR_V30 = "v30"
REVENUE_SENTENCE_REPAIR_V31 = "v31"
REVENUE_SENTENCE_REPAIR_V32 = "v32"
REVENUE_SENTENCE_REPAIR_V33 = "v33"
REVENUE_SENTENCE_REPAIR_V34 = "v34"
REVENUE_SENTENCE_REPAIR_V35 = "v35"
REVENUE_SENTENCE_REPAIR_V36 = "v36"
REVENUE_SENTENCE_REPAIR_V37 = "v37"
REVENUE_SENTENCE_REPAIR_V38 = "v38"
REVENUE_SENTENCE_REPAIR_V39 = "v39"
REVENUE_SENTENCE_REPAIR_V40 = "v40"
REVENUE_SENTENCE_REPAIR_V41 = "v41"
REVENUE_SENTENCE_REPAIR_V42 = "v42"
REVENUE_SENTENCE_REPAIR_V43 = "v43"
REVENUE_SENTENCE_REPAIR_V44 = "v44"
REVENUE_SENTENCE_REPAIR_V45 = "v45"
REVENUE_SENTENCE_REPAIR_V46 = "v46"
REVENUE_SENTENCE_REPAIR_V47 = "v47"
REVENUE_SENTENCE_REPAIR_V48 = "v48"
REVENUE_SENTENCE_REPAIR_V49 = "v49"
REVENUE_SENTENCE_REPAIR_V50 = "v50"
REVENUE_SENTENCE_REPAIR_V51 = "v51"
REVENUE_SENTENCE_REPAIR_V52 = "v52"
REVENUE_SENTENCE_REPAIR_V53 = "v53"
REVENUE_SENTENCE_REPAIR_V54 = "v54"
REVENUE_SENTENCE_REPAIR_V55 = "v55"
REVENUE_SENTENCE_REPAIR_V56 = "v56"
REVENUE_SENTENCE_REPAIR_V57 = "v57"
REVENUE_SENTENCE_REPAIR_V58 = "v58"
REVENUE_SENTENCE_REPAIR_V59 = "v59"
REVENUE_SENTENCE_REPAIR_V60 = "v60"
REVENUE_SENTENCE_REPAIR_V61 = "v61"
_REVENUE_SENTENCE_REPAIR_VERSIONS = frozenset(
    {
        REVENUE_SENTENCE_REPAIR_V1,
        REVENUE_SENTENCE_REPAIR_V2,
        REVENUE_SENTENCE_REPAIR_V3,
        REVENUE_SENTENCE_REPAIR_V4,
        REVENUE_SENTENCE_REPAIR_V5,
        REVENUE_SENTENCE_REPAIR_V6,
        REVENUE_SENTENCE_REPAIR_V7,
        REVENUE_SENTENCE_REPAIR_V8,
        REVENUE_SENTENCE_REPAIR_V9,
        REVENUE_SENTENCE_REPAIR_V10,
        REVENUE_SENTENCE_REPAIR_V11,
        REVENUE_SENTENCE_REPAIR_V12,
        REVENUE_SENTENCE_REPAIR_V13,
        REVENUE_SENTENCE_REPAIR_V14,
        REVENUE_SENTENCE_REPAIR_V15,
        REVENUE_SENTENCE_REPAIR_V16,
        REVENUE_SENTENCE_REPAIR_V17,
        REVENUE_SENTENCE_REPAIR_V18,
        REVENUE_SENTENCE_REPAIR_V19,
        REVENUE_SENTENCE_REPAIR_V20,
        REVENUE_SENTENCE_REPAIR_V21,
        REVENUE_SENTENCE_REPAIR_V22,
        REVENUE_SENTENCE_REPAIR_V23,
        REVENUE_SENTENCE_REPAIR_V24,
        REVENUE_SENTENCE_REPAIR_V25,
        REVENUE_SENTENCE_REPAIR_V26,
        REVENUE_SENTENCE_REPAIR_V27,
        REVENUE_SENTENCE_REPAIR_V28,
        REVENUE_SENTENCE_REPAIR_V29,
        REVENUE_SENTENCE_REPAIR_V30,
        REVENUE_SENTENCE_REPAIR_V31,
        REVENUE_SENTENCE_REPAIR_V32,
        REVENUE_SENTENCE_REPAIR_V33,
        REVENUE_SENTENCE_REPAIR_V34,
        REVENUE_SENTENCE_REPAIR_V35,
        REVENUE_SENTENCE_REPAIR_V36,
        REVENUE_SENTENCE_REPAIR_V37,
        REVENUE_SENTENCE_REPAIR_V38,
        REVENUE_SENTENCE_REPAIR_V39,
        REVENUE_SENTENCE_REPAIR_V40,
        REVENUE_SENTENCE_REPAIR_V41,
        REVENUE_SENTENCE_REPAIR_V42,
        REVENUE_SENTENCE_REPAIR_V43,
        REVENUE_SENTENCE_REPAIR_V44,
        REVENUE_SENTENCE_REPAIR_V45,
        REVENUE_SENTENCE_REPAIR_V46,
        REVENUE_SENTENCE_REPAIR_V47,
        REVENUE_SENTENCE_REPAIR_V48,
        REVENUE_SENTENCE_REPAIR_V49,
        REVENUE_SENTENCE_REPAIR_V50,
        REVENUE_SENTENCE_REPAIR_V51,
        REVENUE_SENTENCE_REPAIR_V52,
        REVENUE_SENTENCE_REPAIR_V53,
        REVENUE_SENTENCE_REPAIR_V54,
        REVENUE_SENTENCE_REPAIR_V55,
        REVENUE_SENTENCE_REPAIR_V56,
        REVENUE_SENTENCE_REPAIR_V57,
        REVENUE_SENTENCE_REPAIR_V58,
        REVENUE_SENTENCE_REPAIR_V59,
        REVENUE_SENTENCE_REPAIR_V60,
        REVENUE_SENTENCE_REPAIR_V61,
    }
)


def revenue_sentence_repair_requested(identity: Mapping[str, Any] | None) -> bool:
    """Return whether this identity turns on same-evidence revenue sentences.

    A different work identity does not change projection unless it carries this
    marker. The marker is read by the overview projection, not only stored.
    ``v2`` is the corrected commodity-evidence identity and still keeps the
    revenue-sentence repair.
    """

    if not isinstance(identity, Mapping):
        return False
    return identity.get(REVENUE_SENTENCE_REPAIR) in _REVENUE_SENTENCE_REPAIR_VERSIONS


def named_role_repair_requested(identity: Mapping[str, Any] | None) -> bool:
    """Return whether this identity keeps principal sentences and named roles.

    ``v4`` still carries the revenue-sentence repair. It also accepts “业务覆盖”
    and “专注于”, and it separates a real sale from “销售模式”.
    """

    if not isinstance(identity, Mapping):
        return False
    return identity.get(REVENUE_SENTENCE_REPAIR) in {
        REVENUE_SENTENCE_REPAIR_V4,
        REVENUE_SENTENCE_REPAIR_V5,
        REVENUE_SENTENCE_REPAIR_V6,
        REVENUE_SENTENCE_REPAIR_V7,
        REVENUE_SENTENCE_REPAIR_V8,
        REVENUE_SENTENCE_REPAIR_V9,
        REVENUE_SENTENCE_REPAIR_V10,
        REVENUE_SENTENCE_REPAIR_V11,
        REVENUE_SENTENCE_REPAIR_V12,
        REVENUE_SENTENCE_REPAIR_V13,
        REVENUE_SENTENCE_REPAIR_V14,
        REVENUE_SENTENCE_REPAIR_V15,
        REVENUE_SENTENCE_REPAIR_V16,
        REVENUE_SENTENCE_REPAIR_V17,
        REVENUE_SENTENCE_REPAIR_V18,
        REVENUE_SENTENCE_REPAIR_V19,
        REVENUE_SENTENCE_REPAIR_V20,
        REVENUE_SENTENCE_REPAIR_V21,
        REVENUE_SENTENCE_REPAIR_V22,
        REVENUE_SENTENCE_REPAIR_V23,
        REVENUE_SENTENCE_REPAIR_V24,
        REVENUE_SENTENCE_REPAIR_V25,
        REVENUE_SENTENCE_REPAIR_V26,
        REVENUE_SENTENCE_REPAIR_V27,
        REVENUE_SENTENCE_REPAIR_V28,
        REVENUE_SENTENCE_REPAIR_V29,
        REVENUE_SENTENCE_REPAIR_V30,
        REVENUE_SENTENCE_REPAIR_V31,
        REVENUE_SENTENCE_REPAIR_V32,
        REVENUE_SENTENCE_REPAIR_V33,
        REVENUE_SENTENCE_REPAIR_V34,
        REVENUE_SENTENCE_REPAIR_V35,
        REVENUE_SENTENCE_REPAIR_V36,
        REVENUE_SENTENCE_REPAIR_V37,
        REVENUE_SENTENCE_REPAIR_V38,
        REVENUE_SENTENCE_REPAIR_V39,
        REVENUE_SENTENCE_REPAIR_V40,
        REVENUE_SENTENCE_REPAIR_V41,
        REVENUE_SENTENCE_REPAIR_V42,
        REVENUE_SENTENCE_REPAIR_V43,
        REVENUE_SENTENCE_REPAIR_V44,
        REVENUE_SENTENCE_REPAIR_V45,
        REVENUE_SENTENCE_REPAIR_V46,
        REVENUE_SENTENCE_REPAIR_V47,
        REVENUE_SENTENCE_REPAIR_V48,
        REVENUE_SENTENCE_REPAIR_V49,
        REVENUE_SENTENCE_REPAIR_V50,
        REVENUE_SENTENCE_REPAIR_V51,
        REVENUE_SENTENCE_REPAIR_V52,
        REVENUE_SENTENCE_REPAIR_V53,
        REVENUE_SENTENCE_REPAIR_V54,
        REVENUE_SENTENCE_REPAIR_V55,
        REVENUE_SENTENCE_REPAIR_V56,
        REVENUE_SENTENCE_REPAIR_V57,
        REVENUE_SENTENCE_REPAIR_V58,
        REVENUE_SENTENCE_REPAIR_V59,
        REVENUE_SENTENCE_REPAIR_V60,
        REVENUE_SENTENCE_REPAIR_V61,
    }


def service_operating_energy_requested(identity: Mapping[str, Any] | None) -> bool:
    """Return whether this identity keeps service operating energy use.

    ``v6`` still carries the principal-sentence and named-role repairs. It also
    binds 电耗 and 柴油单耗 to the source subject and business column.
    """

    if not isinstance(identity, Mapping):
        return False
    return identity.get(REVENUE_SENTENCE_REPAIR) in {
        REVENUE_SENTENCE_REPAIR_V6,
        REVENUE_SENTENCE_REPAIR_V7,
        REVENUE_SENTENCE_REPAIR_V8,
        REVENUE_SENTENCE_REPAIR_V9,
        REVENUE_SENTENCE_REPAIR_V10,
        REVENUE_SENTENCE_REPAIR_V11,
        REVENUE_SENTENCE_REPAIR_V12,
        REVENUE_SENTENCE_REPAIR_V13,
        REVENUE_SENTENCE_REPAIR_V14,
        REVENUE_SENTENCE_REPAIR_V15,
        REVENUE_SENTENCE_REPAIR_V16,
        REVENUE_SENTENCE_REPAIR_V17,
        REVENUE_SENTENCE_REPAIR_V18,
        REVENUE_SENTENCE_REPAIR_V19,
        REVENUE_SENTENCE_REPAIR_V20,
        REVENUE_SENTENCE_REPAIR_V21,
        REVENUE_SENTENCE_REPAIR_V22,
        REVENUE_SENTENCE_REPAIR_V23,
        REVENUE_SENTENCE_REPAIR_V24,
        REVENUE_SENTENCE_REPAIR_V25,
        REVENUE_SENTENCE_REPAIR_V26,
        REVENUE_SENTENCE_REPAIR_V27,
        REVENUE_SENTENCE_REPAIR_V28,
        REVENUE_SENTENCE_REPAIR_V29,
        REVENUE_SENTENCE_REPAIR_V30,
        REVENUE_SENTENCE_REPAIR_V31,
        REVENUE_SENTENCE_REPAIR_V32,
        REVENUE_SENTENCE_REPAIR_V33,
        REVENUE_SENTENCE_REPAIR_V34,
        REVENUE_SENTENCE_REPAIR_V35,
        REVENUE_SENTENCE_REPAIR_V36,
        REVENUE_SENTENCE_REPAIR_V37,
        REVENUE_SENTENCE_REPAIR_V38,
        REVENUE_SENTENCE_REPAIR_V39,
        REVENUE_SENTENCE_REPAIR_V40,
        REVENUE_SENTENCE_REPAIR_V41,
        REVENUE_SENTENCE_REPAIR_V42,
        REVENUE_SENTENCE_REPAIR_V43,
        REVENUE_SENTENCE_REPAIR_V44,
        REVENUE_SENTENCE_REPAIR_V45,
        REVENUE_SENTENCE_REPAIR_V46,
        REVENUE_SENTENCE_REPAIR_V47,
        REVENUE_SENTENCE_REPAIR_V48,
        REVENUE_SENTENCE_REPAIR_V49,
        REVENUE_SENTENCE_REPAIR_V50,
        REVENUE_SENTENCE_REPAIR_V51,
        REVENUE_SENTENCE_REPAIR_V52,
        REVENUE_SENTENCE_REPAIR_V53,
        REVENUE_SENTENCE_REPAIR_V54,
        REVENUE_SENTENCE_REPAIR_V55,
        REVENUE_SENTENCE_REPAIR_V56,
        REVENUE_SENTENCE_REPAIR_V57,
        REVENUE_SENTENCE_REPAIR_V58,
        REVENUE_SENTENCE_REPAIR_V59,
        REVENUE_SENTENCE_REPAIR_V60,
        REVENUE_SENTENCE_REPAIR_V61,
    }


def core_answer_repair_requested(identity: Mapping[str, Any] | None) -> bool:
    """Return whether this identity delivers substantive core answers.

    ``v7`` still carries the named-role and service-energy repairs. It also
    keeps a steel business sentence, a parent-child revenue table, and
    row-level supply bindings.
    """

    if not isinstance(identity, Mapping):
        return False
    return identity.get(REVENUE_SENTENCE_REPAIR) in {
        REVENUE_SENTENCE_REPAIR_V7,
        REVENUE_SENTENCE_REPAIR_V8,
        REVENUE_SENTENCE_REPAIR_V9,
        REVENUE_SENTENCE_REPAIR_V10,
        REVENUE_SENTENCE_REPAIR_V11,
        REVENUE_SENTENCE_REPAIR_V12,
        REVENUE_SENTENCE_REPAIR_V13,
        REVENUE_SENTENCE_REPAIR_V14,
        REVENUE_SENTENCE_REPAIR_V15,
        REVENUE_SENTENCE_REPAIR_V16,
        REVENUE_SENTENCE_REPAIR_V17,
        REVENUE_SENTENCE_REPAIR_V18,
        REVENUE_SENTENCE_REPAIR_V19,
        REVENUE_SENTENCE_REPAIR_V20,
        REVENUE_SENTENCE_REPAIR_V21,
        REVENUE_SENTENCE_REPAIR_V22,
        REVENUE_SENTENCE_REPAIR_V23,
        REVENUE_SENTENCE_REPAIR_V24,
        REVENUE_SENTENCE_REPAIR_V25,
        REVENUE_SENTENCE_REPAIR_V26,
        REVENUE_SENTENCE_REPAIR_V27,
        REVENUE_SENTENCE_REPAIR_V28,
        REVENUE_SENTENCE_REPAIR_V29,
        REVENUE_SENTENCE_REPAIR_V30,
        REVENUE_SENTENCE_REPAIR_V31,
        REVENUE_SENTENCE_REPAIR_V32,
        REVENUE_SENTENCE_REPAIR_V33,
        REVENUE_SENTENCE_REPAIR_V34,
        REVENUE_SENTENCE_REPAIR_V35,
        REVENUE_SENTENCE_REPAIR_V36,
        REVENUE_SENTENCE_REPAIR_V37,
        REVENUE_SENTENCE_REPAIR_V38,
        REVENUE_SENTENCE_REPAIR_V39,
        REVENUE_SENTENCE_REPAIR_V40,
        REVENUE_SENTENCE_REPAIR_V41,
        REVENUE_SENTENCE_REPAIR_V42,
        REVENUE_SENTENCE_REPAIR_V43,
        REVENUE_SENTENCE_REPAIR_V44,
        REVENUE_SENTENCE_REPAIR_V45,
        REVENUE_SENTENCE_REPAIR_V46,
        REVENUE_SENTENCE_REPAIR_V47,
        REVENUE_SENTENCE_REPAIR_V48,
        REVENUE_SENTENCE_REPAIR_V49,
        REVENUE_SENTENCE_REPAIR_V50,
        REVENUE_SENTENCE_REPAIR_V51,
        REVENUE_SENTENCE_REPAIR_V52,
        REVENUE_SENTENCE_REPAIR_V53,
        REVENUE_SENTENCE_REPAIR_V54,
        REVENUE_SENTENCE_REPAIR_V55,
        REVENUE_SENTENCE_REPAIR_V56,
        REVENUE_SENTENCE_REPAIR_V57,
        REVENUE_SENTENCE_REPAIR_V58,
        REVENUE_SENTENCE_REPAIR_V59,
        REVENUE_SENTENCE_REPAIR_V60,
        REVENUE_SENTENCE_REPAIR_V61,
    }


def source_delivery_repair_requested(identity: Mapping[str, Any] | None) -> bool:
    """Return whether this identity delivers power and petrochemical sources.

    ``v8`` still carries the v7 core-answer repair. It also keeps a full
    “主要业务是” or “主要从事” sentence, a wrapped 百万元 industry table,
    and coal, crude, and refined-product roles. ``v9`` keeps those and marks
    the row-subject and review-coverage repair round. ``v10`` keeps all of it
    and adds the chemical-feedstock-oil role and the wrapped product row.
    """

    if not isinstance(identity, Mapping):
        return False
    return identity.get(REVENUE_SENTENCE_REPAIR) in {
        REVENUE_SENTENCE_REPAIR_V8,
        REVENUE_SENTENCE_REPAIR_V9,
        REVENUE_SENTENCE_REPAIR_V10,
        REVENUE_SENTENCE_REPAIR_V11,
        REVENUE_SENTENCE_REPAIR_V12,
        REVENUE_SENTENCE_REPAIR_V13,
        REVENUE_SENTENCE_REPAIR_V14,
        REVENUE_SENTENCE_REPAIR_V15,
        REVENUE_SENTENCE_REPAIR_V16,
        REVENUE_SENTENCE_REPAIR_V17,
        REVENUE_SENTENCE_REPAIR_V18,
        REVENUE_SENTENCE_REPAIR_V19,
        REVENUE_SENTENCE_REPAIR_V20,
        REVENUE_SENTENCE_REPAIR_V21,
        REVENUE_SENTENCE_REPAIR_V22,
        REVENUE_SENTENCE_REPAIR_V23,
        REVENUE_SENTENCE_REPAIR_V24,
        REVENUE_SENTENCE_REPAIR_V25,
        REVENUE_SENTENCE_REPAIR_V26,
        REVENUE_SENTENCE_REPAIR_V27,
        REVENUE_SENTENCE_REPAIR_V28,
        REVENUE_SENTENCE_REPAIR_V29,
        REVENUE_SENTENCE_REPAIR_V30,
        REVENUE_SENTENCE_REPAIR_V31,
        REVENUE_SENTENCE_REPAIR_V32,
        REVENUE_SENTENCE_REPAIR_V33,
        REVENUE_SENTENCE_REPAIR_V34,
        REVENUE_SENTENCE_REPAIR_V35,
        REVENUE_SENTENCE_REPAIR_V36,
        REVENUE_SENTENCE_REPAIR_V37,
        REVENUE_SENTENCE_REPAIR_V38,
        REVENUE_SENTENCE_REPAIR_V39,
        REVENUE_SENTENCE_REPAIR_V40,
        REVENUE_SENTENCE_REPAIR_V41,
        REVENUE_SENTENCE_REPAIR_V42,
        REVENUE_SENTENCE_REPAIR_V43,
        REVENUE_SENTENCE_REPAIR_V44,
        REVENUE_SENTENCE_REPAIR_V45,
        REVENUE_SENTENCE_REPAIR_V46,
        REVENUE_SENTENCE_REPAIR_V47,
        REVENUE_SENTENCE_REPAIR_V48,
        REVENUE_SENTENCE_REPAIR_V49,
        REVENUE_SENTENCE_REPAIR_V50,
        REVENUE_SENTENCE_REPAIR_V51,
        REVENUE_SENTENCE_REPAIR_V52,
        REVENUE_SENTENCE_REPAIR_V53,
        REVENUE_SENTENCE_REPAIR_V54,
        REVENUE_SENTENCE_REPAIR_V55,
        REVENUE_SENTENCE_REPAIR_V56,
        REVENUE_SENTENCE_REPAIR_V57,
        REVENUE_SENTENCE_REPAIR_V58,
        REVENUE_SENTENCE_REPAIR_V59,
        REVENUE_SENTENCE_REPAIR_V60,
        REVENUE_SENTENCE_REPAIR_V61,
    }


def project_owned_page_facts(
    selection: CoreEvidenceSelection,
    chapter: ChapterTask | None = None,
    *,
    repair_revenue_sentence: bool = False,
    named_role_repair: bool = False,
    service_operating_energy: bool = False,
    core_answer_repair: bool = False,
    source_delivery_repair: bool = False,
    expand_actor_aliases: bool = False,
) -> tuple[SemanticRecord, ...]:
    """Project source-native core facts already stated in owned excerpts."""

    actor_definitions = (
        tuple(
            definition
            for candidate in selection.spans
            for definition in _native_actor_definitions(candidate.excerpt)
        )
        if expand_actor_aliases
        else ()
    )
    records: list[SemanticRecord] = []
    for span in selection.spans:
        if chapter is not None and span.chapter_task != chapter.value:
            continue
        if span.chapter_task == ChapterTask.EXTRACT_BUSINESS_OVERVIEW.value:
            records.extend(
                _project_overview_span(
                    selection,
                    span,
                    repair_revenue_sentence=repair_revenue_sentence,
                    named_role_repair=named_role_repair,
                    core_answer_repair=core_answer_repair,
                    source_delivery_repair=source_delivery_repair,
                )
            )
        elif span.chapter_task == ChapterTask.EXTRACT_SEGMENT_FINANCIALS.value:
            if span.section_title in _INCOME_ANALYSIS_HEADINGS:
                records.extend(_project_income_analysis_span(selection, span))
            else:
                records.extend(
                    _project_segment_span(
                        selection,
                        span,
                        core_answer_repair=core_answer_repair,
                        source_delivery_repair=source_delivery_repair,
                    )
                )
                records.extend(_project_company_total_rows(selection, span))
        elif span.chapter_task == ChapterTask.EXTRACT_MATERIAL_INPUTS.value:
            records.extend(
                _project_material_span(
                    selection, span, source_delivery_repair=source_delivery_repair
                )
            )
    if repair_revenue_sentence and chapter in (
        None,
        ChapterTask.EXTRACT_BUSINESS_OVERVIEW,
    ):
        for span in selection.spans:
            records.extend(
                _project_repair_commodity_span(
                    selection,
                    span,
                    named_role_repair=named_role_repair,
                    service_operating_energy=service_operating_energy,
                    core_answer_repair=core_answer_repair,
                    source_delivery_repair=source_delivery_repair,
                    expand_actor_aliases=expand_actor_aliases,
                    actor_definitions=actor_definitions,
                )
            )
    if source_delivery_repair:
        records = _retain_unclear_segment_descriptions(selection, records)
        relations = {}
        for context in selection.spans:
            if context.section_title != "原始关系说明":
                continue
            for line in context.excerpt.splitlines():
                m = re.fullmatch(r"\s*(.+?公司)\s+(联营企业|合营企业)\s*", line)
                if m:
                    relations[re.sub(r"\s+", "", m[1])] = (m[2], context.page)
        associated = set()
        kind = None
        last_page = None
        for context in selection.spans:
            if context.section_title != "原始关系说明":
                continue
            if last_page is None or context.page != last_page + 1:
                kind = None
            last_page = context.page
            for line in context.excerpt.splitlines():
                if re.search(r"[一二三]、合营企业", line):
                    kind = "合营企业"
                elif re.search(r"[一二三]、联营企业", line):
                    kind = "联营企业"
                elif re.match(
                    r"\s*(?:合计|[（(]\d+[)）]|\d+、|[一二三四五六七八九十]+、)", line
                ):
                    kind = None
                m = re.match(r"\s*(.+?公司)(?:\s+\d|\s*$)", line)
                if kind and m:
                    associated.add(re.sub(r"\s+", "", m[1]))
        for index, record in enumerate(records):
            if isinstance(record, Activity) and record.source_actor in associated:
                records[index] = record.model_copy(
                    update={"subject_scope": SubjectScope.BUSINESS_SEGMENT}
                )
        for index, record in enumerate(records):
            native = record.source_native
            if not isinstance(record, (Segment, Measurement)) or not re.match(
                r"重要(?:合营|联营)企业/", native.header or ""
            ):
                continue
            resolved = relations.get(native.name)
            if resolved and resolved[0] not in native.header:
                kind, relation_page = resolved
                records[index] = record.model_copy(
                    update={
                        "source_native": native.model_copy(
                            update={
                                "header": "重要" + kind + "/本期营业收入",
                                "qualifier": kind
                                + "："
                                + native.name
                                + "；原栏目冲突："
                                + native.header
                                + f"；关系依据p{relation_page}明确列示，非集团合并收入",
                            }
                        ),
                        "evidence": tuple(
                            e.model_copy(
                                update={
                                    "subject_evidence_pages": tuple(
                                        dict.fromkeys(
                                            (*e.subject_evidence_pages, relation_page)
                                        )
                                    )
                                }
                            )
                            for e in record.evidence
                        ),
                    }
                )
    if source_delivery_repair:
        rental = [
            r
            for r in records
            if isinstance(r, Segment)
            and r.source_native.header == "房地产出租/租金收入"
        ]
        if rental:
            unique_rental = {
                (
                    r.source_native.name,
                    r.source_native.qualifier,
                    r.source_native.value,
                ): r
                for r in rental
            }
            total = sum(
                Decimal(r.source_native.value.replace(",", ""))
                for r in unique_rental.values()
            )
            corroborating = [
                r
                for r in records
                if isinstance(r, Measurement)
                and r.source_native.value
                and r.source_native.unit
                and r.source_native.unit != rental[0].source_native.unit
                and re.search("租赁|出租", r.source_native.name)
                and Decimal(r.source_native.value.replace(",", "")) == total
            ]
            if corroborating:
                conflicting_cells = {
                    (
                        r.source_native.name,
                        r.source_native.value,
                        r.source_native.unit,
                        r.source_native.header,
                        r.source_native.qualifier,
                    )
                    for r in rental
                }
                records = [
                    r.model_copy(
                        update={
                            "uncertainty": (
                                *r.uncertainty,
                                "official_income_unit_conflict:unclear:原表单位与同报告独立收入原格矛盾；原打印值及表头保留，未作单位更正",
                            )
                        }
                    )
                    if isinstance(r, (Segment, Measurement))
                    and (
                        r.source_native.name,
                        r.source_native.value,
                        r.source_native.unit,
                        r.source_native.header,
                        r.source_native.qualifier,
                    )
                    in conflicting_cells
                    else r
                    for r in records
                ]
    return _dedupe_owned_records(records)


def _retain_unclear_segment_descriptions(
    selection: CoreEvidenceSelection,
    records: list[SemanticRecord],
) -> list[SemanticRecord]:
    """Retain conflicting native descriptions without affirming their business.

    A named product-sales segment can describe an unrelated produced/sold
    object. Require positive same-report main-business or revenue context for
    the segment's product, then check whether that other context supports the
    described object. Absence alone, or a product word alone, is not a conflict.
    """
    corroborating = [
        span
        for span in selection.spans
        if "报告分部包括" not in span.excerpt
        and re.search(
            r"(?:公司|本公司)(?:主要从事|产品销售主要包括|收入主要来源于)",
            re.sub(r"\s+", "", span.excerpt),
        )
    ]
    context = re.sub(r"\s+", "", "\n".join(s.excerpt for s in corroborating))
    retained: list[SemanticRecord] = []
    for record in records:
        if not isinstance(record, BusinessOverview):
            retained.append(record)
            continue
        text = re.sub(r"\s+", "", record.source_text)
        conflicts = []
        if "主要控股参股公司分析" in text and "经营范围" in text and "许可项目" in text:
            conflicts.append(
                "registered_permission_not_current_operation:unclear:"
                "原注册许可及一般项目保留，不能据此确认报告期实际经营"
            )
        if "报告分部包括" in text:
            for match in re.finditer(
                r"[（(]\d+[)）]([^；。()（）]{2,30}?)产品销售分部[，,]"
                r"生产及销售([^；。]+)",
                text,
            ):
                native_product, described = match.groups()
                stem = native_product[:2]
                if (
                    stem in context
                    and stem not in described
                    and described.removesuffix("及相关产品") not in context
                ):
                    pages = sorted({s.page for s in corroborating if stem in s.excerpt})
                    conflicts.append(
                        f"{BUSINESS_DESCRIPTION_CONFLICT}:unclear:"
                        f"原产品分部={native_product}；原描述={described}；"
                        f"同报告主营及收入来源页={pages}"
                    )
        if conflicts:
            # Evidence and source_text remain the exact original statement.
            record = record.model_copy(
                update={"uncertainty": (*record.uncertainty, *conflicts)}
            )
        retained.append(record)
    return retained


def _prepared_for(
    selection: CoreEvidenceSelection,
    span: CoreEvidenceSpan,
    field_id: str,
) -> PreparedEvidence | None:
    for item in selection.prepared_evidence:
        if (
            item.field_id == field_id
            and item.evidence.page == span.page
            and item.evidence.section_title == span.section_title
            and isinstance(item.evidence.anchor, TextAnchor)
            and item.evidence.anchor.bounded_quote == span.excerpt
        ):
            return item
    return None


def _project_overview_span(
    selection: CoreEvidenceSelection,
    span: CoreEvidenceSpan,
    *,
    repair_revenue_sentence: bool = False,
    named_role_repair: bool = False,
    core_answer_repair: bool = False,
    source_delivery_repair: bool = False,
) -> tuple[SemanticRecord, ...]:
    overview_item = _prepared_for(selection, span, "business_overview_source")
    activity_item = _prepared_for(selection, span, "explicit_activity")
    records: list[SemanticRecord] = []
    company_sentence = (
        _company_business_source(span.excerpt) if named_role_repair else ""
    )
    if core_answer_repair and not company_sentence:
        company_sentence = _steel_business_source(span.excerpt)
    if source_delivery_repair:
        numbered = _numbered_business_source(span.excerpt)
        if (
            not numbered
            and span.section_title != "当期产品及服务披露"
            and len(
                re.findall(
                    r"(?:^|\n)\s*\d+[.．、]\s*[\u4e00-\u9fff]{2,12}业务", span.excerpt
                )
            )
            >= 2
        ):
            return ()
        delivered = (
            _complete_current_business_source(span.excerpt)
            or numbered
            or next(iter(_owned_business_sources(span.excerpt)), "")
            or _project_business_source(span.excerpt)
            or _main_business_source(span.excerpt)
            or _integrated_business_source(span.excerpt)
            or _toll_service_source(span.excerpt)
            or _main_operation_source(span.excerpt)
            or _operating_model_source(span.excerpt)
            or _company_as_narrative_source(span.excerpt)
            or _provider_narrative_source(span.excerpt)
            or _current_business_narrative_source(span.excerpt)
            or _company_sales_mechanism_source(span.excerpt)
            or _business_blocks_source(span.excerpt)
            or _company_income_source(span.excerpt)
            or next(iter(_current_product_sources(span.excerpt)), "")
        )
        if delivered:
            company_sentence = delivered
        if span.section_title == "当期产品及服务披露":
            # This span was already bounded to one affirmative source passage.
            # A shorter nested match must not replace its complete mechanism.
            company_sentence = span.excerpt
    if overview_item is not None and (
        _excerpt_states_owned_overview(span.excerpt) or company_sentence
    ):
        quote = (
            overview_item.evidence.anchor.bounded_quote
            if isinstance(overview_item.evidence.anchor, TextAnchor)
            else ""
        )
        source_text = company_sentence or _overview_source_text(
            span.excerpt,
            quote,
            heading=span.section_title,
        )
        if source_delivery_repair and source_text:
            supplements = _company_product_model_sources(span.excerpt)
            start = span.excerpt.find(source_text)
            ends = [span.excerpt.find(text) + len(text) for text in supplements]
            if start >= 0 and ends:
                # The contract requires one original continuous passage,
                # including the intervening owned context, not stitched quotes.
                source_text = span.excerpt[start : max(start + len(source_text), *ends)]
        if source_delivery_repair and re.search(
            r"(?:子公司|第三方公司|(?:本公司|公司)(?:拟|计划))[^。]{0,40}主营业务为",
            re.sub(r"\s+", "", source_text),
        ):
            source_text = ""
        if source_text:
            records.append(
                _base_fact(
                    BusinessOverview,
                    report=selection.report,
                    record_id=f"owned:{overview_item.evidence.evidence_id}:overview",
                    field_id="business_overview_source",
                    chapter_task=ChapterTask.EXTRACT_BUSINESS_OVERVIEW,
                    evidence=overview_item.evidence,
                    source_native=SourceNativeValue(name=span.section_title),
                    source_text=source_text,
                )
            )
        if (
            source_delivery_repair
            and records
            and re.match(r"注\d+：[^。]+成立于", source_text)
        ):
            note_actor = re.match(r"注\d+：([^。]+?)成立于", source_text)[1]
            if "参股项目" in re.sub(r"\s+", "", source_text) and "未纳入合并" in re.sub(
                r"\s+", "", source_text
            ):
                overview = records[-1]
                records[-1] = overview.model_copy(
                    update={
                        "subject_scope": SubjectScope.BUSINESS_SEGMENT,
                        "subject_basis": SubjectBasis.DIRECT_SOURCE_WORDING,
                        "subject_name": note_actor,
                        "source_native": overview.source_native.model_copy(
                            update={
                                "qualifier": "原参股主体："
                                + note_actor
                                + "；报告披露日未纳入合并；不视为集团本期经营"
                            }
                        ),
                    }
                )
        if repair_revenue_sentence:
            records.extend(
                _revenue_sentence_records(
                    selection,
                    overview_item,
                    excerpt=span.excerpt,
                    principal_text=source_text,
                )
            )
    if activity_item is None:
        return tuple(records)
    seen: set[str] = set()
    activity_excerpt = span.excerpt
    if source_delivery_repair:
        # Printed running headers can occur within the last sentence on a page.
        activity_excerpt = re.sub(
            r"[^\n\r。；]*?公司\s*20\d{2}\s*年年度报告[^\n\r]*", "", activity_excerpt
        )
        activity_excerpt = re.sub(r"(?m)^\s*\d+\s*/\s*\d+\s*$", "", activity_excerpt)
    excerpt = _join_pdf_soft_breaks(activity_excerpt)
    for pattern in _CLAUSE_PATTERNS:
        for match in pattern.finditer(excerpt):
            if source_delivery_repair and "主要控股参股公司分析" in excerpt:
                continue
            if source_delivery_repair and match.group(0).startswith("主营业务为"):
                sentence = _sentence_containing(excerpt, match.start())
                if not _current_company_sentence(sentence) or re.search(
                    r"(?:本公司|公司)(?:拟|计划)", sentence
                ):
                    continue
            if source_delivery_repair and match.group(0).startswith("主要从事"):
                prefix = _sentence_containing(excerpt, match.start())
                prefix = prefix[: prefix.find("主要从事")]
                if (
                    re.search(
                        r"(?<![\u4e00-\u9fff])(?:本公司|公司|本集团)[^。；;]{0,40}$",
                        prefix,
                    )
                    is None
                ):
                    continue
            verb = "经营"
            if match.group(0).startswith("主营"):
                verb = "为"
            elif "从事" in match.group(0):
                verb = "从事"
            elif "包括" in match.group(0):
                verb = "包括"
            elif "涵盖" in match.group(0):
                verb = "涵盖"
                if source_delivery_repair and re.search(
                    r"参数|等级|多个领域|应用领域|业务涉及", match.group(1)
                ):
                    continue
            clause = match.group(1)
            if source_delivery_repair:
                if re.search(r"销售折扣|销售折让|销售返利", clause):
                    # Variable consideration is a recognition policy, not a product.
                    continue
                if verb == "涵盖":
                    if re.match(r"生产加工与终端销售", re.sub(r"\s+", "", clause)):
                        continue
                    clause = re.split(
                        r"[，,](?:拓展|建设|提供)|等多元化", clause, maxsplit=1
                    )[0]
                    if "能源服务模式" in _sentence_containing(excerpt, match.start()):
                        continue
            if (
                source_delivery_repair
                and re.search(
                    r"公司控股子公司[^。]+主要从事叶片的设计",
                    re.sub(r"\s+", "", excerpt[: match.end()]),
                )
                and clause.strip().startswith("叶片的设计")
            ):
                continue
            actor = "公司"
            if source_delivery_repair:
                sentence = _sentence_containing(excerpt, match.start())
                named_actor = re.search(
                    r"公司下属控股公司([\u4e00-\u9fff]{2,40}?有限公司)主要从事",
                    excerpt[: match.end()],
                )
                if named_actor:
                    actor = named_actor[1]
                elif "本集团" in sentence:
                    actor = "本集团"
            if source_delivery_repair:
                clause = re.split(
                    r"[”\"](?:七大|等)|为代表的产品|，众多经典药品", clause, maxsplit=1
                )[0]
                if re.search(
                    r"(?:内科、外科、妇科、儿科|对冲周期风险|挖掘全链条价值)", clause
                ):
                    continue
                # A product list ends when the source changes to upstream or
                # downstream firms. Their objects are not the company's products.
                clause = re.split(
                    r"[，,](?:上游|下游)(?:企业|客户|为)", clause, maxsplit=1
                )[0]
            if source_delivery_repair:
                clause = re.split(r"[，,]产品行销|等产品[，,]", clause, maxsplit=1)[0]
                clause = re.sub(r'[“"]([^”"]+)[”"]系列', "", clause)
            if source_delivery_repair and "远洋渔业捕捞、水产品加工销售" in clause:
                clause = clause.replace(
                    "远洋渔业捕捞、水产品加工销售", "水产品加工销售"
                )
            objects = _activity_object_clauses(clause)
            if (
                source_delivery_repair
                and "七大核心品类" in match.group(1)
                and "、铝、" in clause
            ):
                objects = [*objects, "铝"]
            for raw in objects:
                object_name, action, source_verb = _object_and_action(raw, verb)
                if core_answer_repair and _SPEC_OBJECT.match(object_name):
                    continue
                if source_delivery_repair and object_name.strip() in {
                    "销售",
                    "生产",
                    "建设",
                    "利用",
                    "运营与管理",
                }:
                    continue
                if source_delivery_repair and re.search(
                    r"为(?:主要)?原料$", re.sub(r"\s+", "", object_name)
                ):
                    continue
                if source_delivery_repair:
                    object_name = object_name.strip('“”"')
                key = re.sub(r"\s+", "", object_name)
                if not key or key in seen:
                    continue
                seen.add(key)
                records.append(
                    _base_fact(
                        Activity,
                        report=selection.report,
                        record_id=(
                            f"owned:{activity_item.evidence.evidence_id}"
                            f":activity:{len(seen)}"
                        ),
                        field_id="explicit_activity",
                        chapter_task=ChapterTask.EXTRACT_BUSINESS_OVERVIEW,
                        evidence=activity_item.evidence,
                        source_native=SourceNativeValue(name=object_name),
                        action=action,
                        activity_actor=actor,
                        source_actor=actor,
                        actor_basis=SubjectBasis.DIRECT_GRAMMATICAL_ACTOR,
                        object_name=object_name,
                        source_verb=source_verb,
                    )
                )
    if source_delivery_repair and activity_item is not None:
        steel = _steel_raw_material_binding(span.excerpt)
        if steel:
            records.append(
                _base_fact(
                    Activity,
                    report=selection.report,
                    record_id=(
                        f"owned:{activity_item.evidence.evidence_id}"
                        ":activity:steel-raw-material"
                    ),
                    field_id="explicit_activity",
                    chapter_task=ChapterTask.EXTRACT_BUSINESS_OVERVIEW,
                    evidence=activity_item.evidence,
                    source_native=SourceNativeValue(
                        name=steel["name"],
                        value=steel.get("value"),
                        unit=steel.get("unit"),
                        header=steel.get("header"),
                    ),
                    action=steel["action"],
                    activity_actor=steel["actor"],
                    source_actor=steel["actor"],
                    actor_basis=SubjectBasis.DIRECT_GRAMMATICAL_ACTOR,
                    object_name=steel["name"],
                    source_verb=steel["verb"],
                    excerpt_subject=span.excerpt,
                )
            )
    return tuple(records)


def _project_segment_span(
    selection: CoreEvidenceSelection,
    span: CoreEvidenceSpan,
    *,
    core_answer_repair: bool = False,
    source_delivery_repair: bool = False,
) -> tuple[SemanticRecord, ...]:
    if not span.context_complete:
        return ()
    if source_delivery_repair:
        if span.section_title in {
            "收入和成本分析",
            "主营业务分行业、分产品、分地区、分销售模式情况",
        } and any(
            sp.section_title == "主营业务原表"
            and bool(_physical_main_income_rows(sp.excerpt))
            and span.page in (sp.page, *sp.continuation_pages)
            for sp in selection.spans
        ):
            return ()
        native = _project_native_income_span(selection, span)
        if native is not None:
            return native
    segment_item = _prepared_for(selection, span, "segment_dimension")
    revenue_item = _prepared_for(selection, span, "operating_revenue")
    if segment_item is None and revenue_item is None:
        return ()
    if source_delivery_repair and not re.search("营业收入|结算收入", span.excerpt):
        return ()
    excerpt = _join_rmb_column_header(_join_pdf_soft_breaks(span.excerpt))
    excerpt = _join_segment_label_amounts(
        excerpt,
        core_answer_repair=core_answer_repair,
    )
    quote = (
        segment_item.evidence.anchor.bounded_quote
        if segment_item is not None
        and isinstance(segment_item.evidence.anchor, TextAnchor)
        else ""
    )
    if revenue_item is not None and isinstance(
        revenue_item.evidence.anchor, TextAnchor
    ):
        quote = quote or revenue_item.evidence.anchor.bounded_quote
    if core_answer_repair:
        quote = _join_segment_label_amounts(
            _join_pdf_soft_breaks(quote),
            core_answer_repair=True,
        )
    # The bounded quote carries the passage's own group wording (本集团…), which
    # the acceptance policy checks; bind the subject from that same text —
    # unless the table itself shows a narrower scope such as 母公司, which the
    # group narrative must not lift.
    subject_text = span.excerpt
    if quote and not re.search(r"母公司", span.excerpt):
        subject_text = f"{span.excerpt}\n{quote}"
    column_unit = (
        "百万元"
        if source_delivery_repair and "人民币百万元" in re.sub(r"\s+", "", excerpt)
        else None
    )
    unit = column_unit
    previous_was_unit = False
    group_dimensions: frozenset[str] | None = None
    dimension = _dimension_from_heading(span.section_title)
    revenue_parent = ""
    records: list[SemanticRecord] = []
    started = False
    lines = excerpt.splitlines()
    last_heading_offset = -1
    native_table_header = ""
    for offset, line in enumerate(lines):
        if started and _is_revenue_table_stop(line):
            break
        if source_delivery_repair and re.search(
            r"主营业务分(?:行业|产品|地区).*情况的说明", line
        ):
            # Margin commentary repeats labels and percentages, not revenue.
            break
        if not line.strip():
            continue
        if source_delivery_repair:
            if "主营业务收入构成" in line:
                native_table_header = "主营业务收入构成"
            elif re.search(r"主营业务分(?:行业|产品|地区|销售)", line):
                native_table_header = "主营业务收入"
        declared = _unit_from_excerpt(line)
        if declared is not None and _UNIT_DECLARATION.search(line):
            unit = declared
            previous_was_unit = True
            continue
        opened = _open_segment_group(line)
        if opened is not None:
            if not previous_was_unit:
                unit = _table_intro_unit(lines, offset)
            group_dimensions = opened
            previous_was_unit = False
            started = True
            last_heading_offset = offset
            continue
        if (
            _dimension_from_heading(line) is not None
            or _parse_segment_row(line) is not None
        ):
            started = True
        if source_delivery_repair and "房地产业务分地区情况表" in re.sub(
            r"\s+", "", line
        ):
            dimension = "region"
            group_dimensions = None
            native_table_header = "房地产业务分地区/结算收入"
            unit = _table_intro_unit(lines, offset)
            last_heading_offset = offset
            continue
        section = _dimension_from_heading(line)
        if section is not None:
            revenue_parent = ""
            if group_dimensions is not None and section in group_dimensions:
                previous_was_unit = False
                dimension = section
                last_heading_offset = offset
                continue
            group_dimensions = None
            if not previous_was_unit:
                unit = _table_intro_unit(lines, offset) or (
                    unit
                    if source_delivery_repair
                    and ("主营业务" in line or "主营业务收入构成" in excerpt)
                    else None
                )
            native_table_header = (
                "主营业务收入"
                if "主营业务" in line
                else native_table_header
                if source_delivery_repair
                and native_table_header in {"主营业务收入构成", "主营业务收入"}
                else ""
            )
            previous_was_unit = False
            dimension = section
            last_heading_offset = offset
            continue
        if group_dimensions is not None and _is_enumerated_revenue_class(line):
            group_dimensions = None
            if not previous_was_unit:
                unit = _table_intro_unit(lines, last_heading_offset)
        previous_was_unit = False
        parsed = _parse_segment_row(line)
        if parsed is None and source_delivery_repair and dimension:
            total = re.match(
                r"\s*(主营业务(?:收入)?合计|合计)\s+(\d[\d,]*\.\d{2})\s+", line
            )
            if total:
                parsed = (total[1], total[2], None)
        if parsed is None and source_delivery_repair and "主营业务收入构成" in excerpt:
            total = re.match(r"\s*(主营业务收入合计)\s+(\d[\d,]*\.\d{2})\s+", line)
            if total:
                parsed = (total[1], total[2], None)
                dimension = "industry"
                native_table_header = "主营业务收入构成"
        if parsed is None:
            continue
        label, amount, _share = parsed
        row_dimension = (
            "revenue_composition" if _is_enumerated_revenue_class(line) else dimension
        )
        row_header = native_table_header or None
        if (
            source_delivery_repair
            and row_dimension in {"product", "region"}
            and last_heading_offset >= 0
            and "主营业务" in lines[last_heading_offset]
        ):
            row_header = "主营业务收入"
        if source_delivery_repair and label.endswith("小计"):
            row_dimension = "total"
        if core_answer_repair and label in _REVENUE_PARENT_LABELS:
            row_dimension = "revenue_composition"
            revenue_parent = label
        elif (
            core_answer_repair
            and row_dimension == "revenue_composition"
            and revenue_parent
        ):
            row_header = revenue_parent
        if row_dimension is None:
            continue
        source_line = line.strip()
        if not _stated_in_quote(source_line, quote or span.excerpt):
            continue
        if segment_item is not None:
            records.append(
                _base_fact(
                    Segment,
                    report=selection.report,
                    record_id=(
                        f"owned:{segment_item.evidence.evidence_id}"
                        f":segment:{row_dimension}:{label}"
                        + (
                            f":table:{row_header}:row:{offset}"
                            if source_delivery_repair
                            else ""
                        )
                    ),
                    field_id="segment_dimension",
                    chapter_task=ChapterTask.EXTRACT_SEGMENT_FINANCIALS,
                    evidence=segment_item.evidence,
                    source_native=SourceNativeValue(
                        name=label,
                        value=amount,
                        unit=unit,
                        header=row_header,
                        qualifier="小计" if row_dimension == "total" else None,
                    ),
                    dimension=row_dimension,
                    label=label,
                    excerpt_subject=subject_text,
                )
            )
        if revenue_item is not None and unit:
            records.append(
                _base_fact(
                    Measurement,
                    report=selection.report,
                    record_id=(
                        f"owned:{revenue_item.evidence.evidence_id}"
                        f":revenue:{row_dimension}:{label}"
                        + (
                            f":table:{row_header}:row:{offset}"
                            if source_delivery_repair
                            else ""
                        )
                    ),
                    field_id="operating_revenue",
                    chapter_task=ChapterTask.EXTRACT_SEGMENT_FINANCIALS,
                    evidence=revenue_item.evidence,
                    source_native=SourceNativeValue(
                        name=label,
                        value=amount,
                        unit=unit,
                        header=row_header,
                        qualifier="小计" if row_dimension == "total" else None,
                    ),
                    metric_type=MetricType.OPERATING_REVENUE,
                    logical_slot=LogicalSlot.REVENUE,
                    measured_object=label,
                    segment_dimension=row_dimension,
                    segment_label=label,
                    excerpt_subject=subject_text,
                )
            )
    return tuple(records)


_COMPANY_TOTAL_LABELS = frozenset({"营业收入合计", "营业总收入"})
_INCOME_AMOUNT_LABELS = frozenset({"营业收入", "利息净收入"})
_INCOME_SHARE_LABELS = frozenset({"利息净收入"})
_INCOME_ITEM_DIMENSION = "income_item"
_FORBIDDEN_INCOME_LABELS = frozenset(
    {
        "净息差",
        "净利息收益率",
        "成本收入比",
        "贷款总额",
        "贷款利息收入",
        "投资利息收入",
        "业务总收入",
    }
)
_INCOME_ANALYSIS_STOP_HEADINGS = (
    "利息净收入",
    "净息差",
    "手续费及佣金净收入",
    "分行业",
    "分产品",
    "分地区",
    "分销售模式",
    "营业成本构成",
)
_AMOUNT_TOKEN = re.compile(r"-?[\d,]+(?:\.\d+)?")
_SHARE_TOKEN = re.compile(r"-?[\d.]+")
_TABLE_BLOCK_SPLIT = re.compile(r"(?=(?:下表|单位[:：]))")
_BUSINESS_TOTAL_MARK = re.compile(r"业务总收入")
_COMPOSITION_MARK = re.compile(r"营业收入构成|占营业收入百分比")
_REGION_TABLE_MARK = re.compile(r"地区分部|分地区")


def _project_company_total_rows(
    selection: CoreEvidenceSelection,
    span: CoreEvidenceSpan,
) -> tuple[SemanticRecord, ...]:
    revenue_item = _prepared_for(selection, span, "operating_revenue")
    if revenue_item is None:
        return ()
    excerpt = _join_pdf_soft_breaks(span.excerpt)
    quote = (
        revenue_item.evidence.anchor.bounded_quote
        if isinstance(revenue_item.evidence.anchor, TextAnchor)
        else span.excerpt
    )
    unit = _unit_from_excerpt(excerpt)
    if not unit:
        return ()
    records: list[SemanticRecord] = []
    for line in excerpt.splitlines():
        parsed = _parse_labeled_amount_row(line, _COMPANY_TOTAL_LABELS)
        if parsed is None:
            continue
        label, amount = parsed
        if not _stated_in_quote(line.strip(), quote or span.excerpt):
            continue
        records.append(
            _company_total_measurement(
                selection,
                revenue_item,
                label=label,
                amount=amount,
                unit=unit,
                excerpt=excerpt,
            )
        )
    return tuple(records)


def _project_income_analysis_span(
    selection: CoreEvidenceSelection,
    span: CoreEvidenceSpan,
) -> tuple[SemanticRecord, ...]:
    revenue_item = _prepared_for(selection, span, "operating_revenue")
    if revenue_item is None:
        return ()
    excerpt = _clip_income_analysis_excerpt(_join_pdf_soft_breaks(span.excerpt))
    quote = (
        revenue_item.evidence.anchor.bounded_quote
        if isinstance(revenue_item.evidence.anchor, TextAnchor)
        else span.excerpt
    )
    records: list[SemanticRecord] = []
    parts = [part.strip() for part in _TABLE_BLOCK_SPLIT.split(excerpt) if part.strip()]
    for index, block in enumerate(parts):
        context = f"{parts[index - 1]}\n{block}" if index else block
        if _BUSINESS_TOTAL_MARK.search(context):
            continue
        if re.search(r"地区分部", context) and not _COMPOSITION_MARK.search(context):
            continue
        unit = _first_declared_unit(block)
        if unit == "%":
            if not _COMPOSITION_MARK.search(context):
                continue
            records.extend(
                _project_income_share_block(
                    selection,
                    revenue_item,
                    block=block,
                    quote=quote or span.excerpt,
                    excerpt=excerpt,
                )
            )
            continue
        if not unit:
            continue
        records.extend(
            _project_income_amount_block(
                selection,
                revenue_item,
                block=block,
                unit=unit,
                quote=quote or span.excerpt,
                excerpt=excerpt,
            )
        )
    return tuple(records)


def _project_income_amount_block(
    selection: CoreEvidenceSelection,
    revenue_item,
    *,
    block: str,
    unit: str,
    quote: str,
    excerpt: str,
) -> tuple[SemanticRecord, ...]:
    records: list[SemanticRecord] = []
    for line in block.splitlines():
        parsed = _parse_labeled_amount_row(
            line, _COMPANY_TOTAL_LABELS | _INCOME_AMOUNT_LABELS
        )
        if parsed is None:
            continue
        label, amount = parsed
        if label in _FORBIDDEN_INCOME_LABELS:
            continue
        if not _stated_in_quote(line.strip(), quote):
            continue
        if label in _COMPANY_TOTAL_LABELS or label == "营业收入":
            records.append(
                _company_total_measurement(
                    selection,
                    revenue_item,
                    label=label,
                    amount=amount,
                    unit=unit,
                    excerpt=excerpt,
                )
            )
            continue
        if label in _INCOME_SHARE_LABELS:
            records.append(
                _income_item_measurement(
                    selection,
                    revenue_item,
                    label=label,
                    amount=amount,
                    unit=unit,
                    excerpt=excerpt,
                )
            )
    return tuple(records)


def _project_income_share_block(
    selection: CoreEvidenceSelection,
    revenue_item,
    *,
    block: str,
    quote: str,
    excerpt: str,
) -> tuple[SemanticRecord, ...]:
    records: list[SemanticRecord] = []
    for line in block.splitlines():
        parsed = _parse_labeled_share_row(line, _INCOME_SHARE_LABELS)
        if parsed is None:
            continue
        label, share = parsed
        if not _stated_in_quote(line.strip(), quote):
            continue
        records.append(
            _income_share_measurement(
                selection,
                revenue_item,
                label=label,
                share=share,
                excerpt=excerpt,
            )
        )
    return tuple(records)


def _company_total_measurement(
    selection: CoreEvidenceSelection,
    revenue_item,
    *,
    label: str,
    amount: str,
    unit: str,
    excerpt: str,
) -> Measurement:
    return _base_fact(
        Measurement,
        report=selection.report,
        record_id=(
            f"owned:{revenue_item.evidence.evidence_id}:revenue:company_total:{label}"
        ),
        field_id="operating_revenue",
        chapter_task=ChapterTask.EXTRACT_SEGMENT_FINANCIALS,
        evidence=revenue_item.evidence,
        source_native=SourceNativeValue(name=label, value=amount, unit=unit),
        metric_type=MetricType.OPERATING_REVENUE,
        logical_slot=LogicalSlot.REVENUE,
        measured_object=label,
        excerpt_subject=excerpt,
    )


def _income_item_measurement(
    selection: CoreEvidenceSelection,
    revenue_item,
    *,
    label: str,
    amount: str,
    unit: str,
    excerpt: str,
) -> Measurement:
    return _base_fact(
        Measurement,
        report=selection.report,
        record_id=(
            f"owned:{revenue_item.evidence.evidence_id}"
            f":revenue:{_INCOME_ITEM_DIMENSION}:{label}"
        ),
        field_id="operating_revenue",
        chapter_task=ChapterTask.EXTRACT_SEGMENT_FINANCIALS,
        evidence=revenue_item.evidence,
        source_native=SourceNativeValue(name=label, value=amount, unit=unit),
        metric_type=MetricType.OPERATING_REVENUE,
        logical_slot=LogicalSlot.REVENUE,
        measured_object=label,
        segment_dimension=_INCOME_ITEM_DIMENSION,
        segment_label=label,
        excerpt_subject=excerpt,
    )


def _income_share_measurement(
    selection: CoreEvidenceSelection,
    revenue_item,
    *,
    label: str,
    share: str,
    excerpt: str,
) -> Measurement:
    return _base_fact(
        Measurement,
        report=selection.report,
        record_id=(f"owned:{revenue_item.evidence.evidence_id}:share:{label}:营业收入"),
        field_id="operating_revenue",
        chapter_task=ChapterTask.EXTRACT_SEGMENT_FINANCIALS,
        evidence=revenue_item.evidence,
        source_native=SourceNativeValue(
            name=f"{label} / 营业收入",
            value=share,
            unit="%",
        ),
        metric_type=MetricType.DISCLOSED_SHARE,
        logical_slot=LogicalSlot.DISCLOSED_SHARE,
        measured_object=label,
        relationship_context="营业收入",
        excerpt_subject=excerpt,
    )


def _parse_labeled_amount_row(
    line: str,
    labels: frozenset[str],
) -> tuple[str, str] | None:
    text = line.strip()
    if not text:
        return None
    tokens = text.split()
    if len(tokens) < 2:
        return None
    label = tokens[0]
    if label not in labels or not _AMOUNT_TOKEN.fullmatch(tokens[1]):
        return None
    return label, tokens[1]


def _parse_labeled_share_row(
    line: str,
    labels: frozenset[str],
) -> tuple[str, str] | None:
    text = line.strip()
    if not text:
        return None
    tokens = text.split()
    if len(tokens) < 2:
        return None
    label = tokens[0]
    if label not in labels or not _SHARE_TOKEN.fullmatch(tokens[1]):
        return None
    return label, tokens[1]


def _income_analysis_excerpt_ready(excerpt: str) -> bool:
    text = _clip_income_analysis_excerpt(_join_pdf_soft_breaks(excerpt))
    if _first_declared_unit(text) is None:
        return False
    for line in text.splitlines():
        if _parse_labeled_amount_row(
            line, _COMPANY_TOTAL_LABELS | _INCOME_AMOUNT_LABELS
        ) or _parse_labeled_share_row(line, _INCOME_SHARE_LABELS):
            return True
    return False


_MDA_REVENUE_HEADINGS = frozenset(
    {"收入和成本分析", "主营业务分行业情况", "主营业务分产品情况"}
)


def _formal_segment_table_ready(excerpt: str) -> bool:
    """Require a unit plus either a segment heading or an enumerated class row."""

    normalized = _join_segment_label_amounts(
        _join_rmb_column_header(_join_pdf_soft_breaks(excerpt))
    )
    if _unit_from_excerpt(normalized) is None:
        return False
    dimension = None
    started = False
    for line in normalized.splitlines():
        if started and _is_revenue_table_stop(line):
            break
        section = _dimension_from_heading(line)
        if section is not None:
            dimension = section
            started = True
            continue
        if _parse_segment_row(line) is None:
            continue
        if dimension is not None or _is_enumerated_revenue_class(line):
            return True
    return False


_REVENUE_TABLE_STOP_TITLES = (
    "成本分析",
    "产销量",
    "资产及负债",
    "费用",
    "分部报告",
    "分部信息",
    "主要销售客户",
    "重大采购",
)


def _is_revenue_table_stop(line: str) -> bool:
    compact = _HEADING_PREFIX.sub("", re.sub(r"\s+", "", line.strip()), count=1)
    compact = compact.lstrip(".．、")
    if "收入和成本" in compact:
        return False
    return any(title in compact for title in _REVENUE_TABLE_STOP_TITLES)


def _is_enumerated_revenue_class(line: str) -> bool:
    # "18.40" is a decimal amount, not an enumeration mark: the character
    # after 、.． must not be a digit.
    return (
        re.match(r"\s*(?:[一二三四五六七八九十]+|\d+)[、.．](?!\d)", line) is not None
    )


def _join_segment_label_amounts(
    text: str,
    *,
    core_answer_repair: bool = False,
) -> str:
    """Attach a wrapped label to the amount line that follows it."""

    text = re.sub(r"中国\s*[(（]\s*含港澳\s*台\s*[)）]", "中国（含港澳台）", text)
    if core_answer_repair:
        text = re.sub(r"(\.\d{2})(?=-?\d)", r"\1 ", text)
    if core_answer_repair:
        text = re.sub(
            r"(?m)^([\u4e00-\u9fff]{2,15})\n([\u4e00-\u9fff]{1,4})\s+(?=\d[\d,]*\.\d)",
            lambda m: (
                m.group()
                if m[1].endswith("百分点") or m[2] == "合计"
                else m[1] + m[2] + " "
            ),
            text,
        )
    if core_answer_repair:
        text = re.sub(
            r"(?m)^\s*([\u4e00-\u9fff]+[（(][^）)\n]+[)）])\s*\n\s*([\u4e00-\u9fff]{1,4})\s+(?=\d[\d,]*\.\d)",
            r"\1\2 ",
            text,
        )
        text = re.sub(r"直销\s*[（(]含团\s*购[)）]", "直销（含团购）", text)
        text = re.sub(r"批发\s*代\s*理[—-]\s*经\s*销商", "批发代理—经销商", text)
        text = re.sub(r"主营业\s*务合计", "主营业务合计", text)
    if core_answer_repair:
        text = re.sub(
            r"(?m)^毛利率比上年增减[（(]%[）)]\s*(?=[\u4e00-\u9fff]+\s+\d)", "", text
        )
    lines = [line for line in text.splitlines() if line.strip()]
    if core_answer_repair:
        for i in range(len(lines) - 1):
            m = re.match(
                r"(\s*[(（]\d+[)）]\s*[^\d]+?)(\s+\d[\d,]*\.\d{2}.*)$", lines[i]
            )
            tail = lines[i + 1].strip()
            if (
                m
                and re.fullmatch(r"[\u4e00-\u9fff]{1,10}", tail)
                and not re.search(r"合计|小计|营业|毛利|分行业|分产品", tail)
            ):
                lines[i] = re.sub(r"\s+", "", m[1]) + tail + m[2]
                lines[i + 1] = ""
    if core_answer_repair:
        # A row label and the final margin cell can both continue after a
        # page header: 上海 <amounts> / <header> / 地区 个百分点.
        # Only this explicit trailing label cell is joined, never a new row.
        for row_index, line in enumerate(lines):
            parsed = _parse_segment_row(line)
            if parsed is None or parsed[0].endswith("地区"):
                continue
            cursor = row_index + 1
            while cursor < len(lines) and cursor <= row_index + 4:
                following = lines[cursor].strip()
                if (
                    not following
                    or "年度报告" in following
                    or re.fullmatch(r"\d+\s*/\s*\d+", following)
                ):
                    cursor += 1
                    continue
                if re.fullmatch(r"地区\s+个百分点", following):
                    lines[row_index] = line.replace(parsed[0], parsed[0] + "地区", 1)
                    lines[cursor] = "个百分点"
                break
    if core_answer_repair:
        for i in range(len(lines) - 1):
            m = re.match(
                r"\s*(?P<label>[^\d\n]+?)\s+(?P<amount>\d[\d,]*\.\d{2})", lines[i]
            )
            if m and re.fullmatch(
                r"[\u4e00-\u9fff（）()]+", re.sub(r"\s+", "", m["label"])
            ):
                tail = re.match(
                    r"\s*(?P<tail>[\u4e00-\u9fff]{1,8})(?:\s{2,}个百分点|\s*)$",
                    lines[i + 1],
                )
                if (
                    tail
                    and tail["tail"] not in {"个百分点", "合计"}
                    and not _dimension_from_heading(lines[i + 1])
                    and "合计" not in m["label"]
                    and not (
                        i + 2 < len(lines)
                        and re.match(r"\s*-?\d[\d,]*\.\d", lines[i + 2])
                    )
                ):
                    lines[i] = lines[i].replace(
                        m["label"], re.sub(r"\s+", "", m["label"]) + tail["tail"], 1
                    )
                    lines[i + 1] = ""
    merged: list[str] = []
    index = 0
    while index < len(lines):
        if core_answer_repair:
            joined_at = _join_numbered_revenue_label(lines, index)
            if joined_at is not None:
                merged.append(joined_at[0])
                index = joined_at[1]
                continue
        current = lines[index]
        if core_answer_repair and re.match(
            r"\s*(?:华东|华北|华中|东北|西北|西南)[：:]", current
        ):
            parts = []
            cursor = index
            while cursor < len(lines):
                line = lines[cursor]
                if cursor > index and re.match(
                    r"\s*(?:华东|华北|华中|东北|西北|西南)[：:]", line
                ):
                    break
                if re.search(r"\d[\d,]*\.\d+", line):
                    number = re.search(r"\d[\d,]*\.\d+", line)
                    merged.append(
                        "".join(parts)
                        + re.sub(r"\s+", "", line[: number.start()])
                        + " "
                        + line[number.start() :].strip()
                    )
                    index = cursor + 1
                    break
                parts.append(re.sub(r"\s+", "", line))
                cursor += 1
            if index == cursor + 1:
                continue
        if core_answer_repair and index + 2 < len(lines):
            label_parts = [
                re.sub(r"\s+", "", part) for part in lines[index : index + 2]
            ]
            if (
                all(
                    re.fullmatch(r"[\u4e00-\u9fffA-Za-z]{2,20}", part)
                    for part in label_parts
                )
                and re.match(r"\s*-?[\d,]+\.", lines[index + 2])
                and not any(
                    re.search(r"营业|增减|百分点|毛利|报告", part)
                    for part in label_parts
                )
            ):
                merged.append("".join(label_parts) + " " + lines[index + 2].strip())
                index += 3
                continue
        nxt = lines[index + 1] if index + 1 < len(lines) else ""
        compact_label = re.sub(r"\s+", "", current)
        next_row = _parse_segment_row(nxt) if core_answer_repair else None
        if (
            next_row is not None
            and (
                next_row[0] in {"行业", "地区"}
                or (compact_label == "在某一时点" and next_row[0] == "确认")
                or ("、" in compact_label and next_row[0] == "产及供应")
                or re.match(r"[A-Z]{2,}[\u4e00-\u9fff]*$", next_row[0])
                or (
                    re.fullmatch(r"[\u4e00-\u9fffA-Za-z、（）()]{2,20}", compact_label)
                    and not _dimension_from_heading(current)
                    and not re.search(r"增减|毛利|报告|百分点|营业", current)
                )
            )
            and re.fullmatch(r"[\u4e00-\u9fffA-Za-z、（）()]{1,20}", compact_label)
            and not compact_label.endswith("百分点")
        ):
            merged.append(f"{compact_label}{nxt.strip()}")
            index += 2
            continue
        if (
            re.fullmatch(r"[\u4e00-\u9fffA-Za-z0-9/、（）()—-]{2,40}", compact_label)
            and not compact_label.endswith("百分点")
            and re.match(r"\s*-?[\d,]", nxt)
        ):
            merged.append(f"{compact_label} {nxt.strip()}")
            index += 2
            continue
        merged.append(current)
        index += 1
    return "\n".join(merged)


def _join_numbered_revenue_label(
    lines: list[str],
    index: int,
) -> tuple[str, int] | None:
    """Join “旅客及货邮航空 / 服务收入” onto the amount line."""

    current = lines[index]
    if not re.match(r"\s*(?:\d+[、.．]|[(（]\d+[)）])", current) or re.search(
        r"-?[\d,]+\.\d", current
    ):
        return None
    parts = [re.sub(r"\s+", "", current)]
    cursor = index + 1
    while cursor < len(lines):
        nxt = lines[cursor]
        if re.match(r"\s*-?[\d,]", nxt):
            label = "".join(parts)
            return f"{label} {nxt.strip()}", cursor + 1
        if not nxt.strip():
            cursor += 1
            continue
        row = _parse_segment_row(nxt)
        if row is not None:
            return "".join(parts) + nxt.strip(), cursor + 1
        if re.fullmatch(r"\s*[\u4e00-\u9fff]{2,12}\s*", nxt):
            parts.append(re.sub(r"\s+", "", nxt))
            cursor += 1
            continue
        return None
    return None


def _clip_before_later_segment_template(excerpt: str) -> str:
    """Keep the MD&A revenue table and stop at the next non-revenue section."""

    kept: list[str] = []
    table_started = False
    for line in excerpt.splitlines():
        # Explanations before the table (e.g. 折旧费用同比增加) are not its tail.
        if table_started and _is_revenue_table_stop(line):
            break
        kept.append(line)
        table_started = table_started or _dimension_from_heading(line) is not None
    return "\n".join(kept).strip()


def _clip_income_analysis_excerpt(excerpt: str) -> str:
    kept: list[str] = []
    for line in excerpt.splitlines():
        heading = _heading_if_title_line(line, _INCOME_ANALYSIS_STOP_HEADINGS)
        if heading is not None and kept:
            break
        if kept and _BUSINESS_TOTAL_MARK.search(line):
            break
        if kept and re.search(r"地区分部", line) and not _COMPOSITION_MARK.search(line):
            break
        kept.append(line)
    return "\n".join(kept)


def _first_declared_unit(text: str) -> str | None:
    percent = _PERCENT_UNIT.search(text)
    money = _UNIT_DECLARATION.search(text)
    if percent is not None and (money is None or percent.start() <= money.start()):
        return "%"
    if money is not None:
        return money.group(1)
    return None


def _subject_from_excerpt(excerpt: str) -> tuple[SubjectScope, SubjectBasis | None]:
    # An explicit narrower local scope (母公司口径 tables) wins over the
    # group narrative that the same page may also carry.
    if "母公司财务报表" in excerpt:
        return SubjectScope.ISSUER, SubjectBasis.DIRECT_SOURCE_WORDING
    if re.search(r"本集团", excerpt):
        return SubjectScope.CONSOLIDATED_GROUP, SubjectBasis.DIRECT_SOURCE_WORDING
    if re.search(r"母公司", excerpt):
        return SubjectScope.UNCLEAR, None
    return SubjectScope.UNCLEAR, None


def _dedupe_owned_records(
    records: list[SemanticRecord],
) -> tuple[SemanticRecord, ...]:
    seen: set[tuple[object, ...]] = set()
    unique: list[SemanticRecord] = []
    for record in records:
        if isinstance(record, BusinessOverview):
            key = (record.object_type, re.sub(r"\s+", "", record.source_text))
            if key in seen:
                continue
            seen.add(key)
        if isinstance(record, Measurement):
            key = (
                record.metric_type,
                record.measured_object,
                record.source_native.value,
                record.source_native.unit,
                record.source_native.header,
                record.segment_dimension,
                record.segment_label,
                record.relationship_context,
                record.source_native.qualifier,
                record.subject_scope,
            )
            if key in seen:
                continue
            seen.add(key)
        if isinstance(record, Activity) and record.action == ActivityAction.SELLS:
            name = re.sub(r"\s+", "", record.object_name)
            duplicate = next(
                (
                    i
                    for i, prior in enumerate(unique)
                    if isinstance(prior, Activity)
                    and prior.action == ActivityAction.SELLS
                    and prior.source_native.value is None
                    and record.source_native.value is None
                    and prior.source_native.header == record.source_native.header
                    and prior.source_actor == record.source_actor
                    and prior.source_native.qualifier == record.source_native.qualifier
                    and (
                        name == re.sub(r"\s+", "", prior.object_name)
                        or name.startswith(re.sub(r"\s+", "", prior.object_name) + "(")
                        or re.sub(r"\s+", "", prior.object_name).startswith(name + "(")
                    )
                ),
                None,
            )
            if duplicate is not None:
                prior = unique[duplicate]
                preferred = (
                    record
                    if len(name) > len(re.sub(r"\s+", "", prior.object_name))
                    else prior
                )
                evidence_by_id = {
                    item.evidence_id: item
                    for item in (*prior.evidence, *record.evidence)
                }
                updates = {"evidence": tuple(evidence_by_id.values())}
                for candidate in (prior, record):
                    if candidate.source_actor and candidate.source_actor != "公司":
                        updates.update(
                            source_actor=candidate.source_actor,
                            activity_actor=candidate.activity_actor,
                            subject_scope=candidate.subject_scope,
                            subject_basis=candidate.subject_basis,
                        )
                unique[duplicate] = preferred.model_copy(update=updates)
                continue
        unique.append(record)
    return tuple(unique)


_MATERIAL_NAME = r"[\u4e00-\u9fffA-Za-z]{1,8}"
_COMPANY_PROCUREMENT = re.compile(
    rf"(?:本公司|公司)(?:向[\u4e00-\u9fff]{{1,8}})?"
    rf"(?:采购|购入|消耗|投入)(?:了)?({_MATERIAL_NAME})"
    rf"(?:用于(?:生产|制造|经营)|作为(?:原材料|原料|投入))"
)
_COMPANY_INPUT_COST = re.compile(
    r"(?:直接)?(?:推高|抬高|提高|增加)"
    r"(?P<gap>.{0,8})(?:制造|生产|经营)成本"
)
_THIRD_PARTY_COST = re.compile(r"下游|客户|供应商|制造企业|生产企业")
_NOT_A_MATERIAL_NAME = re.compile(r"销售|出售|客户|供应商|下游|企业|价格|风险|公司")
_GENERIC_MATERIAL_NAMES = frozenset(
    {"材料", "原材料", "原料", "原燃料", "燃料", "能源", "直接材料", "存货"}
)


_REPAIR_SALES = (
    ("钢铁", ("钢铁产品", "钢铁")),
    ("稀土精矿", ("稀土精矿",)),
    ("萤石", ("萤石精矿", "萤石")),
    ("焦化产品", ("焦化产品", "冶金焦炭")),
    ("焦化副产品", ("焦化副产品",)),
    ("焦炭", ("焦炭",)),
)
_REPAIR_PROCUREMENT = ("铁矿石", "白灰", "石灰石", "进口矿", "焦炭")
_REPAIR_ENERGY = (("蒸汽", "蒸汽费"), ("热水", "热水费"), ("电", "电费"))
_REPAIR_COMMODITY_CUE = re.compile(
    r"采购|销售|畅销|量产出货|批量出货|主要上游原材料|耗用量|蒸汽费|热水费|电费|生产与销售|原辅料|焦炭采购"
)
_SERVICE_ENERGY_CUE = re.compile(r"电耗|柴油单耗|燃油消耗|供电煤耗|发电厂用电率")
_OPERATING_ENERGY = re.compile(
    r"(?P<business>污水|焚烧业务)(?:吨水药耗、)?(?P<item>电耗|柴油单耗)"
)
_FIRM_ENDING = re.compile(r"[\u4e00-\u9fffA-Za-z0-9]{0,40}公司")


def _repair_commodity_spans(
    pages: Sequence[ReportPageText],
    *,
    covered: Sequence[CoreEvidenceSpan],
    service_operating_energy: bool = False,
) -> list[CoreEvidenceSpan]:
    covered_pages = {span.page for span in covered if span.field_ids}
    spans: list[CoreEvidenceSpan] = []
    for page in pages:
        if not page.readable:
            continue
        company_table = "主要控股参股公司分析" in page.text and "公司名称" in page.text
        if page.page in covered_pages and not (
            company_table
            or "企业集团的构成" in page.text
            and "业务性质" in page.text
            or _operating_energy_bindings(page.text)
            or _explicit_current_commodity_bindings(page.layout_text or page.text)
            or _native_branch_action_bindings(page.layout_text or page.text)
            or re.search(r"注\s*\d+：[^。]+成立于", page.text)
            or _native_input_bindings(page.text)
            or _native_current_product_bindings(page.text)
            or _company_trade_sales_product_names(page.text)
            and not any(
                _company_trade_sales_product_names(span.excerpt)
                for span in covered
                if page.page in (span.page, *span.continuation_pages)
            )
            or _formal_sales_product_names(page.text, owned_products=True)
            and not any(
                _formal_sales_product_names(span.excerpt, owned_products=True)
                for span in covered
                if page.page in (span.page, *span.continuation_pages)
            )
        ):
            continue
        compact = re.sub(r"\s+", "", page.text)
        commodity = (
            company_table
            or _REPAIR_COMMODITY_CUE.search(compact) is not None
            or bool(_explicit_current_commodity_bindings(page.layout_text or page.text))
            or bool(_native_input_bindings(page.text))
            or bool(_native_branch_action_bindings(page.layout_text or page.text))
            or "企业集团的构成" in compact
            and "业务性质" in compact
        )
        energy = (
            service_operating_energy and _SERVICE_ENERGY_CUE.search(compact) is not None
        )
        hedge = "套期保值" in compact and "原料的期货业务" in compact
        if not commodity and not energy and not hedge:
            continue
        excerpt = (page.layout_text or page.text).strip()
        continuations: tuple[int, ...] = ()
        previous = next((p for p in pages if p.page == page.page - 1), None)
        if (
            previous
            and "主要控股参股公司分析" in previous.text
            and "公司名称" in page.text
        ):
            excerpt = "主要控股参股公司分析\n" + excerpt
            continuations = (previous.page,)
        nxt = next(
            (
                candidate
                for candidate in pages
                if candidate.page == page.page + 1 and candidate.readable
            ),
            None,
        )
        if previous and "母子公司" in excerpt and "产品说明" in excerpt:
            # The text extractor retains native merged-cell group order; the
            # centered layout label alone cannot establish its vertical extent.
            excerpt = previous.text + "\n" + page.text
            continuations = (previous.page,)
        if (
            nxt
            and "结转收入金额" in excerpt
            and "房地产企业出租房地产情况" not in excerpt
        ):
            excerpt += (
                "\n"
                + re.split(
                    r"[（(]\d+[)）]\.?房地产企业出租房地产情况",
                    nxt.layout_text or nxt.text,
                    maxsplit=1,
                )[0]
            )
            continuations = tuple(dict.fromkeys((*continuations, nxt.page)))
        if nxt and company_table and "报告期内取得和处置子公司的情况" not in excerpt:
            excerpt += "\n" + (nxt.layout_text or nxt.text)
            continuations = (nxt.page,)
        note_actor = re.search(
            r"注\s*\d+：([^。]+?)成立于", re.sub(r"\s+", "", excerpt)
        )
        if note_actor:
            # The note describes an investee; its scope needs the actual
            # ownership statement, not the fact that a company was founded.
            for context in pages:
                ownership = re.search(
                    r"截至报告日[^。]+"
                    + re.escape(note_actor[1])
                    + r"[^。]+参股项目[^。]+未纳入合并[^。]+。",
                    re.sub(r"\s+", "", context.text),
                )
                if ownership:
                    excerpt += "\n" + _original_span_matching(
                        context.text, ownership.group()
                    )
                    continuations = tuple(dict.fromkeys((*continuations, context.page)))
                    break
        if company_table:
            contexts = [
                p
                for p in pages
                if re.search(
                    r"公司主要从事[^。]+产销及贸易经营|母子公司\s+产品名称",
                    p.layout_text or p.text,
                )
            ]
            for context in contexts:
                excerpt += "\n" + (context.layout_text or context.text)
                continuations = tuple(dict.fromkeys((*continuations, context.page)))
        if (
            nxt
            and "生产量" in excerpt
            and "销售量" in excerpt
            and "产销量情况说明" not in excerpt
        ):
            tail = re.split(r"[（(]3[)）]", nxt.layout_text or nxt.text, maxsplit=1)[0]
            excerpt += "\n" + tail
            continuations = (nxt.page,)
        if nxt and (
            "采购商品/接受劳务情况表" in excerpt
            and "出售商品/提供劳务情况表" not in excerpt
            or "出售商品/提供劳务情况表" in excerpt
            and "购销商品、提供和接受劳务的关联交易说明" not in excerpt
        ):
            cursor = page.page + 1
            stop = (
                r"出售商品/提供劳务情况表"
                if "出售商品/提供劳务情况表" not in excerpt
                else r"购销商品、提供和接受劳务的关联交易说明"
            )
            while not re.search(stop, excerpt):
                following = next(
                    (p for p in pages if p.page == cursor and p.readable), None
                )
                if following is None or cursor > page.page + _MAX_SECTION_PAGES:
                    break
                excerpt += "\n" + (following.layout_text or following.text)
                continuations = tuple(dict.fromkeys((*continuations, cursor)))
                cursor += 1
        if nxt and (
            "报告期内公司从事的业务情况" in excerpt
            and "报告期内公司新增重要非主营业务" not in excerpt
            or "销售商品" in excerpt
            and re.search(r"自助缴费机采购项目", re.sub(r"\s+", "", nxt.text))
        ):
            excerpt += (
                "\n"
                + re.split(
                    r"报告期内公司新增重要非主营业务|十三、重大合同",
                    nxt.text,
                    maxsplit=1,
                )[0]
            )
            continuations = (nxt.page,)
        if (
            nxt
            and "④本公司及控股子公司为" in re.sub(r"\s+", "", excerpt)
            and "⑤本公司" not in re.sub(r"\s+", "", excerpt)
        ):
            excerpt += "\n" + nxt.text
            continuations = tuple(dict.fromkeys((*continuations, nxt.page)))
        if nxt and "企业集团的构成" in excerpt and "业务性质" in excerpt:
            excerpt += "\n" + (nxt.layout_text or nxt.text)
            continuations = tuple(dict.fromkeys((*continuations, nxt.page)))
        if nxt and "业务本期仅统计" in excerpt:
            ownership = next(
                (
                    s
                    for s in _owned_business_sources(nxt.text)
                    if "公司丧失" in s and "合并范围" in s
                ),
                "",
            )
            if ownership:
                excerpt += "\n" + ownership
                continuations = tuple(dict.fromkeys((*continuations, nxt.page)))
        performance = re.search(r"(?m)^\s*三、\s*经营情况讨论与分析", excerpt)
        if (
            nxt
            and performance
            and not _native_branch_action_bindings(excerpt[: performance.start()])
        ):
            excerpt = (
                excerpt[performance.start() :]
                + "\n"
                + re.split(r"[（(]二[)）]", nxt.text, maxsplit=1)[0]
            )
            continuations = (nxt.page,)
        if not excerpt:
            continue
        for definition_page in pages:
            if "释义" not in definition_page.text or " 指 " not in definition_page.text:
                continue
            definitions = [
                original
                for alias, _, original in _native_actor_definitions(
                    definition_page.text
                )
                if alias in re.sub(r"\s+", "", excerpt)
            ]
            if definitions:
                excerpt += "\n" + "\n".join(definitions)
                continuations = tuple(
                    dict.fromkeys((*continuations, definition_page.page))
                )
        spans.append(
            CoreEvidenceSpan(
                page=page.page,
                section_title="修复商品披露",
                continuation_pages=continuations,
                excerpt=excerpt,
                bounded_quote=excerpt,
                chapter_task=ChapterTask.EXTRACT_MATERIAL_INPUTS.value,
                field_ids=("explicit_activity",),
                dimension_ids=(),
            )
        )
    return spans


def _repair_commodity_clauses(excerpt: str) -> list[str]:
    """One clause per sentence or table row, after joining a PDF soft wrap.

    A line that ends with an enumeration comma continues the same sentence.
    Page 97 breaks “冶金机械、 / 设备及配件、焦炭及焦化副产品生产和销售”.
    """

    merged: list[str] = []
    for line in _join_pdf_soft_breaks(excerpt).split("\n"):
        if merged and merged[-1].rstrip().endswith(("、", "，", ",")):
            merged[-1] = f"{merged[-1].rstrip()}{line.lstrip()}"
        else:
            merged.append(line)
    clauses: list[str] = []
    for line in merged:
        for part in re.split(r"[。；;]", line):
            compact = re.sub(r"\s+", "", part).strip()
            if compact:
                clauses.append(compact)
    return clauses


def _sales_alias_in(stated: str, alias: str) -> bool:
    """Match a sales name without treating 冶金焦炭 as bare 焦炭."""

    if alias not in stated:
        return False
    return not (alias == "焦炭" and stated.count("焦炭") == stated.count("冶金焦炭"))


_ORG_NAME = re.compile(
    r"[\u4e00-\u9fffA-Za-z0-9（）()]{2,40}(?:股份有限公司|有限责任公司|有限公司)"
)


def _native_actor_definitions(text: str) -> list[tuple[str, str, str]]:
    """Read all aliases and a wrapped current legal name before former names."""
    text = text.replace("\r", "")
    definitions = []
    for m in re.finditer(
        r"(?m)^\s*(?P<aliases>[\u4e00-\u9fffA-Za-z、 ]{2,50})\s+指\s+[^\n]+\n\s*[（(](?P<name>[\u4e00-\u9fff•·（）()]+?公司)[）)]",
        text,
    ):
        for alias in m["aliases"].split("、"):
            definitions.append((re.sub(r"\s+", "", alias), m["name"], m.group()))
    for m in re.finditer(
        r"(?m)^\s*(?P<aliases>[\u4e00-\u9fffA-Za-z、]{2,50})[ \t]+指[ \t]*\n?[ \t]*"
        r"(?P<name>[\u4e00-\u9fffA-Za-z（）()]{2,60}?公司)",
        text,
    ):
        for alias in m["aliases"].split("、"):
            definitions.append((alias, m["name"], m.group()))
    compact = re.sub(r"\s+", "", text)
    for m in re.finditer(
        r'[“"]?(?P<name>[\u4e00-\u9fff]{2,40}?有限公司)[”"]?[^。；]{0,40}?(?:以下简称|以下简\s*称)[“"](?P<alias>[^”"]{2,30})[”"]',
        compact,
    ):
        name = m["name"]
        repeated = re.fullmatch(r"(.+有限公司)\1", name)
        definitions.append((m["alias"], repeated[1] if repeated else name, m.group()))
    known = {alias for alias, _, _ in definitions}
    for m in re.finditer(r"(?m)^[ \t]*([^\n]{1,80}?)[ \t]+指[ \t]+([^\n]+)", text):
        for alias in re.split(r"、|/|／", m[1]):
            alias = re.sub(r"\s+", "", alias)
            if alias not in known:
                definitions.append((alias, m[2].strip(), m.group()))
                known.add(alias)
    return definitions


def _clause_names_company(compact: str) -> bool:
    return re.search(r"(?:本公司|公司)", compact) is not None


def _without_org_names(compact: str) -> str:
    """Drop named firms so “钢铁销售有限公司” is not a sales action."""

    return _ORG_NAME.sub("", compact)


def _has_real_sales_action(stated: str) -> bool:
    """Ignore 销售模式, 销售区域, and 销售部."""

    return "销售" in _PSEUDO_SALES.sub("", stated) or "生产与销售" in stated


def _formal_sales_product_names(
    excerpt: str, *, owned_products: bool = False
) -> list[str]:
    """Product names from a 生产量/销售量 table, one row at a time."""

    # Dosage conversion is a qualifier, not a separate product or name suffix.
    excerpt = re.sub(r"[（(]\s*按[^）)]+?折算\s*[)）]", "", excerpt)
    names: list[str] = []
    in_table = False
    table_prefix = ""
    pending = ""
    units = r"万千瓦时|亿千瓦时|兆瓦时|万平方米|万吉焦|吉焦|万吨|万台|万片|万袋|万条|万只|万个|万支|万盒|万十亿|千克|立方米|MW|吨|辆|台"
    for line in excerpt.replace("\r\n", "\n").replace("\r", "\n").split("\n"):
        compact = re.sub(r"\s+", "", line)
        if "生产量" in compact and "销售量" in compact and "钢铁" not in compact:
            in_table = re.search(r"子公司|第三方|拟|计划", table_prefix[-160:]) is None
            pending = ""
            continue
        if not in_table or not compact:
            table_prefix += compact
            continue
        if (
            compact.startswith("合计")
            or re.match(r"^[（(][一二三四五六七八九十0-9]+[)）]", compact)
            or "产销量情况说明" in compact
        ):
            in_table = False
            pending = ""
            continue
        if re.search(r"年度报告|^\d+/\d+$|增减|库存量|销售量|生产量|^（?%", compact):
            continue
        match = re.match(
            rf"(.*?)(?:{units})([\d,]+(?:\.\d+)?)([\d,]+(?:\.\d+)?)", compact
        )
        # Prefer separated numeric columns, while retaining native parentheses
        # and dosage forms in the name. The unit is never a product suffix.
        spaced = list(
            re.finditer(
                rf"(?<!\S)([\u4e00-\u9fffA-Za-z()（）-]+(?: +[\u4e00-\u9fffA-Za-z()（）-]+)?)\s+(?:{units})\s+(?:[\d,]+(?:\.\d+)?|-)\s+([\d,]+(?:\.\d+)?)",
                line.strip(),
            )
        )
        if spaced:
            for index, row in enumerate(spaced):
                name = (pending if index == 0 else "") + re.sub(
                    r"\s+", "", row[1]
                ).lstrip("-")
                if ("钢铁" in name or owned_products) and float(
                    row[2].replace(",", "")
                ) > 0:
                    names.append(name)
            pending = ""
            continue
        elif match:
            name = pending + match.group(1)
        else:
            if re.fullmatch(
                r"[\u4e00-\u9fffA-Za-z0-9()（）-]+", compact
            ) and not re.search(r"比上年|%|库存|增减", compact):
                if names and compact in {"机械", "配件", "产品"} and not pending:
                    names[-1] += compact
                else:
                    pending += compact
            continue
        pending = ""
        if name and ("钢铁" in name or owned_products):
            names.append(name)
    return list(dict.fromkeys(names))


def _domestic_scrap_clause(excerpt: str) -> str:
    """The company's scrap row that says 国内采购, not internal 自供."""

    compact = re.sub(r"\s+", "", excerpt)
    start = compact.find("废钢供应")
    if start < 0:
        return ""
    window = compact[start : start + 240]
    if "国内采购" not in window:
        return ""
    return window


def _clause_names_other_firm(clause: str) -> bool:
    """A named firm in the clause is not the reporting company."""

    for match in _FIRM_ENDING.finditer(clause):
        firm = match.group(0).removeprefix("同时")
        if firm in {"公司", "本公司"}:
            continue
        return True
    return False


def _operating_energy_bindings(excerpt: str) -> list[tuple[str, str, str]]:
    """Bind 电耗 and 柴油单耗 to the clause subject and business column.

    A subsidiary firm, or a price-risk sentence with no operating-consumption
    wording, does not become the reporting company's energy use.
    """

    bindings: list[tuple[str, str, str]] = []
    for clause in _repair_commodity_clauses(excerpt):
        if "子公司" in clause or _clause_names_other_firm(clause):
            continue
        match = _OPERATING_ENERGY.search(clause)
        if match is None:
            continue
        if "价格风险" in clause:
            continue
        stated = _without_org_names(clause)
        if "本公司" in stated or "公司" in stated:
            subject = "公司"
        elif "运营端" in clause:
            subject = "运营端"
        else:
            continue
        bindings.append((subject, match.group("business"), match.group("item")))
    compact = re.sub(r"\s+", "", excerpt)
    for sentence in re.split(r"[。；;]", compact):
        match = re.search(r"(?:本集团|本公司|公司)[^。]{0,30}燃油消耗", sentence)
        if match and not re.search(
            r"子公司|第三方|拟|计划|尚未|不消耗|未消耗", sentence[: match.end()]
        ):
            bindings.append(
                ("本集团" if "本集团" in match.group(0) else "公司", "燃油消耗", "燃油")
            )
    return bindings


def _project_repair_commodity_span(
    selection: CoreEvidenceSelection,
    span: CoreEvidenceSpan,
    *,
    named_role_repair: bool = False,
    service_operating_energy: bool = False,
    core_answer_repair: bool = False,
    source_delivery_repair: bool = False,
    expand_actor_aliases: bool = False,
    actor_definitions: tuple[tuple[str, str, str], ...] | None = None,
) -> tuple[SemanticRecord, ...]:
    """Bind a role only when the company, name, and action share a clause."""

    item = _prepared_for(selection, span, "explicit_activity")
    if item is None:
        return ()
    if actor_definitions is None:
        actor_definitions = (
            tuple(
                definition
                for candidate in selection.spans
                for definition in _native_actor_definitions(candidate.excerpt)
            )
            if expand_actor_aliases
            else ()
        )
    records: list[SemanticRecord] = []
    seen: set[tuple[object, ...]] = set()

    def add_activity(
        name: str,
        action: ActivityAction,
        verb: str,
        value: str | None = None,
        *,
        actor: str = "公司",
        header: str | None = None,
        unit: str | None = None,
        qualifier: str | None = None,
    ) -> None:
        original_actor = actor
        for alias, full_name, _ in actor_definitions:
            if alias not in {
                "公司",
                "本公司",
                "集团",
                "本集团",
            } and (
                alias == re.sub(r"\s+", "", actor)
                or actor == alias + "及其他物流子公司"
            ):
                actor = full_name + (
                    "及其他物流子公司" if actor.endswith("及其他物流子公司") else ""
                )
        # Installation, maintenance and technical support share a broad action
        # enum, but are distinct explicitly reported services.
        key = (
            name,
            action,
            header,
            actor,
            qualifier,
            verb if action == ActivityAction.PROVIDES_SERVICE else None,
        )
        if key in seen:
            return
        seen.add(key)
        limited = re.search(
            rf"{re.escape(name)}业务本期仅统计[^。；]+",
            re.sub(r"\s+", "", span.excerpt),
        )
        former_actor = None
        if limited:
            renamed = re.search(
                r"后更名为([^。]+?有限公司)[）)]", re.sub(r"\s+", "", span.excerpt)
            )
            if renamed and "公司丧失" in span.excerpt:
                former_actor = renamed[1]
                actor = former_actor
        ceased = re.search(
            rf"\d{{4}}年\d{{1,2}}月后，公司已不开展{re.escape(name)}贸易业务",
            re.sub(r"\s+", "", span.excerpt),
        )
        native = SourceNativeValue(
            name=name,
            value=value,
            unit=unit if unit is not None else ("元" if value else None),
            header=header,
            qualifier=qualifier
            if qualifier is not None
            else ceased.group()
            if ceased
            else limited.group()
            if limited
            else "原主体：" + actor
            if actor not in {"公司", "本公司", "本集团", "公司及合并子公司", "运营端"}
            else "能源采购"
            if header == "能源" and action == ActivityAction.PURCHASES
            else None,
        )
        records.append(
            _base_fact(
                Activity,
                report=selection.report,
                record_id=(f"owned:{item.evidence.evidence_id}:commodity:{len(seen)}"),
                field_id="explicit_activity",
                chapter_task=ChapterTask.EXTRACT_BUSINESS_OVERVIEW,
                evidence=item.evidence,
                source_native=native,
                action=action,
                activity_actor=actor,
                source_actor=actor,
                actor_basis=SubjectBasis.DIRECT_GRAMMATICAL_ACTOR,
                object_name=name,
                source_verb=verb,
                excerpt_subject=span.excerpt,
            )
        )

        if former_actor or actor != original_actor:
            records[-1] = records[-1].model_copy(
                update={
                    "subject_scope": SubjectScope.NAMED_SUBSIDIARY,
                    "subject_basis": SubjectBasis.DIRECT_SOURCE_WORDING,
                }
            )

    for compact in _repair_commodity_clauses(span.excerpt):
        stated = _without_org_names(compact)
        if (
            named_role_repair
            and re.search(r"合营企业|联营企业", compact)
            and "业务性质" in compact
        ):
            continue
        if core_answer_repair and "母公司" in compact and "业务性质" in compact:
            continue
        company = _clause_names_company(stated if core_answer_repair else compact)
        if "参股" in compact and "本公司" not in compact:
            company = False
        sells = (
            _has_real_sales_action(stated)
            if named_role_repair
            else "销售" in stated or "生产与销售" in stated
        )
        procures = any(token in stated for token in ("采购", "订购", "原辅料"))
        if core_answer_repair and (
            _AUDIT_PROCEDURE.search(compact) or _RESUME_CLAUSE.search(compact)
        ):
            sells = False
            procures = False
        if named_role_repair and company and "能源介质" in stated:
            if sells:
                add_activity("能源介质", ActivityAction.SELLS, "销售")
            if "采购" in stated or "订购" in stated:
                add_activity("能源介质", ActivityAction.PURCHASES, "采购")
        if (
            company
            and sells
            and "采购协议" not in stated
            and (not source_delivery_repair or _current_company_sentence(stated))
        ):
            for name, aliases in _REPAIR_SALES:
                # A counterparty's name is not the sold object. Generic
                # 销售商品 rows cannot supply an unstated product.
                objects = (
                    _direct_sales_objects(stated) if source_delivery_repair else stated
                )
                if any(_sales_alias_in(objects, alias) for alias in aliases):
                    add_activity(name, ActivityAction.SELLS, "销售")
        if (
            service_operating_energy
            and "价格风险" in compact
            and not any(token in stated for token in ("采购", "订购"))
        ):
            procures = False
        if (
            company
            and procures
            and not (
                source_delivery_repair
                and re.search(r"上游原料价格|价格波动|风险", stated)
                and not re.search(
                    r"(?:本公司|公司|本集团)[^。]{0,30}(?:采购|订购)", stated
                )
            )
        ):
            for name in _REPAIR_PROCUREMENT:
                if name not in stated:
                    continue
                if name == "焦炭" and (
                    re.search(r"上游原料价格|价格波动|风险", stated)
                    or not any(
                        token in stated for token in ("采购", "订购", "作为原料")
                    )
                ):
                    continue
                add_activity(name, ActivityAction.PURCHASES, "采购")
        if "蒸汽费" in compact and "热水费" in compact and "电费" in compact:
            for name, _alias in _REPAIR_ENERGY:
                add_activity(name, ActivityAction.PURCHASES, "消耗")
            if "7407073" in compact or "7,407,073" in compact:
                add_activity(
                    "蒸汽费、热水费及电费",
                    ActivityAction.PURCHASES,
                    "消耗",
                    "7407073",
                )
    if named_role_repair:
        owned_products = source_delivery_repair and any(
            candidate.chapter_task == ChapterTask.EXTRACT_SEGMENT_FINANCIALS.value
            and span.page in (candidate.page, *candidate.continuation_pages)
            for candidate in selection.spans
        )
        if source_delivery_repair and not owned_products:
            table_header = re.search(r"主要产品\s+单位\s+生产量\s+销售量", span.excerpt)
            if table_header:
                prefix = span.excerpt[: table_header.start()]
                owned_products = "√适用 □不适用" in prefix and not re.search(
                    r"子公司|第三方|拟|计划", prefix
                )
        for name in _formal_sales_product_names(
            span.excerpt, owned_products=owned_products
        ):
            add_activity(name, ActivityAction.SELLS, "销售")
        if _domestic_scrap_clause(span.excerpt) and not core_answer_repair:
            add_activity("废钢", ActivityAction.PURCHASES, "采购")
    if core_answer_repair:
        for name, channel in _supply_source_rows(span.excerpt):
            add_activity(name, ActivityAction.PURCHASES, "采购", header=channel)
    if source_delivery_repair:
        for name, verb, header in _native_current_product_bindings(span.excerpt):
            add_activity(name, ActivityAction.SELLS, verb, header=header)
        for name, verb, header in _native_input_bindings(span.excerpt):
            if verb != "投入":
                add_activity(name, ActivityAction.PURCHASES, verb, header=header)
        for name, actor in _named_sales_bindings(span.excerpt):
            before = len(records)
            add_activity(name, ActivityAction.SELLS, "销售", actor=actor)
            if len(records) > before and actor != "公司":
                records[-1] = records[-1].model_copy(
                    update={
                        "subject_scope": SubjectScope.CONSOLIDATED_GROUP,
                        "subject_basis": SubjectBasis.DIRECT_SOURCE_WORDING,
                    }
                )
        for name in _company_sales_product_names(span.excerpt):
            add_activity(name, ActivityAction.SELLS, "销售")
        for name in _company_trade_sales_product_names(span.excerpt):
            # The row amount is revenue, not a commodity quantity or price.
            # Keep it in the original evidence and project only the native role.
            add_activity(name, ActivityAction.SELLS, "销售", header="本期营业收入")
        for binding in (
            *_power_and_oil_bindings(span.excerpt),
            *_explicit_current_commodity_bindings(span.excerpt),
        ):
            if binding["action"] is None:
                # Own energy use is projected by the material chapter; it
                # does not establish an external purchase Activity.
                continue
            before = len(records)
            actor = binding.get("actor") or "公司"
            if binding.get("header") == "电力热力生产供应业/购煤成本":
                actors = {
                    m[1]
                    for candidate in selection.spans
                    for m in re.finditer(
                        r"全资子公司([\u4e00-\u9fff]{2,20}公司)(?:拥有|总装机容量)",
                        re.sub(r"\s+", "", candidate.excerpt),
                    )
                }
                if len(actors) != 1:
                    continue
                actor = actors.pop()
            if (
                binding.get("header") == "本年度其他业务收入"
                and re.fullmatch(r"[\u4e00-\u9fff]{2,8}", actor)
                and actor
                not in {
                    "公司",
                    "本公司",
                    "本集团",
                }
            ):
                firms = {
                    re.sub(r"\s+", "", m.group())
                    for candidate in selection.spans
                    if "主要控股参股公司分析" in candidate.bounded_quote
                    for m in re.finditer(
                        r"[\u4e00-\u9fff\s]{2,60}?有限公司", candidate.excerpt
                    )
                    if actor in re.sub(r"\s+", "", m.group())
                }
                if len(firms) == 1:
                    actor = firms.pop()
                    binding = {
                        **binding,
                        "subject_basis": SubjectBasis.DIRECT_SOURCE_WORDING,
                    }
            add_activity(
                binding["name"],
                binding["action"],
                binding["verb"],
                binding.get("value"),
                actor=actor,
                header=binding.get("header"),
                unit=binding.get("unit"),
                qualifier=binding.get("qualifier"),
            )
            if len(records) > before and binding.get("subject_basis"):
                # The action's explicit group definition wins over an
                # unrelated parent-company ownership note elsewhere on page.
                records[-1] = records[-1].model_copy(
                    update={
                        "subject_scope": binding.get("subject_scope")
                        or (
                            SubjectScope.ISSUER
                            if actor.endswith("分公司")
                            else SubjectScope.CONSOLIDATED_GROUP
                            if actor in {"公司", "本公司", "本集团", "公司及合并子公司"}
                            else SubjectScope.NAMED_SUBSIDIARY
                        ),
                        "subject_basis": binding["subject_basis"],
                    }
                )
        for index, record in enumerate(records):
            if record.source_native.header != "原具名投资经营":
                continue
            if any(
                name == record.source_actor and associate
                for sp in selection.spans
                for name, _, associate in _native_equity_business_rows(sp.excerpt)
            ):
                records[index] = record.model_copy(
                    update={
                        "subject_scope": SubjectScope.BUSINESS_SEGMENT,
                        "source_native": record.source_native.model_copy(
                            update={
                                "qualifier": "原参股主体，不并表；原主体："
                                + record.source_actor
                            }
                        ),
                    }
                )
        for binding in _hedge_underlying_bindings(span.excerpt):
            add_activity(
                binding["name"],
                binding["action"],
                binding["verb"],
                binding.get("value"),
                actor=binding.get("actor") or "公司",
                header=binding.get("header"),
                unit=binding.get("unit"),
            )
    if source_delivery_repair:
        for name, actor, group in _current_shipped_product_bindings(span.excerpt):
            before = len(records)
            add_activity(
                name, ActivityAction.SELLS, "出货" if group else "上市销售", actor=actor
            )
            if len(records) > before and group:
                records[-1] = records[-1].model_copy(
                    update={
                        "subject_scope": SubjectScope.CONSOLIDATED_GROUP,
                        "subject_basis": SubjectBasis.DIRECT_SOURCE_WORDING,
                    }
                )
    if service_operating_energy:
        for subject, business, item_name in _operating_energy_bindings(span.excerpt):
            add_activity(
                item_name,
                ActivityAction.PURCHASES,
                "消耗",
                actor=subject,
                header=business,
            )
    return tuple(records)


def _join_rmb_column_header(text: str) -> str:
    """Join a wrapped column header such as 营业收入（人 / 民币百万元）."""

    return re.sub(r"人\s*[\r\n]+\s*民币", "人民币", text)


def _integrated_business_source(excerpt: str) -> str:
    """A company-profile sentence that keeps every clause through the period."""

    joined = _join_pdf_soft_breaks(excerpt)
    match = _INTEGRATED_BUSINESS_SENTENCE.search(joined)
    if match is None:
        return ""
    compact = re.sub(r"\s+", "", match.group(0))
    source = _original_span_matching(excerpt, compact) or ""
    tail = joined[match.end() :]
    controlled = re.match(
        r"。\s*\d{4}\s*年，(?:本公司|公司)取得(?P<name>[\u4e00-\u9fff]{2,12})控制权，(?P=name)[^。]{2,300}主要开展[^。]{2,200}。",
        tail,
    )
    if source and controlled:
        compact += re.sub(r"\s+", "", controlled.group(0))
        source = _original_span_matching(excerpt, compact) or source
    return source


def _current_business_narrative_source(excerpt: str) -> str:
    joined = _join_pdf_soft_breaks(excerpt)
    match = _CURRENT_BUSINESS_NARRATIVE.search(joined)
    if match is None or not _current_company_sentence(match.group(0)):
        return ""
    source = match.group(0)
    vision = re.search(
        r"(?:本公司|公司)以[^。]{2,500}为愿景[^。]{2,500}为战略定位。\s*$",
        joined[: match.start()],
    )
    if vision and _current_company_sentence(vision.group(0)):
        source = vision.group(0) + source
    return _original_span_matching(excerpt, re.sub(r"\s+", "", source))


def _company_sales_mechanism_source(excerpt: str) -> str:
    compact = re.sub(r"\s+", "", excerpt)
    for pattern in (
        rf"{_COMPANY_SUBJECT}电力销售客户主要为[^。]+。",
        rf"{_COMPANY_SUBJECT}煤机全年市场化交易累计成交电量[^。]+。",
    ):
        match = re.search(pattern, compact)
        if match and _current_company_sentence(
            compact[max(0, compact.rfind("。", 0, match.start()) + 1) : match.end()]
        ):
            return _original_span_matching(excerpt, match.group(0))
    # A native current-year trading table states a sales mechanism even when
    # its heading is not a sentence. Keep the preceding owned operating
    # context rather than inventing a company subject for the table.
    table = re.search(
        r"(?:^|\n)\s*\d+[、.]\s*电力市场化交易\s*\n"
        r"\s*√适用\s*□不适用[\s\S]+?市场化交易的总电量[^\n]+"
        r"[\s\S]+?总上网电量[^\n]+[\s\S]+?占比[^\n]+",
        excerpt,
    )
    if table:
        before = excerpt[: table.start()]
        owner = re.search(r"报告期内，\s*本公司[^。]+。", before)
        if owner and not re.search(r"子公司|第三方|本公司(?:拟|计划|将|尚未)", before):
            return excerpt[owner.start() : table.end()]
    return ""


def _current_shipped_product_bindings(excerpt: str) -> list[tuple[str, str, bool]]:
    """Established shipments/sales within the owned subsection, not future layout."""
    compact = re.sub(r"\s+", "", excerpt)
    bindings = []
    chip = re.search(
        r"[0-9]+、芯片[^。]*公司战略控股[^。]+。.*?(?=[0-9]+、|$)", compact
    )
    if chip:
        context = chip.group(0)
        control = re.search(
            r"公司战略控股(?P<names>[^。]{2,60}?)两家上游芯片企业", context
        )
        if (
            control
            and "报告期内" in context
            and any(
                re.search(r"(?:量产|批量)出货", clause)
                and not re.search(r"计划|拟|尚未|未实现|不|将", clause)
                for clause in re.split(r"[。；;]", context)
            )
            and not re.search(
                r"子公司战略控股|第三方公司战略控股|公司(?:拟|计划)战略控股", context
            )
        ):
            bindings.append(("芯片", "公司战略控股的" + control.group("names"), True))
    wearable = re.search(
        r"[0-9]+、智能穿戴[^。]*报告期内，公司[^。]+。.*?(?=（[一二三四五六七八九十]+）|$)",
        compact,
    )
    if wearable:
        context = wearable.group(0)
        subject = re.search(r"报告期内，公司[^。]+。", context)
        sale = re.search(r"开放式AI耳机[^。]*国内上市销售", context)
        if (
            subject
            and _current_company_sentence(subject.group(0))
            and sale
            and not re.search(
                r"子公司|第三方|拟|计划|尚未|未上市", context[: sale.end()]
            )
        ):
            bindings.append(("AI耳机", "公司", False))
    return bindings


def _company_coal_risk_source(text: str) -> str:
    """The company's own coal-cost risk bound to its current coal-fired fleet."""
    joined = _join_pdf_soft_breaks(text)
    risk = re.search(r"[（(]四[）)]可能面对的风险[\s\S]*?(?=[（(]五[）)]|$)", joined)
    if risk is None:
        return ""
    context = re.sub(r"\s+", "", risk.group(0))
    own = re.search(r"(?:本公司|公司)装机结构中煤电占比高[^。]*。", context)
    if (
        own
        and _current_company_sentence(
            context[max(0, context.rfind("。", 0, own.start()) + 1) : own.end()]
        )
        and "煤炭成本在燃煤发电企业的发电成本中占比较大" in context
    ):
        return risk.group(0)
    return ""


def _current_company_sentence(sentence: str) -> bool:
    return (
        re.search(_COMPANY_SUBJECT, sentence) is not None
        and re.search(
            r"子公司|母公司|第三方|(?:客户|供应商)(?:公司|酿造|生产)", sentence
        )
        is None
        and re.search(
            r"(?:拟|计划|尚未|不再)[^。；;]{0,18}(?:作为|从事|生产|销售|构建|采用|有)"
            r"|(?:不|未|没有|并无)(?:对外)?(?:销售|生产|采用|构建)",
            sentence,
        )
        is None
    )


def _company_product_model_sources(excerpt: str) -> list[str]:
    """Keep the owned, current product matrix and stated sales model whole."""

    sources: list[str] = []
    compact = re.sub(r"\s+", "", excerpt)
    for sentence in re.split(r"(?<=。)", compact):
        start = re.search(rf"(?<!第三方){_COMPANY_SUBJECT}(?:旗下|采用)", sentence)
        if start is None:
            continue
        stated = sentence[start.start() :]
        if not _current_company_sentence(stated):
            continue
        if "产品矩阵" not in stated and not ("销售模式" in stated and "采用" in stated):
            continue
        text = _original_span_matching(excerpt, stated)
        if text:
            sources.append(text)
    return sources


def _company_income_source(excerpt: str) -> str:
    compact = re.sub(r"\s+", "", excerpt)
    match = re.search(
        rf"(?<!第三方){_COMPANY_SUBJECT}主营业务收入主要来[自源]于[^。]+。", compact
    )
    if match is None or not _current_company_sentence(
        compact[max(0, compact.rfind("。", 0, match.start()) + 1) : match.end()]
    ):
        return ""
    return _original_span_matching(excerpt, match.group(0))


def _company_trade_sales_product_names(excerpt: str) -> list[str]:
    """Names sold in an affirmed company-owned trade-revenue table."""

    joined = _join_pdf_soft_breaks(excerpt)
    heading = re.search(
        r"(?:^|\n)\s*(?:[A-Z][.．]\s*)?报告期内(?:本公司|公司)存在贸易业务收入"
        r"\s*\n\s*√适用\s*□不适用",
        joined,
    )
    if heading is None:
        return []
    table = re.split(r"贸易业务(?:占|收入占)", joined[heading.end() :], maxsplit=1)[0]
    if re.search(r"子公司|母公司|第三方|拟|计划|尚未|不存在", table):
        return []
    compact = re.sub(r"\s+", "", table)
    if "贸易业务开展情况本期营业收入上期营业收入" not in compact:
        return []
    if _unit_from_excerpt(table) is None:
        return []
    sales = re.findall(
        r"(?:^|\n)\s*销售([\u4e00-\u9fff]{1,12})\s+\d[\d,]*\.\d+\s+\d",
        table,
    )
    sales.extend(
        re.findall(
            r"(?:^|\n)\s*([\u4e00-\u9fff]{2,10})业务\s+\d[\d,]*\.\d+\s+\d", table
        )
    )
    names = []
    for name in sales:
        if name in {"贸易", "商贸", "其他", "其它"}:
            continue
        # A named trade business establishes sales of its printed goods,
        # not a product whose name includes the business suffix.
        if name.endswith("贸易"):
            names.extend(re.split(r"、|及", name.removesuffix("贸易")))
        else:
            names.append(name)
    return names


def _direct_sales_objects(stated: str) -> str:
    """Only product-column wording or a direct sales/production object."""

    if "销售商品" in stated:
        # Customer/content/amount rows do not contain a product column.
        return ""
    objects = []
    for pattern in (
        r"(?:销售|生产与销售)([\u4e00-\u9fff、和及]{2,50})(?=产品|[，,。；;]|$)",
        r"([\u4e00-\u9fff、和及]{2,50})(?:产品)?(?:的)?(?:生产和销售|生产与销售|生产、销售|销售)",
    ):
        objects.extend(match.group(1) for match in re.finditer(pattern, stated))
    return "、".join(objects)


def _named_sales_bindings(excerpt: str) -> list[tuple[str, str]]:
    """Current named product lists in owned marketing or performance sections.

    Keep native brands/forms; generic parent categories are not extra sales.
    """

    compact = re.sub(r"\s+", "", excerpt)
    bindings: list[tuple[str, str]] = []
    if re.search(r"公司药[（(]产[)）]品销售情况", compact) and not re.search(
        r"子公司|第三方|公司拟|公司计划", compact.split("主要销售模式分析")[0]
    ):
        section = compact.split("销售费用情况分析")[0]
        for match in re.finditer(r"主要产品[为有]([^。；;]+)", section):
            sentence = _sentence_containing(section, match.start())
            # A sale modifier belongs to this list, not every list on the page.
            introduction = re.split(r"[，,。；;]", section[: match.start()])[-1]
            if re.search(
                r"子公司|第三方|(?:公司)?(?:拟|计划)[^。]{0,30}(?:销售|主要产品)",
                sentence,
            ) or re.search(
                r"(?:拟|计划|将(?:要)?|即将|未来|预计|准备|打算|尚未|暂未|"
                r"未曾|从未|并未|没有|不再|未)[^，,。；;]{0,30}(?:销售|主要产品)|不销售",
                introduction + "主要产品",
            ):
                continue
            for branch in re.split(
                r"等(?:慢病|专科)产品[，,]?|及部分输液产品[，,]?|以及", match.group(1)
            ):
                actor = "公司"
                subsidiary = re.search(r"等([\u4e00-\u9fff]{2,16})产品", branch)
                if subsidiary:
                    actor = subsidiary.group(1)
                branch = re.split(
                    r"等[，,。]|等[\u4e00-\u9fff]*产品|形成|实行", branch, maxsplit=1
                )[0]
                for name in branch.strip("，,、").split("、"):
                    if re.fullmatch(
                        r"[\u4e00-\u9fffA-Za-z0-9()（）-]{2,60}", name
                    ) and not name.startswith("部分"):
                        bindings.append((name, actor))
    performance = re.search(
        r"经营情况讨论与分析.*?\d{4}年[，,]([^。]+实现营业收入[^。]+。)", compact
    )
    if (
        performance
        and _current_company_sentence(performance.group(1))
        and not re.match(r"(?:本公司|公司)(?:拟|计划)", performance.group(1))
    ):
        text = compact[performance.end() :]
        for match in re.finditer(
            r"([\u4e00-\u9fff]{2,30}[（(][^()（）]{1,20}[)）])(?:销量同比|快速导入市场[，,]收入同比)",
            text,
        ):
            name = re.sub(r"^.*?(?:类新药)", "", match.group(1))
            bindings.append((name, "公司"))
        for match in re.finditer(
            r"[，,]([\u4e00-\u9fffA-Za-z0-9、-]{2,100})等原料药销量", text
        ):
            bindings.extend((name, "公司") for name in match.group(1).split("、"))
    return list(dict.fromkeys(bindings))


def _numbered_business_source(excerpt: str) -> str:
    """An owned business section with numbered, established business platforms."""

    joined = _join_pdf_soft_breaks(excerpt)
    blocks = list(
        re.finditer(r"(?:^|\n)\s*\d+[.．、]\s*[\u4e00-\u9fff]{2,12}业务", joined)
    )
    if len(blocks) < 2 or "报告期内公司从事" not in joined:
        return ""
    body = joined[blocks[0].start() :]
    if not re.search(
        r"(?<![\u4e00-\u9fff])(?:本公司|公司)(?:通过|的|拥有|实现|立足|原料药业务)",
        re.sub(r"\s+", "", body),
    ):
        return ""
    return re.split(r"报告期内公司新增重要非主营业务的说明", body, maxsplit=1)[
        0
    ].strip()


def _project_business_source(excerpt: str) -> str:
    joined = _join_pdf_soft_breaks(excerpt)
    match = re.search(
        r"(?<![\u4e00-\u9fff])(?:本公司|公司)主营业务为[^。]+项目的开发、建设、运营与管理。",
        joined,
    )
    if not match or not _current_company_sentence(match.group(0)):
        return ""
    return re.split(
        r"报告期内公司新增重要非主营业务的说明", joined[match.start() :], maxsplit=1
    )[0].strip()


def _company_sales_product_names(excerpt: str) -> list[str]:
    names: list[str] = []
    compact = re.sub(r"\s+", "", excerpt)
    for sentence in re.split(r"[。；;]", compact):
        if not _current_company_sentence(sentence):
            continue
        for pattern in (
            r"主要从事([\u4e00-\u9fff]{2,12})的(?:研发|酿造|生产)[、和及\u4e00-\u9fff]{0,20}销售",
            r"公司有([\u4e00-\u9fff]{2,12})的生产[^。]{0,25}对外销售",
        ):
            match = re.search(pattern, sentence)
            if match:
                names.append(match.group(1))
    return names


def _main_business_source(excerpt: str) -> str:
    """The reporting company's full 主要业务是 sentence."""

    joined = _join_pdf_soft_breaks(excerpt)
    match = _MAIN_BUSINESS_SENTENCE.search(joined)
    if match is None:
        return ""
    compact = re.sub(r"\s+", "", match.group(0))
    return _original_span_matching(excerpt, compact) or ""


def _main_operation_source(excerpt: str) -> str:
    """The 主要经营 sentence with its full business enumeration."""

    joined = _join_pdf_soft_breaks(excerpt)
    match = _MAIN_OPERATION_SENTENCE.search(joined)
    if match is None:
        return ""
    compact = re.sub(r"\s+", "", match.group(0))
    return _original_span_matching(excerpt, compact) or ""


def _provider_narrative_source(excerpt: str) -> str:
    """Keep the whole affirmative positioning sentence of the reporting company."""

    joined = _join_pdf_soft_breaks(excerpt)
    for match in _PROVIDER_NARRATIVE.finditer(joined):
        sentence = _sentence_containing(joined, match.start())
        compact = re.sub(r"\s+", "", sentence)
        # The positioning clause and the immediately following grammatical
        # subject must both describe this company. Do not discard a prefix
        # such as 公司拟 when capturing from 作为.
        if re.match(r"^(?:\d{4}年[，,])?(?:(?:本公司|公司))?作为", compact) is None:
            continue
        role, _, predicate = compact.partition("核心提供商")
        if re.search(r"拟|计划|未来|希望|愿景|目标|第三方|子公司", role):
            continue
        if re.match(
            r"[，,](?:本公司|公司)(?:拟|计划|将|预期|尚未|未|不|希望|力争)",
            predicate,
        ):
            continue
        return _original_span_matching(excerpt, compact) or ""
    return ""


def _business_blocks_source(excerpt: str) -> str:
    """Retain an owned business/mode section with multiple established blocks."""

    joined = _join_pdf_soft_breaks(excerpt)
    heading = re.search(r"公司所从事的主要业务情况及经营模式", joined)
    if heading is None:
        return ""
    blocks = list(
        re.finditer(
            r"[\u4e00-\u9fff]{2,12}业务[:：][^。]{8,600}。", joined[heading.end() :]
        )
    )
    if len(blocks) < 2 or any(
        re.search(r"业务[:：](?:子公司|第三方|公司拟|公司计划)", item.group(0))
        for item in blocks
    ):
        return ""
    end = heading.end() + blocks[-1].end()
    return _original_span_matching(
        excerpt, re.sub(r"\s+", "", joined[heading.start() : end])
    )


def _company_as_narrative_source(excerpt: str) -> str:
    """The 作为……上市公司/工业企业……研发制造 company narrative."""

    joined = _join_pdf_soft_breaks(excerpt)
    match = _COMPANY_AS_NARRATIVE.search(joined)
    if match is None:
        return ""
    compact = re.sub(r"\s+", "", match.group(0))
    return _original_span_matching(excerpt, compact) or ""


def _operating_model_source(excerpt: str) -> str:
    """The 经营模式主要为 sentence with its provide-and-collect fees."""

    joined = _join_pdf_soft_breaks(excerpt)
    match = _OPERATING_MODEL_SENTENCE.search(joined)
    if match is None or not _overview_states_revenue(
        match.group(0), repair_revenue_sentence=True
    ):
        return ""
    compact = re.sub(r"\s+", "", match.group(0))
    return _original_span_matching(excerpt, compact) or ""


def _toll_service_source(excerpt: str) -> str:
    """The 主营业务为 sentence plus its following toll-service mechanism."""

    joined = _join_pdf_soft_breaks(excerpt)
    match = _TOLL_SERVICE_SENTENCE.search(joined)
    if match is None:
        return ""
    compact = re.sub(r"\s+", "", match.group(0))
    return _original_span_matching(excerpt, compact) or ""


def _steel_raw_material_binding(excerpt: str) -> dict[str, Any] | None:
    """The stated main raw-material steel, without quantities.

    The steel must sit in the same sentence as the company's own
    raw-material declaration; a customer or third-party sentence elsewhere
    in the excerpt never binds.
    """

    joined = _join_pdf_soft_breaks(excerpt)
    for sentence in re.split(r"[。；;]", joined):
        compact = re.sub(r"\s+", "", sentence)
        if not re.search(r"(?<![子母])公司生产所需的主要原材料及零部件为", compact):
            continue
        if "客户" in compact or "第三方" in compact:
            continue
        if "钢材" not in compact:
            continue
        return {
            "name": "钢材",
            "action": ActivityAction.PURCHASES,
            "verb": "采购",
            "value": None,
            "unit": None,
            "actor": "公司",
            "header": "主要原材料",
        }
    return None


def _hedge_underlying_bindings(excerpt: str) -> list[dict[str, Any]]:
    """Named futures hedge underlyings; amounts stay empty and unsplit.

    The names must sit in the sentence that affirms the futures business
    (开展 or 从事 without a 未/拟/计划 prefix); a not-yet or planned
    disclosure never binds.
    """

    joined = _join_pdf_soft_breaks(excerpt)
    bindings: list[dict[str, str | None]] = []
    for sentence in re.split(r"[。；;]", joined):
        compact = re.sub(r"\s+", "", sentence)
        if "原料的期货业务" not in compact:
            continue
        if re.search(r"(?:未|拟|计划|将)(?:开展|从事)", compact):
            continue
        if "开展" not in compact and "从事" not in compact:
            continue
        if "客户" in compact or "第三方" in compact or "子公司" in compact:
            continue
        if not re.search(r"本公司|本集团|(?<![子母])公司", compact):
            continue
        if "套期保值" not in compact and "期货" not in compact:
            continue
        for name in ("钢材", "铜", "铝", "原油"):
            if name in compact:
                bindings.append(
                    {
                        "name": name,
                        "action": ActivityAction.OPERATES,
                        "verb": "期货套保",
                        "value": None,
                        "unit": None,
                        "actor": "公司",
                        "header": "套期保值标的",
                    }
                )
    return bindings


def _power_and_oil_bindings(excerpt: str) -> list[dict[str, Any]]:
    """Coal volume, combined power-heat sales, crude purchase, and internal sales."""

    compact = re.sub(r"\s+", "", _join_pdf_soft_breaks(excerpt))
    bindings: list[dict[str, str | None]] = []
    coal = re.search(r"公司共采购煤炭(?P<value>\d+(?:\.\d+)?)亿吨", compact)
    if coal:
        bindings.append(
            {
                "name": "煤炭",
                "action": ActivityAction.PURCHASES,
                "verb": "采购",
                "value": coal.group("value"),
                "unit": "亿吨",
                "actor": "公司",
                "header": None,
            }
        )
    share = re.search(
        r"公司电力、热力销售收入约占营业收入的(?P<value>\d+(?:\.\d+)?)%",
        compact,
    )
    if share:
        bindings.append(
            {
                "name": "电力、热力",
                "action": ActivityAction.SELLS,
                "verb": "销售",
                "value": share.group("value"),
                "unit": "%",
                "actor": "公司",
                "header": None,
            }
        )
    if "炼油事业部" in compact and "购入原油" in compact:
        bindings.append(
            {
                "name": "原油",
                "action": ActivityAction.PURCHASES,
                "verb": "购入",
                "value": None,
                "unit": None,
                "actor": "炼油事业部",
                "header": None,
            }
        )
    if "炼油事业部" in compact and "内部销售" in compact:
        for name in ("汽油", "柴油", "煤油"):
            if name in compact:
                bindings.append(
                    {
                        "name": name,
                        "action": ActivityAction.SELLS,
                        "verb": "内部销售",
                        "value": None,
                        "unit": None,
                        "actor": "炼油事业部",
                        "header": "内部销售",
                    }
                )
    if "炼油事业部" in compact and "部分化工原料油内部销售给化工事业部" in compact:
        bindings.append(
            {
                "name": "化工原料油",
                "action": ActivityAction.SELLS,
                "verb": "内部销售",
                "value": None,
                "unit": None,
                "actor": "炼油事业部",
                "header": "部分内部销售给化工事业部",
            }
        )
    return bindings


def _supply_source_rows(excerpt: str) -> list[tuple[str, str]]:
    """One supply commodity per table row, split by 国内采购 and 国外进口."""

    rows: list[tuple[str, str]] = []
    current = ""
    for line in excerpt.replace("\r\n", "\n").replace("\r", "\n").split("\n"):
        compact = re.sub(r"\s+", "", line)
        named = re.search(r"(铁矿石|废钢)供应", compact)
        if named:
            current = named.group(1)
            continue
        if not current:
            continue
        if compact.startswith("合计"):
            current = ""
            continue
        if compact.startswith("国内采购"):
            rows.append((current, "国内采购"))
        elif compact.startswith("国外进口"):
            rows.append((current, "国外进口"))
    return rows


def _steel_business_source(excerpt: str) -> str:
    """The company's steel description through its named product series."""

    joined = _join_pdf_soft_breaks(excerpt)
    match = _STEEL_BUSINESS_SENTENCE.search(joined)
    if match is None:
        return ""
    compact = re.sub(r"\s+", "", match.group(0))
    return _original_span_matching(excerpt, compact) or ""


def _company_business_source(excerpt: str) -> str:
    """The reporting company's full 业务覆盖 or 专注于 sentence.

    Soft wraps are joined first. A bare “公司专注于” or “公司业务覆盖”
    has no business content and is not a sentence.
    """

    joined = _join_pdf_soft_breaks(excerpt)
    match = _COMPANY_BUSINESS_SENTENCE.search(joined)
    if match is None:
        return ""
    compact = re.sub(r"\s+", "", match.group(0))
    return _original_span_matching(excerpt, compact) or ""


def explicit_material_input_names(
    text: str, *, source_delivery_repair: bool = False
) -> tuple[str, ...]:
    """Return named materials the same sentence binds to the company's own input."""

    compact = re.sub(r"\s+", "", text)
    names: list[str] = (
        ["煤炭"] if source_delivery_repair and _company_coal_risk_source(text) else []
    )
    if source_delivery_repair:
        names.extend(
            name for name, verb, _ in _native_input_bindings(text) if verb == "投入"
        )
        names.extend(
            binding["name"]
            for binding in _explicit_current_commodity_bindings(text)
            if binding.get("header") in {"能源", "实际加工原料"}
        )
    for sentence in re.split(r"[。；;]", compact):
        names.extend(_named_inputs_in_sentence(sentence))
        names.extend(_company_owned_material_lists(sentence))
        if source_delivery_repair and _current_company_sentence(sentence):
            cost_list = re.search(
                rf"(?:酿造|生产)的主要原材料[（(]如(?P<list>{_LIST_BODY})[）)]",
                sentence,
            )
            if cost_list and re.search(r"对(?:本)?公司的(?:盈利|成本)", sentence):
                names.extend(_split_material_names(cost_list.group("list")))
            furnace = re.search(
                r"公司(?:合并口径)?入炉([\u4e00-\u9fff]{1,8}?)(?:单价|成本|消耗)",
                sentence,
            )
            if furnace:
                names.append(furnace.group(1))
    for match in _COMPANY_PROCUREMENT.finditer(compact):
        names.append(match.group(1))
    unique: list[str] = []
    for name in names:
        if not _accept_material_name(name) or name in unique:
            continue
        unique.append(name)
    return tuple(unique)


def _named_inputs_in_sentence(sentence: str) -> list[str]:
    """Accept a raw-material list only when that sentence states the company's cost."""

    if not _sentence_binds_company_input_cost(sentence):
        return []
    names: list[str] = []
    for match in re.finditer("等主要原材料", sentence):
        clause = re.split(r"[，,：:]", sentence[: match.start()])[-1]
        names.extend(_split_material_names(clause))
    return names


def _sentence_binds_company_input_cost(sentence: str) -> bool:
    match = _COMPANY_INPUT_COST.search(sentence)
    if match is None:
        return False
    return _THIRD_PARTY_COST.search(match.group("gap") or "") is None


def _accept_material_name(name: str) -> bool:
    if name in _GENERIC_MATERIAL_NAMES or not re.fullmatch(_MATERIAL_NAME, name):
        return False
    return _NOT_A_MATERIAL_NAME.search(name) is None


def _split_material_names(text: str) -> list[str]:
    names: list[str] = []
    for part in re.split(r"[、，,及和]", text):
        part = part.removesuffix("等")
        if not re.fullmatch(_MATERIAL_NAME, part):
            continue
        if part in _GENERIC_MATERIAL_NAMES:
            continue
        names.append(part)
    return names


_LIST_BODY = rf"(?:{_MATERIAL_NAME}[、和])+{_MATERIAL_NAME}"
_COMPANY_SUBJECT = r"(?<!供应商)(?<!客户)(?<!下游)(?<!子)(?:本公司|公司)"
_COMPANY_PRIMARY_LIST = re.compile(
    rf"{_COMPANY_SUBJECT}"
    rf"(?P<line>(?:产品|生产经营所需)?)"
    rf"主要原材料(?:包括|为)(?P<list>{_LIST_BODY})"
)
_COMPANY_LINE_LIST = re.compile(
    rf"{_COMPANY_SUBJECT}"
    rf"(?P<line>[\u4e00-\u9fff]{{1,12}})"
    rf"原材料包括(?P<list>{_LIST_BODY})"
)
_CONTINUATION_LIST = re.compile(
    rf"(?:生产所需原材料包括|业务原材料)(?P<list>{_LIST_BODY})"
)
_LIST_SUBJECT_REJECTED = re.compile(r"客户|供应商|下游|销售|出售")


def _company_owned_material_lists(sentence: str) -> list[str]:
    """Accept a company-subject raw-material list without requiring a cost verb.

    The older ``等主要原材料`` path still requires the company's own cost
    sentence. This path is the disclosure shape ``公司…主要原材料包括/为``
    and a same-sentence continuation such as ``生产所需原材料包括``.
    """

    names: list[str] = []
    matched = False
    for pattern in (_COMPANY_PRIMARY_LIST, _COMPANY_LINE_LIST):
        for match in pattern.finditer(sentence):
            line = match.group("line") or ""
            if _LIST_SUBJECT_REJECTED.search(line):
                continue
            matched = True
            names.extend(_split_material_names(match.group("list")))
    if not matched:
        return []
    for match in _CONTINUATION_LIST.finditer(sentence):
        names.extend(_split_material_names(match.group("list")))
    return names


def _select_material_span(
    pages: Sequence[ReportPageText],
    *,
    source_delivery_repair: bool = False,
) -> CoreEvidenceSpan | None:
    for page in pages:
        if not page.readable or not explicit_material_input_names(
            page.text, source_delivery_repair=source_delivery_repair
        ):
            continue
        section_title, quote = _material_quote(page.text)
        return CoreEvidenceSpan(
            page=page.page,
            section_title=section_title,
            excerpt=quote,
            bounded_quote=quote,
            chapter_task="extract_material_inputs",
            field_ids=("material_input",),
            context_complete=True,
        )
    return None


def _material_quote(text: str) -> tuple[str, str]:
    coal = _company_coal_risk_source(text)
    if coal:
        return "可能面对的风险", coal
    compact = re.sub(r"\s+", "", text)
    marker = text.find("等主要原材料")
    if marker >= 0:
        line_start = text.rfind("\n", 0, marker) + 1
        end = text.find("。", marker)
        quote = text[line_start : len(text) if end < 0 else end + 1].strip()
        if _named_inputs_in_sentence(re.sub(r"\s+", "", quote)):
            return _material_section(text, quote), quote
    match = _COMPANY_PROCUREMENT.search(compact)
    if match is None:
        return "主要原材料", text.strip()
    quote = _original_span_matching(text, match.group(0)) or match.group(0)
    return _material_section(text, quote), quote.strip()


def _material_section(text: str, quote: str) -> str:
    anchor = quote[:12]
    index = text.find(anchor) if anchor else -1
    before = text[:index] if index > 0 else ""
    lines = [line.strip() for line in before.splitlines() if line.strip()]
    if lines and len(lines[-1]) <= 30 and "等主要原材料" not in lines[-1]:
        return lines[-1]
    return "主要原材料"


def _project_material_span(
    selection: CoreEvidenceSelection,
    span: CoreEvidenceSpan,
    *,
    source_delivery_repair: bool = False,
) -> tuple[SemanticRecord, ...]:
    item = _prepared_for(selection, span, "material_input")
    if item is None:
        return ()
    records: list[SemanticRecord] = []
    inputs: dict[str, str | None] = dict.fromkeys(
        explicit_material_input_names(
            span.excerpt, source_delivery_repair=source_delivery_repair
        )
    )
    if source_delivery_repair:
        for name, verb, header in _native_input_bindings(span.excerpt):
            if verb == "投入":
                inputs[name] = header
        for binding in _explicit_current_commodity_bindings(span.excerpt):
            if (
                binding.get("header") in {"能源", "实际加工原料"}
                and binding.get("action") is None
            ):
                inputs[binding["name"]] = binding["header"]
    if source_delivery_repair:
        energy_binding = next(
            (
                b
                for b in _native_branch_action_bindings(span.excerpt)
                if b.get("action") is None
            ),
            None,
        )
        if energy_binding:
            inputs[energy_binding["name"]] = energy_binding["header"]
    for name, header in inputs.items():
        actor = (
            energy_binding["actor"]
            if header in {"能源", "实际加工原料"}
            and source_delivery_repair
            and energy_binding
            else None
        )
        actor_pages = []
        if actor:
            for candidate in selection.spans:
                for alias, full_name, _ in _native_actor_definitions(candidate.excerpt):
                    if alias == re.sub(r"\s+", "", actor):
                        actor = full_name
                        actor_pages.append(candidate.page)
        records.append(
            _base_fact(
                Relationship,
                report=selection.report,
                record_id=(f"owned:{item.evidence.evidence_id}:material:{name}"),
                field_id="material_input",
                chapter_task=ChapterTask.EXTRACT_MATERIAL_INPUTS,
                evidence=item.evidence,
                source_native=SourceNativeValue(
                    name=name,
                    header=header,
                    qualifier=(header + "；原主体：" + actor)
                    if header in {"能源", "实际加工原料"}
                    and source_delivery_repair
                    and energy_binding
                    else "能源耗用"
                    if header == "能源"
                    else None,
                ),
                relation_type=RelationshipType.MATERIAL_INPUT,
                object_name=name,
                excerpt_subject=span.excerpt,
            )
        )
        if header == "母公司产品生产工艺原料":
            records[-1] = records[-1].model_copy(
                update={
                    "subject_scope": SubjectScope.ISSUER,
                    "subject_basis": SubjectBasis.DIRECT_SOURCE_WORDING,
                }
            )
        if actor:
            records[-1] = records[-1].model_copy(
                update={
                    "subject_scope": SubjectScope.NAMED_SUBSIDIARY,
                    "subject_basis": SubjectBasis.DIRECT_SOURCE_WORDING,
                    "evidence": (
                        item.evidence.model_copy(
                            update={"subject_evidence_pages": tuple(actor_pages)}
                        ),
                    ),
                }
            )
    return tuple(records)


def _base_fact(model, **kwargs):
    report = kwargs["report"]
    evidence = kwargs.pop("evidence")
    excerpt = kwargs.pop("excerpt_subject", "")
    subject_scope, subject_basis = _subject_from_excerpt(excerpt)
    return model(
        subject_scope=subject_scope,
        subject_basis=subject_basis,
        reported_period=report.report_period,
        period_type=PeriodType.DURATION,
        assertion_class=AssertionClass.REPORTED_FACT,
        evidence=(evidence,),
        **kwargs,
    )


def _excerpt_states_owned_overview(excerpt: str) -> bool:
    return bool(
        re.search(
            r"主营业务为|主要从事|主要产品包括|主要产品为|经营范围(?!内)|"
            r"主要经营|公司主要业务情况|公司金融业务",
            excerpt,
        )
    )


def _join_wrapped_lines(text: str) -> str:
    return re.sub(r"[\r\n]+", "", text)


_PREFERRED_OVERVIEW_STATEMENT = re.compile(
    r"(?:主营业务为|主要从事|主要产品包括|主要产品为|"
    r"经营范围(?!内)\s*[\u4e00-\u9fff]|"
    r"(?:公司|本公司)致力于.{0,40}提供|"
    r"涵盖[^。；;]{2,80}(?:信贷|银行|基金))"
)


def _sentence_containing(text: str, index: int) -> str:
    start = max(text.rfind(mark, 0, index) for mark in ("。", "；", ";", "\n"))
    start = 0 if start < 0 else start + 1
    end_candidates = [text.find(mark, index) for mark in ("。", "；", ";")]
    end_candidates = [item for item in end_candidates if item >= 0]
    end = min(end_candidates) + 1 if end_candidates else len(text)
    return text[start:end].strip()


def _original_span_matching(text: str, compact_target: str) -> str:
    compact_chars = [
        (index, char) for index, char in enumerate(text) if not char.isspace()
    ]
    compact = "".join(char for _, char in compact_chars)
    start = compact.find(compact_target)
    if start < 0 or not compact_target:
        return ""
    end = start + len(compact_target) - 1
    return text[compact_chars[start][0] : compact_chars[end][0] + 1].strip()


def _overview_source_text(excerpt: str, quote: str, *, heading: str) -> str:
    if not excerpt or not quote:
        return ""
    joined = _join_wrapped_lines(excerpt)
    preferred = _PREFERRED_OVERVIEW_STATEMENT.search(joined)
    if preferred is not None:
        sentence = _sentence_containing(joined, preferred.start())
        text = _original_span_matching(excerpt, re.sub(r"\s+", "", sentence))
        if text and (text in quote or text in excerpt):
            return text
    chosen: list[str] = []
    heading_compact = re.sub(r"\s+", "", heading)
    for sentence in re.split(r"(?<=[。；;\n])", excerpt):
        compact = re.sub(r"\s+", "", sentence)
        if not compact or compact == heading_compact:
            continue
        if overview_dimension_hits(sentence) or heading_compact in compact:
            chosen.append(sentence)
        if chosen and len("".join(chosen)) >= 24:
            break
    text = "".join(chosen).strip() or excerpt.strip()
    if re.sub(r"\s+", "", text) == heading_compact:
        substance = next(
            (
                sentence.strip()
                for sentence in re.split(r"(?<=[。；;\n])", excerpt)
                if _OVERVIEW_SUBSTANCE.search(sentence)
            ),
            excerpt.strip(),
        )
        text = substance
    if text in quote:
        return text
    if excerpt in quote:
        return excerpt
    return quote if quote in excerpt or excerpt in quote else ""


def _revenue_sentence_records(
    selection: CoreEvidenceSelection,
    overview_item: PreparedEvidence,
    *,
    excerpt: str,
    principal_text: str,
) -> tuple[SemanticRecord, ...]:
    """One accepted fact per company revenue sentence, without the text between them."""

    principal = re.sub(r"\s+", "", principal_text)
    records: list[SemanticRecord] = []
    seen: set[str] = set()
    for clause in _reporting_company_revenue_clauses(excerpt):
        if not clause or clause in principal or clause in seen:
            continue
        seen.add(clause)
        source_text = _original_span_matching(excerpt, clause) or clause
        records.append(
            _base_fact(
                BusinessOverview,
                report=selection.report,
                record_id=(
                    f"owned:{overview_item.evidence.evidence_id}:revenue:{len(seen)}"
                ),
                field_id="business_overview_source",
                chapter_task=ChapterTask.EXTRACT_BUSINESS_OVERVIEW,
                evidence=overview_item.evidence,
                source_native=SourceNativeValue(name=clause[:80]),
                source_text=source_text,
            )
        )
    return tuple(records)


def _reporting_company_revenue_clauses(excerpt: str) -> list[str]:
    """Keep the reporting company's own revenue clauses from the same excerpt."""

    joined = _join_wrapped_lines(excerpt)
    clauses: list[str] = []
    for sentence in re.split(r"[。；;]", joined):
        operating_model = _operating_model_source(sentence)
        if operating_model:
            clauses.append(re.sub(r"\s+", "", operating_model))
            continue
        for piece in re.split(r"[，,]", sentence):
            compact = re.sub(r"\s+", "", piece).strip()
            if _is_reporting_company_revenue(compact):
                clauses.append(compact)
    return clauses


def _is_reporting_company_revenue(compact: str) -> bool:
    if not compact or _REVENUE_BLOCK_PATTERN.search(compact):
        return False
    if re.search(r"尚未|还未|仍未|并未|没有|未|不", compact):
        revenue_at = compact.find("营业收入")
        if revenue_at < 0:
            revenue_at = compact.find("收入")
        if revenue_at >= 0 and re.search(
            r"尚未|还未|仍未|并未|没有|未|不",
            compact[:revenue_at],
        ):
            return False
    if "不适用" in compact and "营业收入主要来源于" not in compact:
        return False
    if re.match(r"^(?:报告期内)?(?:本公司|公司)", compact) is None:
        return False
    if re.search(r"[\u4e00-\u9fff]{2,}(?:有限公司|股份有限公司)", compact):
        return False
    return _overview_states_revenue(compact, repair_revenue_sentence=True)


def _activity_object_clauses(clause: str) -> list[str]:
    """Drop service targets in “以……为对象，提供……” and keep the provided services."""

    text = clause.strip()
    provided = re.search(r"以.+?为对象[，,]?\s*提供(.+)", text)
    if provided:
        text = provided.group(1)
    # "为客户提供……服务，收取……费" is one provide-and-collect relationship:
    # the company subject, the service, and the fee collection must stay in
    # a single candidate instead of being split at the comma.
    provide_collect = re.search(
        r"(?:公司|本公司|本集团)?为(?:客户提供|相关客户提供)[^。；;]{2,60}服务[，,]收取[^。；;]{2,80}费",
        text,
    )
    if provide_collect:
        return [text]
    # A following explanation of profit or quality control is not a product
    # or service object, and a regex length bound can cut it mid-clause.
    text = re.split(
        r"[，,](?:业务规模保持|主要品牌|品牌包括|建立|进一步|利润|形成|管理及控股)",
        text,
        maxsplit=1,
    )[0]
    text = re.split(r"[，,]?以及其他", text, maxsplit=1)[0]
    # "旋挖钻机，用于市政建设、公路桥梁……" enumerates where a product is used;
    # the application areas are not company activities.
    used_for = re.search(r"用于", text)
    if used_for:
        text = text[: used_for.start()]
    text = re.split(
        r"[，,](?:[\u4e00-\u9fff]{2,12}领域)?(?:核心|主要)产品[为有]", text, maxsplit=1
    )[0]
    project = re.fullmatch(
        r"(.+?)(发电项目)的(开发、建设、运营与管理)", re.sub(r"\s+", "", text)
    )
    if project:
        # 水力和新能源 share 发电项目 and the same complete action chain.
        return [
            name + project.group(2) + "的" + project.group(3)
            for name in re.split(r"和|、", project.group(1))
        ]
    objects: list[str] = []
    for item in _split_listed(text):
        item = item.strip("，,、；;。 ")
        item = re.sub(r"等[\u4e00-\u9fffA-Za-z0-9（）()]*$", "", item).strip(
            "，,、；;。 "
        )
        if len(item) < 2 or item.startswith("以") or "为对象" in item:
            continue
        objects.append(item)
    return objects


def _split_listed(clause: str) -> list[str]:
    text = _join_pdf_soft_breaks(clause).strip().strip("：:。；;，,")
    text = re.sub(r"(?:等(?:多个领域)?)$", "", text)
    if _looks_like_action_chain(text):
        return [text] if text else []
    parts: list[str] = []
    for chunk in re.split(r"[、；;]|[，,]及?|以及", text):
        parts.extend(item.strip() for item in re.split(r"和", chunk) if item.strip())
    return [
        item
        for item in parts
        if len(item) >= 2 and _VAGUE_OBJECT.fullmatch(item) is None
    ]


def _looks_like_action_chain(text: str) -> bool:
    return len(_ACTION_TOKEN.findall(text)) >= 2


def _object_and_action(
    raw: str,
    default_verb: str,
) -> tuple[str, ActivityAction, str]:
    text = raw.strip()
    if re.fullmatch(r"软件设计与开发", re.sub(r"\s+", "", text)):
        return "软件设计与开发", ActivityAction.DEVELOPS, "设计与开发"
    produced = re.fullmatch(r"利用[^。]{2,30}生产的(.+)", text)
    if produced:
        return produced.group(1), ActivityAction.PRODUCES, "生产"
    if _looks_like_action_chain(text):
        object_name = _ACTION_TOKEN.split(text)[0].strip("的 、") or text
        if "制造" in text or "生产" in text:
            return (
                object_name,
                ActivityAction.PRODUCES,
                "制造" if "制造" in text else "生产",
            )
        if "研发" in text or "开发" in text:
            return (
                object_name,
                ActivityAction.DEVELOPS,
                "研发" if "研发" in text else "开发",
            )
        if "销售" in text:
            return object_name, ActivityAction.SELLS, "销售"
        return object_name, ActivityAction.OPERATES, default_verb
    if any(
        token in text
        for token in ("托管", "银行", "基金", "信贷", "服务", "咨询", "运维")
    ):
        return text[:40], ActivityAction.PROVIDES_SERVICE, default_verb
    if "销售" in text:
        return (
            re.sub(r"的?(?:在线)?销售.*$", "", text) or text,
            ActivityAction.SELLS,
            "销售",
        )
    if "研发" in text or "开发" in text:
        return (
            re.sub(r"的?(?:研发|开发).*$", "", text) or text,
            ActivityAction.DEVELOPS,
            "研发" if "研发" in text else "开发",
        )
    if any(token in text for token in ("制造", "生产", "加工")):
        return (
            re.sub(r"的?(?:制造|生产|加工).*$", "", text) or text,
            ActivityAction.PRODUCES,
            "生产",
        )
    return text[:40], ActivityAction.OPERATES, default_verb


_SEGMENT_SECTION_HEADINGS = {
    "主营业务分行业情况": "industry",
    "主营业务/产品分行业情况": "industry",
    "主营业务分行业": "industry",
    "分行业": "industry",
    "主营业务分产品情况": "product",
    "主营业务分产品": "product",
    "分产品": "product",
    "主营业务分地区情况": "region",
    "主营业务主要地区情况": "region",
    "分地区": "region",
    "主营业务分销售模式情况": "sales_mode",
    "分销售模式": "sales_mode",
}


_GROUP_NAME_TO_DIMENSION = {
    "分销售模式": "sales_mode",
    "分地区": "region",
    "分产品": "product",
    "分行业": "industry",
}


def _open_segment_group(line: str) -> frozenset[str] | None:
    """Return dimensions named together in one formal combined-table heading."""

    compact = _HEADING_PREFIX.sub("", re.sub(r"\s+", "", line.strip()), count=1)
    compact = compact.lstrip(".．、")
    compact = compact.removeprefix("主营业务")
    found = [name for name in _GROUP_NAME_TO_DIMENSION if name in compact]
    if len(found) < 2:
        return None
    remainder = compact
    for name in found:
        remainder = remainder.replace(name, "", 1)
    remainder = re.sub(r"[、，,和及情况模式]", "", remainder)
    if remainder:
        return None
    return frozenset(_GROUP_NAME_TO_DIMENSION[name] for name in found)


def _dimension_from_heading(text: str) -> str | None:
    heading = _heading_if_title_line(text, tuple(_SEGMENT_SECTION_HEADINGS))
    if heading is None:
        return None
    return _SEGMENT_SECTION_HEADINGS[heading]


def _unit_declaration(text: str) -> str:
    match = _UNIT_DECLARATION.search(text)
    return "" if match is None else match.group(0)


def _unit_from_excerpt(excerpt: str) -> str | None:
    joined = _join_rmb_column_header(excerpt)
    match = _UNIT_DECLARATION.search(joined)
    if match is not None:
        return match.group(1)
    native = re.search(
        r"(?:金额单位(?:均)?为|货币单位为)人民币(千元|万元|元)|销售收入[（(](万元|千元|元)[)）]",
        joined,
    )
    if native:
        return native.group(1) or native.group(2)
    if "人民币百万元" in re.sub(r"\s+", "", joined):
        return "百万元"
    return None


def _table_intro_unit(lines: list[str], heading_index: int) -> str | None:
    """The unit stated between a table heading and its first data row.

    An independent table only carries the unit it declares for itself; the
    wording of an earlier table must not flow into it.
    """

    intro: list[str] = []
    for line in lines[heading_index + 1 : heading_index + 13]:
        if _parse_segment_row(line) is not None:
            break
        if (
            _open_segment_group(line) is not None
            or _dimension_from_heading(line) is not None
            or _is_revenue_table_stop(line)
        ):
            break
        intro.append(line)
    if not intro:
        return None
    return _unit_from_excerpt("\n".join(intro))


def _join_pdf_soft_breaks(text: str) -> str:
    normalized = text.replace("\r\n", "\n").replace("\r", "\n")
    normalized = re.sub(
        r"(?m)^([^\n]*\d[^\n]*)[ \t]+(合计|总计)[ \t]*$",
        r"\1\n\2",
        normalized,
    )
    normalized = _PDF_AMOUNT_WRAP.sub(r"\1\2", normalized)
    merged: list[str] = []
    for line in normalized.split("\n"):
        if merged and _is_pdf_soft_continuation(merged[-1], line):
            merged[-1] = f"{merged[-1].rstrip()}{line.lstrip()}"
        else:
            merged.append(line)
    return "\n".join(merged)


def _is_pdf_soft_continuation(previous: str, nxt: str) -> bool:
    prev = previous.rstrip()
    current = nxt.lstrip()
    if not prev or not current:
        return False
    if prev[-1] in "。！？；;：:":
        return False
    if _heading_if_title_line(prev, _ALL_HEADINGS) is not None:
        return False
    if _heading_if_title_line(current, _ALL_HEADINGS) is not None:
        return False
    if _dimension_from_heading(prev) is not None:
        return False
    if _dimension_from_heading(current) is not None:
        return False
    if _UNIT_DECLARATION.search(prev) or _PERCENT_UNIT.search(prev):
        return False
    if _UNIT_DECLARATION.search(current) or _PERCENT_UNIT.search(current):
        return False
    if "营业收入" in prev or "营业成本" in prev or _is_revenue_table_stop(prev):
        return False
    if re.search(r"(?:^|\s)[-/](?:\s+[-/])+$", prev):
        return False
    if prev.endswith("个百分点") or re.match(r"(?:合计|总计)(?:\s+\d|$)", current):
        return False
    if current.startswith(("下表", "项目", "营业收入", "营业总收入", "利息净收入")):
        return False
    if prev.endswith(("、", "，")) and not re.search(r"\d", prev):
        return bool(re.match(r"[\u4e00-\u9fff]", current))
    if (
        _parse_labeled_amount_row(
            current, _COMPANY_TOTAL_LABELS | _INCOME_AMOUNT_LABELS
        )
        is not None
    ):
        return False
    if _parse_segment_row(current) is not None:
        return False
    return bool(
        re.search(r"[\u4e00-\u9fff]$", prev) and re.match(r"[\u4e00-\u9fff]", current)
    )


def _stated_in_quote(text: str, quote: str) -> bool:
    if not text or not quote:
        return False
    if text in quote:
        return True
    return re.sub(r"\s+", "", text) in re.sub(r"\s+", "", quote)


def _parse_segment_row(line: str) -> tuple[str, str, str | None] | None:
    text = line.strip()
    text = re.sub(r"^其中[:：]\s*", "", text)
    text = re.sub(r"^(?:[一二三四五六七八九十]+|\d+)[、.．](?!\d)\s*", "", text)
    if not text:
        return None
    tokens = text.split()
    if len(tokens) < 3:
        return None
    amount_index = next(
        (
            i
            for i, token in enumerate(tokens[1:], 1)
            if re.fullmatch(r"-?[\d,]+(?:\.\d+)?", token)
        ),
        None,
    )
    if amount_index is None:
        return None
    label = "".join(tokens[:amount_index])
    numbers = tokens[amount_index:]
    # A road row names the road with digits ("205 国道天长段新线"); the leading
    # number belongs to the label, not the amount column.
    if (
        label.isdigit()
        and numbers
        and re.search(r"[\u4e00-\u9fff]", numbers[0])
        and not re.fullmatch(r"-?[\d,]+(?:\.\d+)?%?", numbers[0])
    ):
        label = f"{label}{numbers[0]}"
        numbers = numbers[1:]
    if (
        label in _SKIP_SEGMENT_LABELS
        or "年度报告" in label
        or "合计" in label
        or len(numbers) < 2
        or numbers[0] == "营业收入"
        or not (
            re.fullmatch(r"[\u4e00-\u9fffA-Za-z0-9（）()/、—-]{1,40}", label)
            or re.fullmatch(
                r"(?:华东|华北|华中|东北|西北|西南)[：:][\u4e00-\u9fff、，（）()]{2,150}",
                label,
            )
        )
        or not re.fullmatch(r"-?[\d,]+(?:\.\d+)?", numbers[0])
        or not (
            numbers[1] in {"/", "-"}
            or re.fullmatch(r"-?[\d,]+(?:\.\d+)?%?", numbers[1])
        )
    ):
        return None
    return label, numbers[0], numbers[1]


def _complete_current_business_source(excerpt: str) -> str:
    """Keep a multi-business owner's continuous section instead of a sub-branch."""
    compact = re.sub(r"\s+", "", excerpt)
    match = re.search(
        r"公司主要从事[^。]+。(?=[\s\S]*?公司核心业务板块)"
        r"|报告期内，公司聚焦[^。]+主要从事[^。]+。"
        r"|公司主要从事[^。]+。主要产品包括[^。]+。"
        r"|公司是[^。]+，报告期内，公司主营业务收入主要来源于[^。]+。"
        r"|本集团以[^。]+为两大核心主业"
        r"|公司建成[^。]+四大产业板块"
        r"|公司主要从事[^。]+三大类业务。"
        r"|公司主营业务包括[^。]+。(?=[\s\S]*?业务主要包括)"
        r"|报告期内，公司从事的主要业务未发生变化，仍为[^。]+。"
        r"|本公司是以[^。]+为主业的[^。]+。"
        r"|公司是[^。]+所属的专业从事[^。]+综合型能源企业。公司的主要产品是[^。]+。[^。]+已并网[^。]+。",
        compact,
    )
    if not match:
        return ""
    prefix = compact[max(0, compact.rfind("。", 0, match.start()) + 1) : match.end()]
    if re.search(r"第三方|子公司|拟|计划|将|尚未|未建成", prefix):
        return ""
    tail = re.split(
        r"报告期内公司新增重要非主营业务|二、报告期内公司所处行业",
        compact[match.start() :],
        maxsplit=1,
    )[0]
    original = _original_span_matching(excerpt, tail)
    return original


def _current_product_sources(excerpt: str) -> list[str]:
    """Affirmative product disclosures in the owned performance/product section."""
    compact = re.sub(r"\s+", "", excerpt)
    sources: list[str] = []
    patterns = (
        r"主营业务的其他收入系[^。]+。",
        r"公司经过[^。]+主要产品包括[^。]+。",
        r"公司还利用[^。]+。成功开拓了[^。]+产品。",
        r"可降解[^。]{2,100}已实现[^。]{2,100}生产，产品畅销[^。]+。",
        r"[\u4e00-\u9fffA-Za-z]{2,30}突破生产技术瓶颈，已稳定量产[^。]+。",
        r"本集团[^。]{0,40}深化运营[^。]+供应链核心产品[^。]+。",
    )
    for pattern in patterns:
        for match in re.finditer(pattern, compact):
            sentence = compact[
                max(0, compact.rfind("。", 0, match.start()) + 1) : match.end()
            ]
            if re.search(
                r"子公司|第三方|公司拟|公司计划|公司尚未|将销售|尚未销售|未实现",
                sentence,
            ):
                continue
            source = _original_span_matching(excerpt, match.group(0))
            if source:
                sources.append(source)
    return sources


def _native_current_product_bindings(excerpt: str) -> list[tuple[str, str, str | None]]:
    """Current sales bind one product's own performance paragraph, not its uses."""
    compact = re.sub(r"\s+", "", excerpt)
    bindings: list[tuple[str, str, str | None]] = []
    for match in re.finditer(
        r"报告期内，公司(?!拟|计划|将|尚未|未)(?P<name>[\u4e00-\u9fffA-Za-z]{2,30}?)(?:产品)?"
        r"(?:实际)?产量[^。]+。",
        compact,
    ):
        clause = match.group(0)
        if re.search(r"(?:尚未|未|拟|计划|将)销售|未生产", clause):
            continue
        if re.search(r"(?:扣除内部自用后)?销售\d", clause):
            name = match.group("name").removesuffix("产品")
            bindings.append((name, "销售", None))
    for match in re.finditer(
        r"公司累计生产(?P<name>[^。]{2,30}?)\d[^。]+销售\d[^。]+。", compact
    ):
        if not re.search(
            r"子公司|第三方|拟|计划|尚未|将销售|未销售",
            compact[max(0, compact.rfind("。", 0, match.start()) + 1) : match.end()],
        ):
            bindings.append((match.group("name"), "销售", None))
    # PVB胶片的本期生产结构句 explicitly continues to 全年...销售.
    for match in re.finditer(
        r"报告期内，公司根据[^。]+自主调整了(?P<name>[^。]{2,30}?)产品生产结构。"
        r"全年(?P=name)产品实际产量[^。]+销售[^。]+。",
        compact,
    ):
        if not re.search(r"拟|计划|尚未|将销售|未销售", match.group(0)):
            bindings.append((match.group("name"), "销售", None))
    for source in _current_product_sources(excerpt):
        text = re.sub(r"\s+", "", source)
        match = re.match(r"可降解(?P<names>[^。]+?)已实现[^。]+生产，产品畅销", text)
        if match:
            for name in match.group("names").split("、"):
                bindings.append((name, "畅销", None))
    if (
        "产销量情况分析表" in compact
        and "上表中公司主要产品的销售量" in compact
        and not re.search(r"子公司|第三方|公司拟|公司计划|尚未销售|将销售", compact)
    ):
        table = re.split(r"产销量情况分析表", excerpt, maxsplit=1)[0]
        table = _join_segment_label_amounts(
            _join_pdf_soft_breaks(table), core_answer_repair=True
        )
        in_products = "分产品营业收入" in re.sub(r"\s+", "", table)
        for line in table.splitlines():
            dim = _dimension_from_heading(line)
            if dim is not None:
                in_products = dim == "product"
            row = _parse_segment_row(line)
            if in_products and row and row[0] not in {"其他", "水泥及熟料"}:
                bindings.append((row[0], "销售", "营业收入"))
    return list(dict.fromkeys(bindings))


def _native_input_bindings(excerpt: str) -> list[tuple[str, str, str]]:
    """Parse explicit upstream and purchase/consumption columns, never downstream."""
    bindings: list[tuple[str, str, str]] = []
    compact = re.sub(r"\s+", "", excerpt)
    if "母子公司" in compact and "产品说明及用途" in compact:
        for name in ("木片", "竹片", "漂白助剂"):
            if re.search(r"(?:保留|加入)" + name, compact):
                bindings.append((name, "投入", "母公司产品生产工艺原料"))
    for m in re.finditer(r"以自产的([^。]+?)和外购的([^。]+?)为主要原料", compact):
        for name in [*m[1].split("、"), *m[2].split("、")]:
            bindings.append((name, "投入", "自产与外购实际原料"))
    if "公司开采自有磷矿资源" in compact and "磷矿石作为磷肥" in compact:
        bindings.append(("磷矿石", "投入", "开采及外购矿石实际原料"))
    if "以磷肥副产氟硅酸为原料" in compact:
        bindings.append(("氟硅酸", "投入", "氟化工实际原料"))
    if "公司水富基地采购煤作为原料生产甲醇" in compact:
        bindings.extend(
            [("煤", "投入", "水富甲醇原料"), ("甲醇", "投入", "聚甲醛及季戊四醇原料")]
        )
    material = re.search(
        r"公司生产经营及工程项目建设所需的主要原材料包括([^。]+?)等。", compact
    )
    if material and not re.search(r"(?:拟|计划|尚未|未开展|第三方)", material.group()):
        for name in material[1].split("、"):
            bindings.append((name, "投入", "生产经营及工程建设实际所需原材料"))
    if re.search(r"优化精益养殖[\s\S]+?依托精准饲料利用", compact) and not re.search(
        r"第三方|拟依托|计划依托|未利用", compact
    ):
        bindings.append(("饲料", "投入", "养殖实际饲料利用"))
    for match in re.finditer(
        r"(?:本公司|公司)(?:持续深化[^。]+，)?提升(?P<names>[^。]+?)等[^。]+应用比例",
        compact,
    ):
        if not re.search(r"未|不|拟|计划|将", match.group()):
            for name in match["names"].split("、"):
                if re.fullmatch(r"[\u4e00-\u9fff]{2,12}", name):
                    bindings.append((name, "投入", "速生材实际应用"))
    for m in re.finditer(
        r"公司核心产品[“\"][^”\"]+[”\"]以(?P<name>[^。]{2,20})为原料", compact
    ):
        if not re.search(r"拟|计划|未使用|不使用", m.group()):
            bindings.append((m["name"], "投入", "核心产品原料"))
    normalized = excerpt.replace("\r\n", "\n").replace("\r", "\n")
    normalized = re.sub(r"主要上游原材\s*料", "主要上游原材料", normalized)
    normalized = re.sub(
        r"化学原料及化\s*[学工]制品制造业", "化学原料及化学制品制造业", normalized
    )
    normalized = re.sub(r"电石渣及其他\s*废弃物", "电石渣及其他废弃物", normalized)
    # The formal company product table declares upstream and downstream columns.
    header = re.search(
        r"产品\s+所属细分行业\s+主要上游原材料\s+主要下游应用领域", normalized
    )
    if header and not re.search(
        r"子公司|第三方|拟|计划", normalized[: header.start()][-120:]
    ):
        table = re.split(
            r"[（(]3[)）][.．]?研发创新", normalized[header.end() :], maxsplit=1
        )[0]
        # Each native row starts with product and industry. Within the upstream
        # cell, a horizontal space starts the next column (except Latin names).
        # Soft-wrapped list cells continue until that column boundary.
        current: str | None = None
        upstream = []
        for line in table.splitlines():
            row = re.search(
                r"(?:^|\s)(?:化工|磷化工|化纤|建材|新材料|电力行业|水泥行业|化学原料及化学制品制造业)(?:\s+(.*)|$)",
                line,
            )
            if row:
                if current:
                    upstream.append(current)
                current = row.group(1) or ""
            elif current is not None:
                if (
                    not current
                    or current.endswith(("、", "，"))
                    or re.match(r"[\u4e00-\u9fff](?:[、，]| +\d+[.．])", line)
                ):
                    current += line.strip()
                else:
                    if current:
                        upstream.append(current)
                    current = None
                    continue
            else:
                continue
            current = re.sub(r"([A-Z]{2,}) +(?=[\u4e00-\u9fff])", r"\1", current)
            boundary = re.search(r" +(?=[\u4e00-\u9fff])", current)
            if boundary:
                upstream.append(current[: boundary.start()])
                current = None
        if current:
            upstream.append(current)
        for cell in upstream:
            # Route names describe production processes, not purchased objects.
            cell = re.sub(r"\d+[.．][^：:]+[：:]", "、", cell)
            for name in re.split(r"[、，]| +(?=\d+[.．])", cell):
                name = re.sub(r"\s+", "", name)
                if re.fullmatch(r"[\u4e00-\u9fffA-Za-z]{1,20}", name) and name not in {
                    "助剂",
                    "其他聚合乳液",
                    "其他聚合",
                }:
                    bindings.append((name, "投入", "主要上游原材料"))
    if "采购量" in normalized and "耗用量" in normalized:
        section = ""
        for line in normalized.splitlines():
            compact = re.sub(r"\s+", "", line)
            if "主要原材料" in compact and "基本情况" in compact:
                section = (
                    ""
                    if re.search(r"子公司|第三方|拟|计划|尚未", compact)
                    else "原材料"
                )
            if "主要能源" in compact and "基本情况" in compact:
                section = (
                    "" if re.search(r"子公司|第三方|拟|计划|尚未", compact) else "能源"
                )
            match = re.match(
                r"\s*([\u4e00-\u9fffA-Za-z]{1,18})\s+(?:外购|招投标|直接采购|市场化采购|定向采购|市场采购)\s+[^\n]+",
                line,
            )
            if match and section and len(re.findall(r"[\d,]+\.\d+", line)) >= 3:
                header = (
                    "能源"
                    if section == "能源" or match.group(1) in {"电煤", "燃煤"}
                    else section
                )
                bindings.append((match.group(1), "采购", header))
                bindings.append((match.group(1), "投入", header))
    for m in re.finditer(
        r"产品采用[^。]+，[\u4e00-\u9fff、和]{2,40}的混合物通过[^。]+", compact
    ):
        if not re.search(r"第三方|未|不|拟|计划|将", m.group()):
            cell = re.search(r"，([\u4e00-\u9fff、和]{2,40})的混合物", m.group())[1]
            for name in re.split(r"、|和", cell):
                bindings.append((name, "投入", "生产工艺原料"))
    # Deduplicate the same native input stated by table and procurement disclosure.
    return list(dict.fromkeys(bindings))


def _owned_business_sources(excerpt: str) -> list[str]:
    """Complete current company/group passages, each retaining its original actor."""
    compact = re.sub(r"\s+", "", excerpt)
    patterns = (
        r"公司主营业务包括[^。]+。[\s\S]+?(?=二、报告期内公司所处行业|$)",
        r"公司主要从事[^。]+三大类业务。[\s\S]+?(?=（二）公司市场地位|$)",
        r"公司生产经营及工程项目建设所需的主要原材料包括[^。]+。",
        r"关联托管/承包情况说明[\s\S]+?(?=本公司委托管理/出包情况表|$)",
        r"公司全面统筹布局重点国别市场[\s\S]+?待履行合同金额[^。]+。",
        r"具体会计政策描述如下：[\s\S]+?在提供管理服务期间确认收入。",
        r"本公司根据在向客户转让商品或服务前[\s\S]+?本公司在该时点确认收入实现。",
        r"[（(]3[)）]\.?履约义务的说明[\s\S]+?款到发货[\s\S]+?(?=[（(]4[)）]|$)",
        r"[\u4e00-\u9fff]{2,12}业务主要由子公司[^。]+从事[\s\S]+?(?=报告期内公司新增重要非主营业务|$)",
        r"报告期内，[“\"]其他[”\"]业务的营业收入[^。]+公司饲料贸易业务板块业务规模下降。",
        r"在主业方面，公司主营业务为[^。]+。[\s\S]+?公司参股[^。]+。",
        r"本公司的主要营业收入系高速公路车辆通行费收入[\s\S]+?本公司及子公司[^。]+均按[^。]+确认通行费收入。",
        r"①在某一时点确认收入[\s\S]+?成本加成总承包合同：[\s\S]+?确定履约进度。",
        r"风电主机装备业务及关键配套业务主要包括[^。]+。公司通过招投标[^。]+。",
        r"(?:本公司|公司)是[^。]{2,100}其主要业务为[^。]+。",
        r"(?:本公司|公司)是一家集[^。]+主要产品覆盖[^。]+。",
        r"本公司属[^。]+主要业务为[^。]+。",
        r"本公司及其子公司[（(]以下简称[“\"]本集团[”\"][)）]主要从事[^。]+。",
        r"截至报告期末，本公司已投入运行[^。]+。主要包括[^。]+自用光伏[^。]+。",
        r"本公司通过大比例参股[^。]+。本公司适应[^。]+综合能源服务[^。]+。",
        r"本公司先后在[^。]+设立专业化售电公司[^。]+综合能源业务。\d{4}年，本公司所属售电公司[^。]+。",
        r"本集团的营业收入主要包括[^。]+。[\s\S]+?此收入[^。]+。",
        r"公司紧扣[^。]+为客户提供[^。]+车队管理服务[^。]+。",
        r"公司的业务覆盖[^。]+订单模式[^。]+。",
        r"公司在海外市场采取[^。]+销售模式[^。]*。[^。]+；同时[^。]+KD组装[^。]+品牌授权[^。]+。",
        r"本公司有\d+个报告分部：[^。]+。",
        r"[\u4e00-\u9fff]+股份有限公司[（(]以下简称[“\"]本公司[”\"][)）]及其子公司[（(]以下统称[“\"]本集团[”\"][)）]主要从事[^。]+。",
        r"本集团拥有[^。]+业务分部。[^。]+。其他业务分部主要包括[^。]+。",
        r"报告期内，本集团稳步提高运行质量[^。]+。[\s\S]+?推广[^。]+服务[^。]+。",
        r"公司持续开展[^。]+。通过[^。]+打造[^。]+服务产品[^。]+。",
        r"公司坚持以[^。]+业务为核心[^。]+。",
        r"(?:此外，)?公司立足于现有存量资产[^。]+物业管理服务业务。公司依托[^。]+。",
        r"公司房地产业务实现合同销售面积[^。]+实现主营业务收入[^。]+同比增长[^。]+。",
        r"报告期内，公司房地产出租总收入[^。]+。",
        r"本集团将票款收入按照[^。]+。",
        r"当客户接受本集团提供的[^。]+与此同时，本集团[^。]+。本集团已收但尚未提供[^。]+。",
        r"本集团主要执行[^。]+常旅客[^。]+。会员可[^。]+。[\s\S]+?会员兑换的其他奖励[^。]+。",
        r"[\u4e00-\u9fff]+收入(?:是)?指本集团向[^。]+。",
        r"报告期内公司存在贸易业务收入[\s\S]+?等贸易业务\d+[\d,]*",
        r"本集团按不同地区列示[^。]+：[\s\S]+?具体对外交易收入的信息见下表：",
        r"本公司电力销售在[^。]+。具体如下：[\s\S]+?B、向用户[^。]+。",
        r"本公司电力销售在[^。]+，具体如下：[\s\S]+?B、向用户[^。]+。",
        r"公司牢固树立精益管理理念[\s\S]+?持续深化中长期、现货、绿电交易、绿证交易[^。]+。",
        r"(?:公司的分布式|公司分布式)[^。]+自发自用[^。]+余电上网[^。]+。",
        r"基于多年服务全球客户[^。]+公司[^。]+OEM&ODM[^。]+。[^。]+。",
        r"锂电池业务本期仅统计[^。]+。",
        r"\d{4}年\d{1,2}月，公司在[^。]+后更名为[^。]+。\d{4}年\d{1,2}月\d{1,2}日[^。]+公司丧失[^。]+合并范围。",
        r"本公司与[^。]+之间存在购销商品、提供服务的关联交易[^。]+。",
        r"公司部分光伏发电项目属于[^。]+自发自用、余电上网[^。]+。",
        r"公司[^。]+持续深化中长期、现货、绿电交易、绿证交易[^。]+。",
        r"其他业务：主要为绿证交易业务，本期交易量[^。]+营业收入[^。]+。",
        r"[（(]3[)）]\.履约义务的说明[\s\S]+?月结[^。]+?合计[^。]+?(?=[（(]4[)）])",
        r"本公司按照业务类型确定的收入确认具体原则和计量方法：[\s\S]+?根据合同或订单，公司在取得出口报关单时确认收入。",
    )
    sources = []
    for pattern in patterns:
        for m in re.finditer(pattern, compact):
            if m.start() and compact[m.start() - 1] in "子方":
                continue
            prefix = compact[max(0, compact.rfind("。", 0, m.start()) + 1) : m.start()]
            if re.search(
                r"(?:第三方|子公司)(?:公司|企业)?(?:拟|计划)?$|(?:公司|本集团)(?:拟|计划|尚未|将)$",
                prefix,
            ):
                continue
            if re.search(r"(?:本公司|公司)(?:拟|计划|将|尚未)|未开展", m.group()):
                continue
            if m.group().startswith(
                "基于多年服务全球客户"
            ) and not _current_company_sentence(m.group()):
                continue
            original = _original_span_matching(excerpt, m.group())
            if original:
                sources.append(original)
    return list(dict.fromkeys(sources))


def _owned_operating_passages(excerpt: str) -> list[str]:
    """Keep complete owned operations and accounting passages, including status.

    These are narrative evidence, not affirmative commodity actions. A trial,
    promotion, associate or asset disposal remains qualified in the answer.
    """
    compact = re.sub(r"\s+", "", excerpt)
    patterns = (
        r"[（(]3[)）]收入确认的具体方法[\s\S]+?(?=\d+[．、]合同取得成本|$)",
        r"[^。]{0,120}上年计算机硬件业务出表[^。]+。",
        r"[（(]1[)）]本年丧失子公司控制权的交易或事项[\s\S]+?(?=\d+[.．、]其他|$)",
        r"[（(]2[)）]公司作为出租人[\s\S]+?(?=[（(]3[)）]售后租回|$)",
        r"本集团收入确认的具体方法如下：[\s\S]+?(?=[（(]2[)）]\.同类业务|\d+、合同成本|$)",
        r"报告期内，公司聚力深耕市场[\s\S]+?(?=（二）数智产业|$)",
        r"公司聚焦知识服务、数智转型服务[\s\S]+?(?=[（(]2[)）]\.产销量|$)",
        r"[（(]1[)）]20\d{2}年\d+月\d+日，本公司与[^。]+签订[\s\S]+?成为[^。]+100%控股的全资子公司。",
        r"危化品仓储业务[^。]+。",
        r"整车产销量[\s\S]+?(?=按地区|$)",
        r"[^。]*独立储能项目[^。]+。",
        r"本集团生产整车及零部件等产品并销售予相关客户。[\s\S]+?完成相关货物交接后确认收入。",
        r"本集团在客户取得相关商品或服务的控制权时[\s\S]+?(?=[（(]2[)）]\.同类业务|\d+、合同成本|$)",
        r"本公司主要收入确认具体方法如下：[\s\S]+?(?=[（(]2[)）]|\d+、合同成本|$)",
        r"公司从事绿色低碳综合智慧能源[\s\S]+?(?=报告期内公司新增重要非主营业务|二、报告期内公司所处行业|$)",
        r"本公司从事电力、煤炭[\s\S]+?(?=本公司在中国|$)",
        r"本公司从事能源业务，主要包括：[\s\S]+?托管费以及其他管理咨询费。",
        r"报告期内，公司扎实推进全面深化改革[\s\S]+?(?=四、报告期内核心竞争力|$)",
        r"本公司主营业务包含[^。]+通过下属全资子公司[^。]+。",
        r"截至报告日，公司完成对[^。]+参股项目[^。]+。[\s\S]+?筹备阶段。",
        r"注\d+：[^。]+成立于\d{4}年[^。]+。[\s\S]+?(?=注\d+：|\d+、重大的|六、|$)",
        r"公司的主要经营模式[\s\S]+?(?=报告期内公司新增重要非主营业务|二、报告期内公司所处行业|$)",
        r"公司及子公司主要产品及用途如下：[\s\S]+?(?=\d+、公司的主要经营模式|$)",
        r"（2）具体方法①[^。]+销售业务[\s\S]+?(?=[（(]2[)）]\.同类业务|\d+、合同成本|$)",
        r"[（(]3[)）]\.履约义务的说明[\s\S]+?(?=[（(]4[)）]|$)",
        r"公司控股子公司[^。]+采购先进计算技术服务[^。]+按月分期支付。",
        r"对于本集团自第三方取得商品控制权后[\s\S]+?本集团以完成商品交付[^。]+。",
        r"本公司各个报告分部提供的主要产品及劳务分别为：[\s\S]+?(?=分部报告信息|[（(]2[)）]|$)",
        r"本公司[^。\n]*?(?:确定经营分部|报告分部)[^。]+。",
        r"本公司收入主要来源于以下业务类型[\s\S]+?本公司海上运输收入在航次结束时确认收入。",
        r"(?:一是|二是|三是)?[^。]{0,30}(?:资源对接|用工保障)[^。]+。",
        r"通过加强国家自主创新示范区政策研究[^。]+政策咨询服务[^。]+。",
        r"ALBO公司围绕品牌升级[\s\S]+?(?=康隆公司|四、报告期内核心竞争力|$)",
        r"报告期内，分行业和分产品情况表中[“\"]商品销售业务[”\"]板块[^。]+。",
        r"母公司财务报表主要项目注释[\s\S]+?营业收入和营业成本[\s\S]+?(?=\d+、|$)",
        r"(?:(?<=不适用)|(?<=。)|^)[\u4e00-\u9fff]+有限公司为公司联营企业，本期采购发生额为[^。]+不再是公司信息披露口径的关联方[^。]+。",
        r"公司以化肥产业为基础[\s\S]+?(?=报告期内调整经营模式|$)",
        r"公司主要开展[^。]+贸易[^。]+。[\s\S]+?(?=三、经营情况讨论与分析|$)",
        r"本集团的营业收入主要包括自产品销售收入、贸易业务收入。[\s\S]+?国际转口贸易业务依据提单按总额法确认收入。",
        r"本公司根据在向客户转让商品或服务前是否拥有[\s\S]+?佣金或手续费的金额确认收入。",
        r"一是深化营销体系转型[\s\S]+?(?=（二）|\(二\)|$)",
        r"一是同仁堂国药聚焦核心业务发展[\s\S]+?(?=四、报告期内核心竞争力|$)",
        r"同仁堂科技中药创新药[^。]+Ⅱ期临床试验[^。]+。",
        r"[^。③④]{2,40}与海外经营实体签订商标[^。]+。",
        r"公司着力构建中药全产业链协同发展体系[\s\S]+?(?=（四）|\(四\)|$)",
        r"同仁堂商业下属零售药店[\s\S]+?(?=2、其他说明|$)",
        r"其他原因的合并范围变动[\s\S]+?(?=6、其他|$)",
        r"公司以服务收益和规模集拼收益为核心[\s\S]+?(?=报告期内公司新增重要非主营业务|$)",
        r"公司物流体系[\s\S]+?(?=（三）|\(三\)|$)",
        r"新能源物流方面[\s\S]+?(?=（三）|\(三\)|$)",
        r"公司作为以传统中成药生产与销售为主[\s\S]+?(?=在销售方面|$)",
        r"本公司生产制造分部商品销售[\s\S]+?提供广告服务的收入于提供服务的会计期间内确认收入。",
        r"公司及下属子公司拥有多家药材种植基地[\s\S]+?为公司制定相关策略提供有力支撑。",
        r"④本公司及控股子公司为[\s\S]+?(?=⑤|$)",
        r"公司主营业务为中成药的生产与销售[\s\S]+?(?=报告期内公司新增重要非主营业务|$)",
        r"⑤本公司及控股子公司向[\s\S]+?(?=（2）|\(2\)|$)",
        r"各业务类型收入确认和计量具体政策[\s\S]+?(?=[（(]2[)）]\.同类业务|\d+、合同成本|$)",
        r"重大的股权投资[\s\S]+?(?=\d+、重大的非股权投资|$)",
        r"零部件产销量[\s\S]+?(?=产品销售|其他说明|$)",
        r"报告期内公司从事的业务情况[\s\S]+?(?=报告期内公司新增重要非主营业务|二、报告期内公司所处行业|$)",
        r"报告期内，公司所从事的主要业务为[\s\S]+?(?=四、报告期内核心竞争力|$)",
        r"公司主要从事商品贸易[\s\S]+?公司已就该产品或服务享有现时收款权利。",
        r"公司主要采用以销定产[\s\S]+?公司产品销售以[^。]+。",
        r"本公司具体的收入确认原则如下：[\s\S]+?(?=[（(]2[)）]\.|\d+、合同成本|$)",
        r"本公司的营业收入主要包括[\s\S]+?(?=[（(]2[)）]\.同类业务|\d+、合同成本|$)",
        r"[（(]一[)）]农业产业经营情况[\s\S]+?(?=四、报告期内核心竞争力|$)",
        r"全资子公司[^。]+投运首座[^。]+。全资子公司[^。]+建成投运[^。]+。",
        r"在合营企业或联营企业中的权益[\s\S]+?将其作为权益法核算的合营企业。",
        r"产销量情况分析表[\s\S]+?(?=产销量情况说明|成本分析表|$)",
        r"全资子公司[^。]+作为增量配网售电企业[\s\S]+?按照批零差价部分确认收入[^。]*。",
        r"报告期内，全资子公司[^。]+通过电力设施校验、维护[^。]+。",
        r"管理费用变动原因说明：[\s\S]+?不再纳入合并财务报表范围[^。]*。",
        r"报告期内，公司共实现营业收入[^。]+。其中：医药工业产品收入[^。]+。",
        r"报告期内，公司实现归属母公司所有者的净利润[\s\S]+?上年同期处置全资子公司[^。]+100%股权[^。]*。",
        r"主要研发项目基本情况[\s\S]+?(?=[（(]3[)）]|$)",
        r"公司核心产品[“\"]([^”\"]+)[”\"]以[^。]+为原料[^。]*。",
        r"作为出租人的经营租赁[\s\S]+?(?=作为出租人的融资租赁|$)",
        r"转租使用权资产取得的收入\d[\d,]*\.\d{2}(?:\d[\d,]*\.\d{2})?",
        r"在重组完成后，公司[\s\S]+?(?=[（(]三[)）]主要业绩|$)",
        r"本公司根据在向客户转让商品或服务前[\s\S]+?本公司为代理人[\s\S]+?等确定。",
        r"公司已成长为[^。]+。",
        r"公司主要药[（(]产[)）]品情况如下：[\s\S]+?注：[^。]+。",
        r"公司药[（(]产[)）]品销售情况[\s\S]+?(?=[（(]2[)）]\.销售费用|$)",
        r"(?:[\u4e00-\u9fff]{2,12}|[A-Za-z]+(?:[A-Za-z]+)?)[（(](?:公司|全资子公司)持有其[^。]+股权[)）][\s\S]+?(?=(?:[\u4e00-\u9fff]{2,12}|[A-Za-z]+)[（(](?:公司|全资子公司)持有其|$)",
        r"本公司按照业务类型确定的收入确认具体原则和计量方法：[\s\S]+?(?=[（(]2[)）]|\d+、合同成本|$)",
        r"\d{4}年，[\u4e00-\u9fff]+聚焦[^。]+两大主业[^。]+。",
        r"联网通信发展稳健。[\s\S]+?(?=高品质网络能力|$)",
        r"注\d+[：:]\w+业务包含[^。]+。",
        r"本公司目前只直接持有[\s\S]+?统称[“\"]本集团[”\"]。",
        r"本集团在履行了合同中的履约义务[\s\S]+?(?=\d+、\s*(?!收入确认)[\u4e00-\u9fff]+|$)",
        r"本集团对于提供的[\s\S]{0,200}?具体会计政策描述如下：[\s\S]+?营业成本。",
        r"本集团的收入主要来自于[\s\S]+?未披露剩余履约义务的相关信息。",
        r"综合服务包括[^。]+。相关定价或收费标准[^。]+。",
        r"公司深耕[^。]+提供[^。]+。[^\n]*[\s\S]+?(?=报告期内公司新增重要非主营业务|$)",
        r"不动产经营方面，[\s\S]+?(?=四、报告期内主要经营情况|$)",
        r"公司立足[^。]+。公司着力[^。]+。公司作为[^。]+目前已形成[\s\S]+?(?=报告期内调整经营模式|$)",
        r"目前公司的[^。]+主要有[^。]+。[^。]+产品主要供应[^。]+。",
        r"(?:公司的收入|公司营业收入)主要包括[\s\S]+?(?=\(?二十八\)?合同成本|\d+、合同成本|$)",
        r"公司主要负责[^。]+。[^。]+。",
        r"报告期内，公司聚焦[\s\S]+?(?=报告期内公司新增重要非主营业务|$)",
        r"公司主要从事[^。]+。主要产品包括[\s\S]+?(?=报告期内公司新增重要非主营业务|二、报告期内公司所处行业|$)",
        r"公路投资运营方面：[\s\S]+?公司参股[^。]+。",
        r"主要系公司战略调整，[^。]+年末完成出表[^。]+。",
        r"本集团的营业收入主要包括[\s\S]+?7公路养护收入[\s\S]+?直到履约进度能够合理确定为止。",
        r"公司不同销售方式下收入的确认方法：[\s\S]+?直到履约进度能够合理确定为止。",
        r"公司持续深化[^。]+提升[^。]+。[^。]+成功开发[^。]+。",
        r"公司于\d{4}年[\s\S]+?公司不再纳入公司财务报表合并范围内。",
        r"本期是否存在丧失子公司控制权的交易或事项[\s\S]+?(?=其他说明|$)",
        r"作为出租方的租赁分类标准和会计处理方法[\s\S]+?(?=[（(]二[)）]承租人|$)",
        r"[\u4e00-\u9fff]{2,20}以[^。]+深耕[^。]+两大核心领域[^。]+。",
        r"公司氯碱化工生产工艺主要为[^。]+。",
        r"如上图所示：[\s\S]+?(?=报告期内公司新增重要非主营业务|$)",
        r"公司生产的产品在满足自身[^。]+。[\s\S]+?线下通过[^。]+。",
        r"公司已建成[^。]+具备提供[^。]+。",
        r"公司开发了[^。]+。",
        r"公司依托当地[^。]+自备热电站[^。]+。",
        r"争力的关键所在。[^。]+。目前，[^。]+并网发电[^。]*。",
        r"\d{4}年，公司全资子公司[^。]+成功试车[^。]+。",
        r"按照业务类型披露具体收入确认方式及计量方法[\s\S]+?(?=[（(]2[)）]|\d+、合同成本|$)",
        r"本公司按照业务类型确定的收入确认具体原则和计量方法：[\s\S]+?公司根据出口货物报关单注明的出口日期确认收入。",
        r"本公司销售商品的业务包括[^。]+。本公司为履约义务的主要责任人[^。]+。",
        r"本公司作为出租人[\s\S]+?本公司按照固定的周期性利率[^。]+。",
        r"由于管道杆路租赁收入[^。]+。本期扣除的其他业务收入[^。]+。",
        r"为配合落实[^。]+公司以全资子公司[^。]+有线电视网络资产[\s\S]+?本次交易完成。",
        r"[（(]四[)）]紧抓政企业务[\s\S]+?(?=[（(]五[)）]|$)",
        r"[（(]三[)）]全力办好[\s\S]+?(?=[（(]四[)）])",
        r"自主研发[^。]+一体化电视方案[\s\S]+?业务支撑能力[^。]+。",
        r"主要控股参股公司分析[\s\S]+?(?=报告期内取得和处置子公司的情况|$)",
        r"经公司[^。]+决议，[\s\S]+?均在公司合并报表范围内。",
        r"企业集团的构成[\s\S]+?(?=\d+、|$)",
        r"产销量情况说明[\s\S]+?(?=[（(]3[)）]\.?重大采购|$)",
        r"出售商品/提供劳务情况表[\s\S]+?(?=购销商品、提供和接受劳务的关联交易说明|$)",
        r"主营业务分行业、分产品、分地区、分销售模式情况的说明[\s\S]+?(?=[（(]2[)）]|$)",
        r"\d{4}年\d{1,2}月，公司全资子公司[^。]+已成功打通全流程[^。]+。[\s\S]+?产能结构优化[^。]+。",
        r"本公司作为出租方：[\s\S]+?(?=本公司作为承租方|关联租赁情况说明|$)",
        r"报告期内取得和处置子公司的情况[\s\S]+?(?=其他说明|$)",
        r"[\u4e00-\u9fff]{2,40}有限公司公司参股子公司[\s\S]+?(?=其他说明|$)",
        r"劣势：一是[^。]+产能释放阶段[^；]+；",
        r"[（(]三[)）]项目支撑持续稳固[\s\S]+?(?=[（(]四[)）]|$)",
        r"[（(]四[)）]一体两翼持续推进[\s\S]+?(?=[（(]五[)）]|四、报告期内核心竞争力|$)",
        r"本公司收入确认的具体方法如下：[\s\S]+?(?=[（(]2[)）]\.同类业务|\d+、合同成本|$)",
        r"本公司主要通过线下、线上[\s\S]+?本公司收入确认具体方法如下：[\s\S]+?(?=[（(]2[)）]\.同类业务|\d+、合同成本|$)",
        r"本公司没有重要的合营或联营企业。公司的联营企业[\s\S]+?不构成公司的重要组成部分。",
        r"按照相关协议和文件精神，本公司为[^。]+代收代付事项处理[^。]+。",
        r"根据意见，明确本次[^。]+。[\s\S]+?本公司确认[^。]+元。",
        r"公司作为国内领先的集[^。]+。报告期内，公司核心竞争力主要为：[\s\S]+?(?=3\.品质优势|$)",
        r"\d+、产品情况[\s\S]+?(?=\d+、原料采购情况|$)",
        r"[（(]2[)）]\.采购金额[\s\S]+?(?=\d+、销售情况|$)",
        r"公司沿用的采购模式为[\s\S]+?(?=具体采购模式详见下图|$)",
        r"公司的销售系统及其下属子公司[\s\S]+?(?=[（(]2[)）]\.销售渠道|$)",
        r"公司与经销商每年签订一次[\s\S]+?进行了明确规定。",
        r"公司销售系统与经销商签订销售合同，[\s\S]+?提供适当账期。",
    )
    sources = []
    for pattern in patterns:
        for match in re.finditer(pattern, compact):
            prefix = compact[
                max(0, compact.rfind("。", 0, match.start()) + 1) : match.start()
            ]
            if re.search(r"第三方|(?:公司|本集团)(?:拟|计划|尚未|不从事)$", prefix):
                continue
            original = _original_span_matching(excerpt, match.group())
            if original:
                sources.append(re.sub(r"\s+", "", original))
    return list(dict.fromkeys(sources))


def _accounting_supplement_spans(pages, report_year):
    """Select the declared current income tables missed by generic note headings."""
    spans = []
    unit_line = ""
    unit_page = None
    cues = (
        "合并利润表",
        "母公司利润表",
        "前五名客户的营业收入",
        "利息净收入",
        "子公司名称",
        "在某一时点确认",
        "对外交易收入总额",
        "向关联方收取之贷款利息收入如下",
        "向关联方收取之利息收入如下",
        "从关联方取得之手续费收入如下",
        "作为出租人的融资租赁",
    )
    for page in pages:
        if not page.readable:
            continue
        text = page.layout_text or page.text
        declarations = [line for line in text.splitlines() if _unit_from_excerpt(line)]
        if declarations:
            unit_line, unit_page = declarations[-1], page.page
        compact = re.sub(r"\s+", "", text)
        if "子公司名称" in compact and "基本情况" in compact:
            start = text.find("子公司名称")
            declarations_before = list(
                re.finditer(r"单位[：:]\s*亿元[^\n]*", text[:start])
            )
            if declarations_before:
                text = text[declarations_before[-1].start() :]
                compact = re.sub(r"\s+", "", text)
        if not any(cue in compact for cue in cues):
            continue
        # A subsidiary-name column in a balance sheet is not a financial-business table.
        if not any(cue in compact for cue in cues if cue != "子公司名称") and not (
            "子公司名称" in compact and "基本情况" in compact and "营业收入" in compact
        ):
            continue
        if "在某一时点确认" in compact and "主营业务收入" in compact:
            text = re.split(
                r"(?m)^\s*" + str(int(report_year) - 1) + r"\s*年度", text, maxsplit=1
            )[0]
        if unit_line:
            text = unit_line + "\n" + text
        if not _unit_from_excerpt(text):
            continue
        spans.append(
            CoreEvidenceSpan(
                page=page.page,
                section_title="补充财务原格",
                excerpt=text,
                bounded_quote=text,
                continuation_pages=(unit_page,)
                if unit_page and unit_page != page.page
                else (),
                chapter_task=ChapterTask.EXTRACT_SEGMENT_FINANCIALS.value,
                field_ids=("segment_dimension", "operating_revenue"),
                context_complete=True,
            )
        )
    return spans


def _headed_segment_income_rows(text):
    """Use full physical column edges for sparse external/internal revenue cells."""
    lines = text.replace("\r", "").splitlines()
    head = next(
        (
            i
            for i, line in enumerate(lines)
            if re.search(r"项目\s{2,}", line)
            and "分部间抵销" in line
            and "合计" in line
        ),
        None,
    )
    if head is None or not any("对外交易收入" in line for line in lines[head:]):
        return None
    cells = list(re.finditer(r"\S+", lines[head]))[1:]
    centers = [(m.start() + m.end()) / 2 for m in cells]
    names = [m.group() for m in cells]
    cursor = head + 1
    while cursor < len(lines) and not re.search(r"-?\d[\d,]*\.\d{2}", lines[cursor]):
        for m in re.finditer(r"\S+", lines[cursor]):
            col = min(
                range(len(cells)),
                key=lambda j: abs(centers[j] - (m.start() + m.end()) / 2),
            )
            names[col] += m.group()
        cursor += 1
    full = next(
        (
            list(re.finditer(r"-?\d[\d,]*\.\d{2}", line))
            for line in lines[cursor:]
            if len(re.findall(r"-?\d[\d,]*\.\d{2}", line)) == len(cells)
        ),
        None,
    )
    if not full:
        return None
    edges = [m.end() for m in full]
    rows = []
    for line in lines[cursor:]:
        basis = next(
            (
                b
                for b in ("对外交易收入", "分部间交易收入")
                if re.sub(r"\s+", "", line).startswith(b)
            ),
            None,
        )
        if not basis:
            continue
        used = set()
        for m in re.finditer(r"-?\d[\d,]*\.\d{2}", line):
            col = min(range(len(edges)), key=lambda j: abs(edges[j] - m.end()))
            if col in used:
                continue
            used.add(col)
            adjustment = (
                RowClass.CONSOLIDATION_ADJUSTMENT if "抵销" in names[col] else None
            )
            rows.append(
                (
                    "adjustment" if adjustment else "business_segment",
                    names[col],
                    m.group(),
                    basis,
                    adjustment,
                )
            )
    return rows


def _accounting_supplement_rows(text):
    """Read explicit original financial headings without borrowing empty cells."""
    rows = []
    compact = re.sub(r"\s+", "", text)

    def add(name, value, header, dim="business_type", qualifier=None):
        rows.append((dim, name, value, header, None, qualifier))

    def simple(block, header, dim="business_type", qualifier=None):
        prior = _prior_only_income_labels(block)
        for line in block.splitlines():
            m = re.match(r"\s*(.+?)\s+(-?\d[\d,]*\.\d{2})", line)
            if not m:
                continue
            name = re.sub(r"\s+", "", m[1])
            if name in prior or re.search(
                r"单位|年度|项目|客户名称|其中|适用|人民币", name
            ):
                continue
            q = qualifier(name) if callable(qualifier) else qualifier
            add(name, m[2], header, dim, q)

    if "合并利润表" in compact:
        block = re.split(r"(?m)^\s*合并利润表\s*$", text, maxsplit=1)[-1]
        block = re.split(r"二、|营业总成本|营业成本", block, maxsplit=1)[0]
        for line in block.splitlines():
            m = re.match(
                r"\s*(?:一、|其中[：:]\s*)?(营业总收入|营业收入|利息收入|手续费及佣金收入)\s+",
                line,
            )
            values = re.findall(r"\d[\d,]*\.\d{2}", line[m.end() :]) if m else []
            if m and values:
                add(m[1], values[0], "合并利润表/" + m[1])
    if "母公司利润表" in compact:
        block = text.split("母公司利润表", 1)[1]
        m = re.search(r"(?m)^\s*一、营业收入[^\n]*?(\d[\d,]*\.\d{2})", block)
        if m:
            add("营业收入", m[1], "母公司利润表/营业收入")
    customer = re.search(r"前五名客户的营业收入[^\n]*", text)
    if customer:
        block = re.split(
            r"\n\s*(?:\d+、|[（(]\d+[)）]|\d+[)）])", text[customer.end() :], maxsplit=1
        )[0]
        simple(block, "前五名客户/营业收入", "customer")
    interest = re.search(r"\d+、\s*利息净收入", text)
    if interest:
        block = re.split(r"(?m)^\s*利息支出", text[interest.end() :], maxsplit=1)[0]
        simple(block, "利息净收入/利息收入")
    if "基本情况" in compact and "子公司名称" in compact:
        for m in re.finditer(
            r"子公司名称\s+([^\n]+)([\s\S]+?)(?=子公司名称|贷款五级分类|$)", text
        ):
            name = re.sub(r"\s+", "", m[1])
            table = re.search(
                r"注册资本[^\n]*营业收入[^\n]*\n\s*((?:-?\d[\d,]*\.\d+\s*){6})", m[2]
            )
            if table:
                add(
                    name,
                    table[1].split()[3],
                    "汽车金融业务/基本情况/营业收入",
                    "business_segment",
                    "原子公司：" + name,
                )
    if "在某一时点确认" in compact and "主营业务收入" in compact:
        lines = text.splitlines()
        idx = next(
            (i for i, l in enumerate(lines) if "整车业务" in l and "合计" in l), None
        )
        if idx is not None:
            names = re.findall(r"\S+", lines[idx])
            total = next(
                (l for l in lines[idx + 1 :] if l.strip().startswith("合计")), ""
            )
            full = list(re.finditer(r"\d[\d,]*\.\d{2}", total))
            if len(names) == len(full):
                edges = [m.end() for m in full]
                for line in lines[idx + 1 :]:
                    label = re.sub(
                        r"\s+", "", re.split(r"\d", line, maxsplit=1)[0]
                    ).removeprefix("其中：")
                    if label not in {
                        "在某一时点确认",
                        "在某一时段内确认",
                        "其他业务收入",
                        "合计",
                    }:
                        continue
                    for m in re.finditer(r"\d[\d,]*\.\d{2}", line):
                        col = min(
                            range(len(edges)), key=lambda j: abs(edges[j] - m.end())
                        )
                        basis = (
                            "主营业务收入/" + label
                            if label.startswith("在某")
                            else label
                        )
                        add(
                            label,
                            m.group(),
                            "收入确认时间/" + basis,
                            "revenue_timing",
                            "原收入列：" + names[col],
                        )
    if "对外交易收入总额" in compact:
        simple(text.split("对外交易收入总额", 1)[1], "地区对外交易收入", "region")
    for cue, name, header, actor in (
        ("向关联方收取之贷款利息收入如下", "贷款利息收入", "关联方贷款利息收入", None),
        ("向关联方收取之利息收入如下", "利息收入", "关联方委托贷款利息收入", None),
        (
            "从关联方取得之手续费收入如下",
            "手续费收入",
            "关联方委托业务手续费收入",
            "财务公司",
        ),
    ):
        if cue in compact:
            original = re.search(r"\s*".join(map(re.escape, cue)), text)
            block = re.split(
                r"\n\s*\((?:i|v)|\n\s*[（(]\d+[)）]|利率均按|关联方存款于|\n\s*于\s*20",
                text[original.end() :],
                maxsplit=1,
            )[0]
            for line in block.splitlines():
                m = re.match(
                    r"\s*(合营企业|联营企业|上汽总公司(?:之子公司)?|合计)\s+(\d[\d,]*\.\d{2})(?=\s|$)",
                    line,
                )
                if m:
                    actor_match = re.search(
                        r"(财务公司(?:及[\u4e00-\u9fff]+)?|本集团)" + re.escape(cue),
                        compact,
                    )
                    source_actor = actor_match[1].strip() if actor_match else actor
                    q = (
                        (
                            "原子公司：" + source_actor + "；"
                            if source_actor and source_actor != "本集团"
                            else ""
                        )
                        + "交易对方："
                        + m[1]
                    )
                    add(name, m[2], header, qualifier=q)
    if "作为出租人的融资租赁" in compact:
        block = re.split(
            r"作为出租人的经营租赁|未折现的租赁收款额",
            text.split("作为出租人的融资租赁", 1)[1],
            maxsplit=1,
        )[0]
        for line in block.splitlines():
            m = re.match(r"\s*(销售收入)\s+(\d[\d,]*\.\d{2})", line)
            if m:
                add(m[1], m[2], "作为出租人的融资租赁/销售收入", "service")
    return rows


def _classified_note_income_rows(text):
    """Preserve vertical contract groups and numbered main/other tables."""
    if not (
        re.search(r"[（(]1[)）]\s*电力业务", text)
        and "合同分类" in text
        or re.search(r"1[)）]\s*主营业务", text)
    ):
        return None
    rows = []
    basis = "营业收入"
    group = None
    dim = "business_type"
    active = False
    for line in text.splitlines():
        compact = re.sub(r"\s+", "", line)
        section = re.match(r"[（(]\d+[)）](.+业务|其他产业)$", compact)
        simple_section = re.match(r"[12][)）](主营业务|其他业务)$", compact)
        if section and "合同分类" in text:
            group = section[1]
            basis = "合同收入/" + group
            dim = "product"
            active = True
            continue
        if simple_section:
            basis = simple_section[1] + "收入"
            dim = "product"
            group = None
            active = True
            continue
        if re.search(r"前五名|履约义务|分解信息|其他说明", compact):
            active = False
        if compact in {"收入成本收入成本", "营业收入营业成本营业收入营业成本"}:
            active = True
        m = re.match(
            r"\s*(主营业务|其他业务|合计|小计|[\u4e00-\u9fff、 ]+?)\s+(-?\d[\d,]*\.\d{2})",
            line,
        )
        if not m or not active:
            continue
        name = re.sub(r"\s+", "", m[1])
        value = m[2]
        if name in {"主营业务", "其他业务"} and group is None and basis == "营业收入":
            rowbasis = "营业收入"
        elif group:
            if name == "合计":
                group = None
                rowbasis = "合同收入/主营业务"
            else:
                rowbasis = basis
        else:
            rowbasis = basis
        rows.append(
            (
                "business_type" if rowbasis == "营业收入" else dim,
                name,
                value,
                rowbasis,
                None,
                "原收入列：" + group if group else None,
            )
        )
    return rows


def _native_wrapped_amount_rows(text: str) -> list[tuple[str, list[str]]]:
    """Retain a row's left label, including a continuation below its amounts."""
    rows = []
    name = ""
    values = []
    for line in text.replace("\r", "").splitlines():
        if re.search(r"报告期内取得和处置子公司的情况|其他说明|公司控制的结构化", line):
            break
        if re.search(
            r"年度报告|^\s*\d+(?:\s*/\s*\d+)?\s*$|^\s*注\s*\d|月）|东的期末净资产|的净利润",
            line,
        ):
            continue
        amounts = list(re.finditer(r"-?\d[\d,]*\.\d{2}", line))
        if amounts:
            label = re.sub(r"\s+", "", line[: amounts[0].start()])
            if re.fullmatch(r"合计[—–-]+", label):
                label = "合计"
            if values:
                rows.append((name, values))
                name = ""
                values = []
            name += label
            values = [m.group() for m in amounts]
        elif (
            re.fullmatch(r"[\u4e00-\u9fffA-Za-z（）()《》/、，&.,：:\s]+", line)
            and line.strip()
        ):
            fragment = re.sub(r"\s+", "", line)
            if not re.search(
                r"项目|发生额|营业收入|营业成本|单位|毛利|本期|上期|本年|上年|关联方|股东|人民币|交易方|受中核|联营企业|最终控制人|产业板块|公司名称|比重|金额|品牌类型|门店类型|销售渠道",
                fragment,
            ):
                name += fragment
    if values:
        rows.append((name, values))
    return [(n, vs) for n, vs in rows if n]


def _current_native_extra_income_spans(
    pages: Sequence[ReportPageText],
) -> list[CoreEvidenceSpan]:
    """Additional observed table formats; preserve original text and stop headings."""
    result = []
    declaration = None

    def keep(page, title, text, continuations=()):
        if declaration and not _unit_from_excerpt(text):
            text = declaration[1] + "\n" + text
            continuations = (*continuations, declaration[0])
        if not _unit_from_excerpt(text):
            return
        result.append(
            CoreEvidenceSpan(
                page=page,
                section_title=title,
                excerpt=text,
                bounded_quote=text,
                continuation_pages=tuple(dict.fromkeys(continuations)),
                chapter_task=ChapterTask.EXTRACT_SEGMENT_FINANCIALS.value,
                field_ids=("segment_dimension", "operating_revenue"),
                context_complete=True,
            )
        )

    for p in pages:
        if not p.readable:
            continue
        raw = p.layout_text or p.text
        m = re.search(
            r"货币单位为人民币(?:百万元|千元|万元|元)", re.sub(r"\s+", "", p.text)
        )
        if m:
            declaration = (p.page, _original_span_matching(p.text, m.group()))
        if "产业板块" in raw and "主营业务收" in raw and "主营业务成" in raw:
            keep(
                p.page,
                "产业板块主营业务收入",
                re.split(
                    r"主营业务分行业、分产品、分地区、分销售模式情况的说明",
                    raw,
                    maxsplit=1,
                )[0],
            )
        if re.search(r"地区[^\n]*20\d{2}年主营业务收入", raw):
            keep(
                p.page,
                "主营业务地区原行",
                raw.split("主营业务分行业、分产品、分地区、分销售模式情况的说明", 1)[
                    -1
                ],
            )
        if (
            "主营业务收入" in raw
            and "公司名称" in raw
            and "归属于母公司" in raw
            and "毛利率" in raw
        ):
            text = raw[raw.rfind("单位", 0, raw.index("公司名称")) :]
            cont = []
            nxt = next((v for v in pages if v.page == p.page + 1 and v.readable), None)
            if nxt and not re.search(
                r"公司名称|归属于母公司", nxt.layout_text or nxt.text
            ):
                tail = re.split(
                    r"[（(]九[)）]|公司控制的结构化主体",
                    nxt.layout_text or nxt.text,
                    maxsplit=1,
                )[0]
                text += "\n" + tail
                cont.append(nxt.page)
            keep(p.page, "具名公司主营业务收入", text, cont)
        if "销售商品/提供劳务" in raw:
            text = raw.split("销售商品/提供劳务", 1)[1]
            cont = []
            cursor = p.page + 1
            while "关联受托管理" not in text:
                nxt = next((v for v in pages if v.page == cursor and v.readable), None)
                if not nxt or cursor > p.page + 12:
                    break
                text += "\n" + (nxt.layout_text or nxt.text)
                cont.append(cursor)
                cursor += 1
            keep(
                p.page,
                "关联销售原表",
                re.split(r"[（(]2[)）]\s*关联受托管理", text, maxsplit=1)[0],
                cont,
            )
        if "1) 出租情况" in raw:
            text = raw.split("1) 出租情况", 1)[1]
            cont = []
            cursor = p.page + 1
            while not re.search(r"2\)\s*承租情况", text):
                nxt = next((v for v in pages if v.page == cursor and v.readable), None)
                if not nxt or cursor > p.page + 3:
                    break
                text += "\n" + (nxt.layout_text or nxt.text)
                cont.append(cursor)
                cursor += 1
            keep(
                p.page,
                "出租情况原表",
                re.split(r"2\)\s*承租情况", text, maxsplit=1)[0],
                cont,
            )
        if "受托管理" in raw and "本年确认的托管" in raw:
            table = re.split(r"\(2\)关联受托管理", raw, maxsplit=1)[-1]
            keep(p.page, "原关联受托收入", table.split("[注]1", 1)[0])
        if "终止经营" in raw and "本年数" in raw and "营业收入" in raw:
            table = raw.split("1. 终止经营", 1)[-1]
            cont = []
            nxt = next((v for v in pages if v.page == p.page + 1 and v.readable), None)
            if nxt and "本年数" in (nxt.layout_text or nxt.text):
                table += "\n" + (nxt.layout_text or nxt.text)
                cont.append(nxt.page)
            keep(p.page, "原终止经营收入", table, cont)
        if ("客户名称" in raw or "前五名客户" in raw) and "销售额" in raw:
            unit = next(
                (
                    l
                    for prior in pages
                    if prior.page == p.page - 1
                    for l in (prior.layout_text or prior.text).splitlines()
                    if _unit_from_excerpt(l)
                ),
                "",
            )
            keep(
                p.page,
                "原前五客户销售额",
                unit + "\n" + raw.split("前五名供应商", 1)[0],
            )
        for title, cue in [
            ("各品牌盈利", "各品牌的盈利情况"),
            ("直营店和加盟店盈利", "直营店和加盟店的盈利情况"),
            ("线上线下销售渠道盈利", "线上、线下销售渠道的盈利情况"),
            ("各地区盈利", "各地区的盈利情况"),
        ]:
            if cue in raw:
                text = raw.split(cue, 1)[1]
                text = re.split(r"\n\s*\d+、", text, maxsplit=1)[0]
                keep(p.page, title, text)
    return result


def _native_income_spans(pages: Sequence[ReportPageText]) -> list[CoreEvidenceSpan]:
    """Bound native financial/income tables and their own unit declaration."""
    spans = []
    financial_unit = None
    financial_declaration = ""
    declaration_page = None
    income_unit_declaration = ""
    income_unit_page = None
    parent_statements = False
    parent_declaration = ""
    parent_page = None
    for page in pages:
        if not page.readable:
            continue
        compact = re.sub(r"\s+", "", page.text)
        convention = re.search(
            r"(?:除特[别殊]注明外[^。\n]{0,50}?金额单位[^。\n]{0,30}?|货币单位为人民币)(百万元|千元|万元|元)",
            compact,
        )
        if convention:
            financial_unit = convention[1]
            financial_declaration = _original_span_matching(
                page.text, convention.group()
            )
            declaration_page = page.page
        if re.search(r"母公司财务报表(?:主要项目)?注释", compact):
            parent_statements = True
            parent_declaration = next(
                l for l in page.text.splitlines() if "母公司财务报表" in l
            )
            parent_page = page.page
        text = page.text
        if "营业收入和营业成本" in text and _unit_from_excerpt(text):
            income_unit_declaration = next(
                (l for l in text.splitlines() if _unit_from_excerpt(l)), ""
            )
            income_unit_page = page.page
        if page.layout_text and (
            "房地产销售收入分项列示如下" in text
            or "营业收入和营业成本" in text
            or "营业收入、营业成本的分解" in text
            or "主要控股参股公司分析" in text
            or "非全资子公司" in text
            or "合同分类" in text
            or "重要合营企业的主要财务信息" in text
            or "重要联营企业的主要财务信息" in text
            or "报告分部的财务信息" in text
        ):
            text = page.layout_text
        markers = (
            ("年度主要业务数据", "年度主要业务数据"),
            ("年度主要业务数据", "本期生产制造经营成果如下"),
            ("年度主要业务数据", "公司市场化物流服务经营成果独立核算"),
            ("分部地理主营收入", "按地理信息划分的对外主营业务收入的分布"),
            ("商标使用费收入", "本期收取"),
            ("营业收入和营业成本情况", "营业收入和营业成本情况"),
            ("营业收入和营业成本情况", "营业收入、营业成本"),
            ("按销售模式", "销售收入"),
            ("新能源汽车收入及补贴", "新能源汽车收入及补贴"),
            ("报告分部的财务信息", "报告分部的财务信息"),
            ("收入附注原生栏目", "营业收入和营业成本"),
            ("收入附注原生栏目", "主营业务收入和主营业务成本"),
            ("收入附注原生栏目", "营业收入、营业成本的分解"),
            ("主营业务分业务", "主营业务分业务情况如下"),
            ("境外子公司收入", "境外资产占比较高的相关说明"),
            ("收入附注原生栏目", "具体对外交易收入的信息见下表"),
            ("收入附注原生栏目", "各个报告分部的信息"),
            ("项目销售收入", "房地产销售收入分项列示如下"),
            ("贸易业务收入", "报告期内公司存在贸易业务收入"),
            ("收入附注原生栏目", "营业收入明细："),
            ("收入附注原生栏目", "营业收入明细如下："),
            ("收入附注原生栏目", "营业收入、营业成本的明细："),
            ("收入附注原生栏目", "主营业务分地区列示如下"),
            ("细分行业收入", "按细分行业划分的公司主营业务基本情况"),
            ("治疗领域收入", "按治疗领域或主要药（产）品等分类划分的经营数据情况"),
            ("渠道收入", "按销售渠道划分的公司主营业务基本情况"),
            ("其他收入扣除明细", "营业收入扣除情况表"),
            ("主体营业收入", "主要控股参股公司分析"),
            ("联营企业收入", "重要联营企业的主要财务信息"),
            ("合营企业收入", "重要合营企业的主要财务信息"),
            ("合营企业收入", "重要的合营企业的主要财务信息"),
            ("非全资子公司收入", "重要非全资子公司的主要财务信息"),
            ("在建项目收入", "在建重大项目情况"),
            ("受托管理收入", "本公司受托管理/承包情况表"),
        )
        for title, cue in markers:
            cue_match = re.search(r"\s*".join(map(re.escape, cue)), text)
            if cue not in text and cue_match is None:
                continue
            if title == "商标使用费收入" and not re.search(
                r"本期收取[^。]+商标使用费", compact
            ):
                continue
            if title == "年度主要业务数据":
                text = page.text
            if title == "按销售模式" and "按销售模式" not in text:
                continue
            start = (
                text.find(cue)
                if title
                in {
                    "细分行业收入",
                    "治疗领域收入",
                    "渠道收入",
                    "其他收入扣除明细",
                    "主体营业收入",
                    "联营企业收入",
                }
                or cue
                in {
                    "营业收入明细：",
                    "营业收入明细如下：",
                    "营业收入、营业成本的明细：",
                }
                else text.find(title)
            )
            if start < 0:
                start = text.find(cue) if cue in text else cue_match.start()
            if title == "商标使用费收入":
                start = max(text.rfind("。", 0, start), text.rfind("③", 0, start)) + 1
            parent_start = (
                text.find("母公司财务报表") if parent_page == page.page else -1
            )
            table_parent = parent_statements and (
                parent_start < 0 or start >= parent_start
            )
            table = text[start:parent_start] if parent_start > start else text[start:]
            continuations = []
            if title in {"联营企业收入", "合营企业收入"}:
                # Applicability belongs to this heading, never the next entity
                # relationship's section on the same page.
                table = table.split(cue, 1)[-1]
                if re.match(r"\s*□适用\s*√不适用", table):
                    continue
                table = cue + table
            if title in {
                "主体营业收入",
                "联营企业收入",
                "合营企业收入",
                "非全资子公司收入",
            } or cue in {
                "营业收入明细：",
                "营业收入明细如下：",
                "营业收入、营业成本的明细：",
            }:
                stop = r"\n\s*\d+[.．]\s*在合营企业|报告期内取得和处置子公司的情况|[（(]4[)）]\.?\s*(?:不重要的合营|使用企业集团)|营业成本分解信息|营业收入、营业成本的分解信息|\n\s*\d+、\s*(?:不重要|重要合营|重要联营|在合营)"
                if title in {"联营企业收入", "合营企业收入"}:
                    stop += (
                        r"|\n\s*[（(]\d+[)）]\.?\s*|重要(?:合营|联营)企业的主要财务信息"
                    )
                    # Exclude the current heading from the boundary search.
                    table = table.split(cue, 1)[-1]
                cursor = page.page + 1
                while not re.search(stop, table):
                    nxt = next(
                        (p for p in pages if p.page == cursor and p.readable), None
                    )
                    if not nxt:
                        break
                    continuation_text = (
                        nxt.text
                        if title == "非全资子公司收入"
                        and re.search(r"\.\s*\n\s*\d", nxt.text)
                        else nxt.layout_text or nxt.text
                    )
                    table += "\n" + continuation_text
                    continuations.append(cursor)
                    cursor += 1
                if cue in {"营业收入明细：", "营业收入明细如下："}:
                    # Also retain its immediately following timing table, up to costs.
                    table = re.split(r"营业成本分解信息", table, maxsplit=1)[0]
                else:
                    table = re.split(stop, table, maxsplit=1)[0]
                if title in {"联营企业收入", "合营企业收入"}:
                    table = cue + table
            if title == "报告分部的财务信息" and (
                "主营业务（分" in table
                or "资产总额" in table
                or not re.search(r"\d[\d,]*\.\d{2}", table)
            ):
                stop = r"\n\s*[（(][3-9][)）]\."
                cursor = page.page + 1
                while not re.search(stop, table):
                    nxt = next(
                        (p for p in pages if p.page == cursor and p.readable), None
                    )
                    if not nxt:
                        break
                    table += "\n" + (nxt.layout_text or nxt.text)
                    continuations.append(cursor)
                    cursor += 1
                table = re.split(stop, table, maxsplit=1)[0]
            if title == "报告分部的财务信息":
                table = re.split(r"母公司财务报表|十九、", table, maxsplit=1)[0]
            if title == "年度主要业务数据":
                table = re.split(
                    r"\n\s*(?:金属矿产方面|综合物流方面|造船板块)", table, maxsplit=1
                )[0]
            if title == "分部地理主营收入":
                table = re.split(r"非流动资产总额的分布", table, maxsplit=1)[0]
            if title == "治疗领域收入":
                table = re.split(r"\n\s*情况说明", table, maxsplit=1)[0]
                table = re.sub(r"详见\s*情\s*况\s*说明", "", table)
            if title == "联营企业收入":
                prior = next(
                    (
                        p
                        for p in pages
                        if p.page == page.page - 1
                        and "重要的合营企业或联营企业" in p.text
                    ),
                    None,
                )
                if prior:
                    table += "\n原联营主体：\n" + prior.text
                    continuations.append(prior.page)
            if title in {"细分行业收入", "渠道收入"}:
                table = re.split(r"\n\s*\([2-9]\)|会计政策说明", table, maxsplit=1)[0]
            if title in {"营业收入和营业成本情况", "收入附注原生栏目"}:
                nxt = next(
                    (p for p in pages if p.page == page.page + 1 and p.readable), None
                )
                if (
                    nxt
                    and (
                        not re.search(
                            r"主营业务\s+\d|主营业务收入\(?[a-z]?\)?\s+\d", table
                        )
                        or not re.search(r"其他业务\s+\d|合计\s+\d", table)
                    )
                    and (
                        "本期发生额" not in table
                        or not re.search(r"其他业务\s+\d|合计\s+\d", table)
                        or re.search(r"主营业务\s*$", table)
                        or not re.search(r"(?:主营|其他)业务\s+\d", table)
                    )
                    and "分部" not in table
                ):
                    table += "\n" + (nxt.layout_text or nxt.text)
                    continuations.append(nxt.page)
            if (
                title == "营业收入和营业成本情况"
                and nxt
                and not re.search(r"(?m)^\s*合计\s+\d", table)
            ):
                following = re.sub(
                    r"(?m)^.*年度报告[^\n]*$|^\s*\d+\s*/\s*\d+\s*$",
                    "",
                    nxt.layout_text or nxt.text,
                )
                if re.match(r"\s*合计\s+\d", following):
                    table += "\n" + re.split(r"[（(]2[)）]", following, maxsplit=1)[0]
                    continuations.append(nxt.page)
            if title == "收入附注原生栏目":
                if (
                    "合同分类" in table or re.search(r"项目\s{2,}分部\s{2,}合计", table)
                ) and (
                    not re.search(
                        r"\d[\d,]*\.\d{2}",
                        re.split(r"合同分类|项目(?=\s{2,}分部)", table, maxsplit=1)[1],
                    )
                    or not re.search(
                        r"其他说明|履约义务",
                        re.split(r"合同分类|项目(?=\s{2,}分部)", table, maxsplit=1)[1],
                    )
                ):
                    cursor = page.page + 1
                    while cursor <= page.page + _MAX_SECTION_PAGES:
                        nxt = next(
                            (p for p in pages if p.page == cursor and p.readable), None
                        )
                        if not nxt:
                            break
                        table += "\n" + (nxt.layout_text or nxt.text)
                        continuations.append(nxt.page)
                        if "其他说明" in nxt.text or "履约义务" in nxt.text:
                            break
                        cursor += 1
                nxt = next(
                    (p for p in pages if p.page == page.page + 1 and p.readable), None
                )
                if nxt and re.search(r"固定资产试\s*运行销售", nxt.text):
                    table += "\n" + re.split(r"\n\s*\d+、", nxt.text, maxsplit=1)[0]
                    continuations.append(nxt.page)
            table = (
                _join_native_income_cells(table)
                if title
                not in {"在建项目收入", "主体营业收入", "联营企业收入", "合营企业收入"}
                and "合同分类" not in table
                else table
            )
            # Bound by the next financial note or explicit next table heading.
            if title == "营业收入和营业成本情况":
                table = re.split(
                    r"(?:\n\s*\d+[、.]\s*(?!\d)|[（(]2[)）]|\n\s*[（(][一二三四五六七八九十]+[)）])",
                    table,
                    maxsplit=1,
                )[0]
            elif title in {"按销售模式", "新能源汽车收入及补贴"}:
                table = re.split(r"\n\s*\d+[、.]", table, maxsplit=1)[0]
            elif title == "项目销售收入":
                table = re.split(r"\([34]\)|[（(][34][)）]", table, maxsplit=1)[0]
            elif title == "境外子公司收入":
                table = re.split(r"\n\s*3[、.]", table, maxsplit=1)[0]
            elif title == "主营业务分业务":
                table = re.split(r"\n\s*1[、.]", table, maxsplit=1)[0]
            elif title == "收入附注原生栏目":
                table = re.split(
                    r"\n\s*(?:七\s*关联方|[（(]e[)）]|[（(][一二三四五六七八九十]+[)）]\s*(?!营业收入)[^\n]+|\d+[、.]\s*(?!\d)[^\n]+)",
                    table,
                    maxsplit=1,
                )[0]
            if title == "收入附注原生栏目" and (
                "合同分类" in table or re.search(r"项目\s{2,}分部\s{2,}合计", table)
            ):
                context = page.text
                previous = next((p for p in pages if p.page == page.page - 1), None)
                if previous:
                    context = previous.text + "\n" + context
                main_row = re.search(
                    r"(?m)^\s*主营业务\s+\d[\d,]*\.\d{2}[^\n]*", context
                )
                if main_row and main_row.group() not in table and not page.layout_text:
                    table = main_row.group() + "\n" + table
                    if previous and main_row.group() in previous.text:
                        continuations.append(previous.page)
            if title == "收入附注原生栏目" and not re.search(
                r"主营业务\s+\d|其他业务\s+\d", table
            ):
                nxt = next(
                    (p for p in pages if p.page == page.page + 1 and p.readable), None
                )
                if nxt and re.search(r"主营业务\s+\d|其他业务\s+\d", nxt.text):
                    table += "\n" + (nxt.layout_text or nxt.text)
                    continuations.append(nxt.page)
            if (
                title == "报告分部的财务信息"
                and not _unit_from_excerpt(table)
                and income_unit_declaration
            ):
                table = income_unit_declaration + "\n" + table
                continuations.append(income_unit_page)
            unit = (
                "万元"
                if title == "商标使用费收入"
                and re.search(r"商标使用费\s*\d[\d,]*\.\d+\s*万元", table)
                else _unit_from_excerpt(table)
            ) or (
                financial_unit
                if "财务报表附注" in page.text
                or title
                in {
                    "营业收入和营业成本情况",
                    "收入附注原生栏目",
                    "联营企业收入",
                    "合营企业收入",
                    "非全资子公司收入",
                }
                else None
            )
            if not unit:
                continue
            # Carry only the applicable explicit convention, never a prior table's unit.
            if _unit_from_excerpt(table) is None and title != "商标使用费收入":
                if not financial_declaration:
                    continue
                table = financial_declaration + "\n" + table
            if table_parent:
                table = parent_declaration + "\n" + table
                continuations.append(parent_page)
            spans.append(
                CoreEvidenceSpan(
                    page=page.page,
                    section_title=title,
                    excerpt=table,
                    bounded_quote=table,
                    continuation_pages=tuple(
                        dict.fromkeys(
                            [
                                *continuations,
                                *(
                                    [declaration_page]
                                    if declaration_page
                                    and financial_declaration in table
                                    else []
                                ),
                            ]
                        )
                    ),
                    chapter_task=ChapterTask.EXTRACT_SEGMENT_FINANCIALS.value,
                    field_ids=("segment_dimension", "operating_revenue"),
                    context_complete=True,
                )
            )
    return spans


def _supplemental_income_spans(
    pages: Sequence[ReportPageText],
) -> list[CoreEvidenceSpan]:
    """Keep the revenue column of operating, provided-service and lessor tables.

    A service row is selected only under the seller's own table, and a rental
    row only under the explicitly declared lessor. Purchases and lessee tables
    cannot inherit that direction or its unit.
    """
    spans = []
    convention = None
    for page in pages:
        text = page.text.replace("\r", "")
        text = re.sub(r"减：行业\s*间交易抵\s*消\s*(?=\d)", "减：行业间交易抵消 ", text)
        if not page.readable:
            continue
        declaration = re.search(
            r"(?:除特[别殊]注明外[^。\n]{0,50}?金额单位[^。\n]{0,30}?|货币单位为人民币)(百万元|千元|万元|元)",
            re.sub(r"\s+", "", text),
        )
        if declaration:
            convention = (page.page, _original_span_matching(text, declaration.group()))
        for cue, title in (
            ("收入确认时间", "收入确认交叉单元"),
            ("重大关联交易", "关联服务交易收入"),
        ):
            unit_basis = convention
            if cue == "收入确认时间":
                prior = next(
                    (
                        p
                        for p in pages
                        if p.page == page.page - 1 and "营业收入和营业成本" in p.text
                    ),
                    None,
                )
                if prior:
                    declaration_line = next(
                        (
                            line
                            for line in reversed(prior.text.splitlines())
                            if _unit_from_excerpt(line)
                        ),
                        None,
                    )
                    if declaration_line:
                        unit_basis = (prior.page, declaration_line)
            if cue in text and unit_basis:
                table = page.layout_text or text
                table = (
                    unit_basis[1]
                    + "\n"
                    + table[table.rfind("\n", 0, table.find(cue)) + 1 :]
                )
                spans.append(
                    CoreEvidenceSpan(
                        page=page.page,
                        section_title=title,
                        excerpt=table,
                        bounded_quote=table,
                        continuation_pages=(unit_basis[0],),
                        chapter_task=ChapterTask.EXTRACT_SEGMENT_FINANCIALS.value,
                        field_ids=("segment_dimension", "operating_revenue"),
                        context_complete=True,
                    )
                )
        if "临时公告未披露的事项" in text and "提供劳务" in text:
            table = text.split("临时公告未披露的事项", 1)[1]
            continuation = ()
            nxt = next((p for p in pages if p.page == page.page + 1), None)
            if nxt and "合计" not in table:
                table += "\n" + nxt.text
                continuation = (nxt.page,)
            table = re.split(r"大额销货退回|\(二\)|（二）", table, maxsplit=1)[0]
            if _unit_from_excerpt(table):
                spans.append(
                    CoreEvidenceSpan(
                        page=page.page,
                        section_title="临时关联服务收入",
                        excerpt=table,
                        bounded_quote=table,
                        continuation_pages=continuation,
                        chapter_task=ChapterTask.EXTRACT_SEGMENT_FINANCIALS.value,
                        field_ids=("segment_dimension", "operating_revenue"),
                        context_complete=True,
                    )
                )
        for cue, stop in (
            ("产品情况", r"产品档次划分标准|\d+、原料采购情况"),
            ("销售渠道", r"[（(]3[)）]\.区域情况"),
            ("区域名称", r"区域划分标准|[（(]4[)）]"),
            ("线上销售情况", r"未来线上经营战略|\d+、公司收入及成本分析"),
            ("按不同类型披露公司主营业务构成", r"情况说明"),
        ):
            if cue not in text:
                continue
            if cue == "产品情况" and not re.search(
                r"(?m)^\s*\d+、\s*产品情况\s*$", text
            ):
                continue
            if cue == "销售渠道" and not re.search(r"[（(]\d+[)）]\.\s*销售渠道", text):
                continue
            table = text[text.find(cue) :]
            table = re.split(stop, table, maxsplit=1)[0]
            compact_table = re.sub(r"\s+", "", table)
            if not re.search(r"销售收入|营业收入", compact_table):
                continue
            if not _unit_from_excerpt(table) and _unit_from_excerpt(text):
                table = (
                    next(line for line in text.splitlines() if _unit_from_excerpt(line))
                    + "\n"
                    + table
                )
            if _unit_from_excerpt(table):
                spans.append(
                    CoreEvidenceSpan(
                        page=page.page,
                        section_title="行业产品销售收入",
                        excerpt=table,
                        bounded_quote=table,
                        chapter_task=ChapterTask.EXTRACT_SEGMENT_FINANCIALS.value,
                        field_ids=("segment_dimension", "operating_revenue"),
                        context_complete=True,
                    )
                )
        if re.search(
            r"(?:收入(?:达到)?人民币|业务[^。]+收入达到人民币)\s*\d+\s*亿元", text
        ):
            # Profit attribution elsewhere on this page is not the subject of
            # the operating-income sentence. Keep the native sentence intact,
            # including any actual parent/subsidiary limitation in that sentence.
            for sentence in re.split(r"(?<=[。；;])", text):
                if not re.search(
                    r"收入(?:\s*\d+)?(?:达到)?\s*人民币\s*\d[\d,.]*\s*亿元",
                    sentence,
                ):
                    continue
                spans.append(
                    CoreEvidenceSpan(
                        page=page.page,
                        section_title="经营正文收入",
                        excerpt=sentence.strip(),
                        bounded_quote=sentence.strip(),
                        chapter_task=ChapterTask.EXTRACT_SEGMENT_FINANCIALS.value,
                        field_ids=("segment_dimension", "operating_revenue"),
                        context_complete=True,
                    )
                )
        if re.search(
            r"(?:业务营业收入|项目结转营业收入|市政业务实现营业收入)\s*\d[\d,.]*\s*万元",
            text,
        ):
            spans.append(
                CoreEvidenceSpan(
                    page=page.page,
                    section_title="经营正文收入",
                    excerpt=text,
                    bounded_quote=text,
                    chapter_task=ChapterTask.EXTRACT_SEGMENT_FINANCIALS.value,
                    field_ids=("segment_dimension", "operating_revenue"),
                    context_complete=True,
                )
            )
        if re.search(r"主营业务分行业、分产品、分地区、分销售模式情况(?!的说明)", text):
            table = text.split("主营业务分行业、分产品、分地区、分销售模式情况", 1)[1]
            table = re.split(
                r"主营业务分行业、分产品、分地区、分销售模式情况的说明",
                table,
                maxsplit=1,
            )[0]
            if page.layout_text:
                table = page.layout_text.split(
                    "主营业务分行业、分产品、分地区、分销售模式情况", 1
                )[-1]
                unit_line = next(
                    (l for l in page.layout_text.splitlines() if _unit_from_excerpt(l)),
                    "",
                )
                cont = []
                cursor = page.page + 1
                while (
                    "主营业务分行业、分产品、分地区、分销售模式情况的说明" not in table
                ):
                    nxt = next(
                        (p for p in pages if p.page == cursor and p.readable), None
                    )
                    if not nxt or cursor > page.page + 3:
                        break
                    table += "\n" + (nxt.layout_text or nxt.text)
                    cont.append(cursor)
                    cursor += 1
                table = re.split(
                    r"主营业务分行业、分产品、分地区、分销售模式情况的说明",
                    table,
                    maxsplit=1,
                )[0]
                table = unit_line + "\n" + table
            else:
                cont = []
                table = _join_native_income_cells(table)
                table = re.sub(r"\n(?=\d[\d,]*\.\d{2}\s+)", " ", table)
            spans.append(
                CoreEvidenceSpan(
                    page=page.page,
                    section_title="主营业务原表",
                    excerpt=table,
                    bounded_quote=table,
                    continuation_pages=tuple(cont),
                    chapter_task=ChapterTask.EXTRACT_SEGMENT_FINANCIALS.value,
                    field_ids=("segment_dimension", "operating_revenue"),
                    context_complete=True,
                )
            )
        if "报告期内房地产出租情况" in text:
            table = (page.layout_text or text).split("报告期内房地产出租情况", 1)[1]
            continuations = []
            nxt = next(
                (p for p in pages if p.page == page.page + 1 and p.readable), None
            )
            if nxt and not re.search(r"\d[\d,]*\.\d{2}", table):
                table += "\n" + (nxt.layout_text or nxt.text)
                continuations.append(nxt.page)
            table = re.split(r"\n\s*5、", table, maxsplit=1)[0]
            spans.append(
                CoreEvidenceSpan(
                    page=page.page,
                    section_title="房地产结转收入",
                    excerpt=table,
                    bounded_quote=table,
                    continuation_pages=tuple(continuations),
                    chapter_task=ChapterTask.EXTRACT_SEGMENT_FINANCIALS.value,
                    field_ids=("segment_dimension", "operating_revenue"),
                    context_complete=True,
                )
            )
        narrative = re.search(
            r"(?:公司实现[^。；]+经营收入|[\u4e00-\u9fff]{2,30}全年实现[^。；]+总收入|来自第三方项目的[^。；]+收入)\s*\d[\d,.]*\s*(?:亿元|万元)",
            re.sub(r"\s+", "", text),
        )
        if narrative and not re.search(
            r"(?:拟|计划|第三方公司|尚未)[^。]{0,30}收入", re.sub(r"\s+", "", text)
        ):
            spans.append(
                CoreEvidenceSpan(
                    page=page.page,
                    section_title="经营正文收入",
                    excerpt=text,
                    bounded_quote=text,
                    chapter_task=ChapterTask.EXTRACT_SEGMENT_FINANCIALS.value,
                    field_ids=("segment_dimension", "operating_revenue"),
                    context_complete=True,
                )
            )
        if "报告期内房地产销售和结转情况" in text:
            table = (page.layout_text or text).split("报告期内房地产销售和结转情况", 1)[
                1
            ]
            continuations = []
            nxt = next(
                (p for p in pages if p.page == page.page + 1 and p.readable), None
            )
            if nxt and "报告期内房地产出租情况" in nxt.text:
                table += (
                    "\n"
                    + re.split(
                        r"报告期内房地产出租情况",
                        nxt.layout_text or nxt.text,
                        maxsplit=1,
                    )[0]
                )
                continuations.append(nxt.page)
            spans.append(
                CoreEvidenceSpan(
                    page=page.page,
                    section_title="房地产结转收入",
                    excerpt=table,
                    bounded_quote=table,
                    continuation_pages=tuple(continuations),
                    chapter_task=ChapterTask.EXTRACT_SEGMENT_FINANCIALS.value,
                    field_ids=("segment_dimension", "operating_revenue"),
                    context_complete=True,
                )
            )
        other_income = re.search(
            r"房地产子公司销售其持有的投资性房地产[^。]+其对应的收入和成本金额分别为\s*[\d,]+\s*万元[^。]*。",
            re.sub(r"\s+", "", text),
        )
        if other_income:
            spans.append(
                CoreEvidenceSpan(
                    page=page.page,
                    section_title="主营业务收入补充说明",
                    excerpt=_original_span_matching(text, other_income.group()),
                    bounded_quote=_original_span_matching(text, other_income.group()),
                    chapter_task=ChapterTask.EXTRACT_SEGMENT_FINANCIALS.value,
                    field_ids=("segment_dimension", "operating_revenue"),
                    context_complete=True,
                )
            )
        adjustment = re.search(
            r"(?m)^\s*(减：行业间交易抵消|行业间抵消|分部抵消|分部抵销)\s+(-?[\d,]+\.\d{2})[^\n]*",
            text,
        )
        if adjustment:
            unit_line = next(
                (line for line in text.splitlines() if _unit_from_excerpt(line)), None
            )
            if unit_line:
                source = unit_line + "\n主营业务分行业\n" + adjustment.group()
                if "行业间" in adjustment[1]:
                    industry = re.split(
                        r"主营业务分产品|主营业务分地区", text, maxsplit=1
                    )[0]
                    total = re.search(
                        r"(?:主营业务合计|合计)\s+(-?[\d,]+\.\d{2})", industry
                    )
                    if total:
                        source += "\n" + total.group()
                spans.append(
                    CoreEvidenceSpan(
                        page=page.page,
                        section_title="主营业务收入补充说明",
                        excerpt=source,
                        bounded_quote=source,
                        chapter_task=ChapterTask.EXTRACT_SEGMENT_FINANCIALS.value,
                        field_ids=("segment_dimension", "operating_revenue"),
                        context_complete=True,
                    )
                )
        operating = re.search(r"报告期内电量、收入及成本情况[\s\S]+", text)
        if operating and _unit_from_excerpt(operating.group()) == "亿元":
            spans.append(
                CoreEvidenceSpan(
                    page=page.page,
                    section_title="电量收入及成本",
                    excerpt=operating.group(),
                    bounded_quote=operating.group(),
                    chapter_task=ChapterTask.EXTRACT_SEGMENT_FINANCIALS.value,
                    field_ids=("segment_dimension", "operating_revenue"),
                    context_complete=True,
                )
            )
        rental = re.search(
            r"作为出租人的经营租赁[\s\S]+?(?=作为出租人的融资租赁|$)", text
        )
        if (
            rental
            and re.search(r"√适用\s*□不适用", rental.group())
            and (_unit_from_excerpt(rental.group()) or _unit_from_excerpt(text))
        ):
            rental_text = rental.group()
            continuation = ()
            if "作为出租人的融资租赁" not in text[text.find("作为出租人的经营租赁") :]:
                following = next(
                    (p for p in pages if p.page == page.page + 1 and p.readable), None
                )
                if following and re.search(
                    r"租赁收入|合计\s+\d[\d,]*\.\d{2}", following.text
                ):
                    rental_text += (
                        "\n"
                        + re.split(r"作为出租人的融资租赁", following.text, maxsplit=1)[
                            0
                        ]
                    )
                    continuation = (following.page,)
            if not _unit_from_excerpt(rental_text):
                rental_text = (
                    next(line for line in text.splitlines() if _unit_from_excerpt(line))
                    + "\n"
                    + rental_text
                )
            spans.append(
                CoreEvidenceSpan(
                    page=page.page,
                    section_title="经营租赁收入",
                    excerpt=rental_text,
                    bounded_quote=rental_text,
                    continuation_pages=continuation,
                    chapter_task=ChapterTask.EXTRACT_SEGMENT_FINANCIALS.value,
                    field_ids=("segment_dimension", "operating_revenue"),
                    context_complete=True,
                )
            )
        lessor = re.search(
            r"(?<!第三方)(?<!子公司)本公司作为出租方：[\s\S]+", page.layout_text or text
        )
        if lessor:
            table = lessor.group()
            continuations = []
            cursor = page.page + 1
            stop = r"本公司作为承租方[:：]|关联租赁情况说明|[（(]4[)）]|\n\s*3、"
            while not re.search(stop, table):
                nxt = next((p for p in pages if p.page == cursor and p.readable), None)
                if not nxt:
                    break
                table += "\n" + (nxt.layout_text or nxt.text).replace("\r", "")
                continuations.append(cursor)
                cursor += 1
            table = re.split(stop, table, maxsplit=1)[0]
            if not _unit_from_excerpt(table) and convention:
                table = convention[1] + "\n" + table
                continuations.append(convention[0])
            if (
                not re.search(r"□适用\s*√不适用", table)
                and _unit_from_excerpt(table)
                and "本期确认的租赁收入" in re.sub(r"\s+", "", text)
            ):
                spans.append(
                    CoreEvidenceSpan(
                        page=page.page,
                        section_title="关联服务及出租收入",
                        excerpt=table,
                        bounded_quote=table,
                        continuation_pages=tuple(continuations),
                        chapter_task=ChapterTask.EXTRACT_SEGMENT_FINANCIALS.value,
                        field_ids=("segment_dimension", "operating_revenue"),
                        context_complete=True,
                    )
                )
        trustee = re.search(
            r"本公司受托管理/承包情况表：[\s\S]+", page.layout_text or text
        )
        if trustee:
            table = re.split(
                r"关联托管/承包情况说明|本公司委托管理", trustee.group(), maxsplit=1
            )[0]
            following = next((p for p in pages if p.page == page.page + 1), None)
            context = re.split(r"本公司委托管理", trustee.group(), maxsplit=1)[0]
            continuation = ()
            if following and "受托方由" in following.text:
                context += (
                    "\n" + re.split(r"本公司委托管理", following.text, maxsplit=1)[0]
                )
                continuation = (following.page,)
            if re.search(r"√适用\s*□不适用", table) and _unit_from_excerpt(table):
                spans.append(
                    CoreEvidenceSpan(
                        page=page.page,
                        section_title="关联服务及出租收入",
                        excerpt=context,
                        bounded_quote=context,
                        continuation_pages=continuation,
                        chapter_task=ChapterTask.EXTRACT_SEGMENT_FINANCIALS.value,
                        field_ids=("segment_dimension", "operating_revenue"),
                        context_complete=True,
                    )
                )
        # A provided-service table can continue over multiple complete pages.
        seller = re.search(
            r"出售商品/提供劳务(?:情况表\s*[:：]?|[:：])\s*[\s\S]+", text
        )
        if seller:
            table = (page.layout_text or text).split("出售商品/提供劳务", 1)[1]
            table = "出售商品/提供劳务" + table
            continuations = []
            if not _unit_from_excerpt(table) and convention:
                table = convention[1] + "\n" + table
                continuations.append(convention[0])
            cursor = page.page + 1
            while not re.search(
                r"采购资产|购销商品、提供和接受劳务的关联交易说明|关联租赁情况", table
            ):
                nxt = next((p for p in pages if p.page == cursor and p.readable), None)
                if not nxt:
                    break
                table += "\n" + (nxt.layout_text or nxt.text).replace("\r", "")
                continuations.append(cursor)
                cursor += 1
            table = re.split(
                r"采购资产|购销商品、提供和接受劳务的关联交易说明|关联租赁情况",
                table,
                maxsplit=1,
            )[0]
            if (
                (
                    "管理服务费" in table
                    or "租金收入" in table
                    or "租赁收入" in table
                    or re.search(r"关联方\s+关联交易内(?:容)?", table)
                )
                and re.search(r"本期(?:发生额|金额)", table)
                and _unit_from_excerpt(table)
            ):
                spans.append(
                    CoreEvidenceSpan(
                        page=page.page,
                        section_title="关联服务及出租收入",
                        excerpt=table,
                        bounded_quote=table,
                        continuation_pages=tuple(continuations),
                        chapter_task=ChapterTask.EXTRACT_SEGMENT_FINANCIALS.value,
                        field_ids=("segment_dimension", "operating_revenue"),
                        context_complete=True,
                    )
                )
        for cue, title, stop in (
            ("转租使用权资产取得的收入", "转租收入", "作为出租人"),
            ("作为出租人的融资租赁", "融资租赁收入", "未折现租赁收款额"),
            ("租出资产", "关联租出资产收入", "3、"),
        ):
            if cue not in text:
                continue
            table = (
                text
                if title in {"转租收入", "关联租出资产收入"}
                else text[text.index(cue) :]
            )
            table = re.split(stop, table, maxsplit=1)[0]
            unit = _unit_from_excerpt(table) or _unit_from_excerpt(text)
            continuations = ()
            if title == "转租收入" and not _unit_from_excerpt(table):
                preceding = next((p for p in pages if p.page == page.page - 1), None)
                if preceding and "作为承租人" in preceding.text:
                    declaration = next(
                        (
                            l
                            for l in reversed(preceding.text.splitlines())
                            if _unit_from_excerpt(l)
                        ),
                        None,
                    )
                    if declaration:
                        table = declaration + "\n" + table
                        unit = _unit_from_excerpt(declaration)
                        continuations = (preceding.page,)
            if title == "关联租出资产收入" and not unit:
                intro = next(
                    (
                        p
                        for p in reversed(pages)
                        if page.page - 2 <= p.page < page.page
                        and "关联交易金额" in p.text
                        and _unit_from_excerpt(p.text)
                    ),
                    None,
                )
                if intro:
                    declaration = next(
                        l for l in intro.text.splitlines() if _unit_from_excerpt(l)
                    )
                    table = declaration + "\n" + table
                    unit = _unit_from_excerpt(declaration)
                    continuations = (intro.page,)
            if unit:
                spans.append(
                    CoreEvidenceSpan(
                        page=page.page,
                        section_title=title,
                        excerpt=table,
                        bounded_quote=table,
                        continuation_pages=continuations,
                        chapter_task=ChapterTask.EXTRACT_SEGMENT_FINANCIALS.value,
                        field_ids=("segment_dimension", "operating_revenue"),
                        context_complete=True,
                    )
                )
    return spans


def _join_native_income_cells(text: str) -> str:
    """Join printed decimal fragments/vertical row cells, preserving year blanks."""
    text = text.replace("\r", "")
    text = re.sub(r"(?m)^([^\n]*\d[^\n]*)[ \t]+(合计|总计)[ \t]*$", r"\1\n\2", text)
    text = re.sub(r"(?m)^.*年度报告[^\n]*$|^\s*\d+\s*/\s*\d+\s*$", "", text)
    text = re.sub(r"(?<=,)\s+(?=\d)", "", text)
    text = re.sub(r"-(?:[ \t]{1,2}|[ \t]*\n[ \t]*)(?=\d)", "-", text)
    text = re.sub(r"(?<=\d)\s+(?=[,.]\d)", "", text)
    text = re.sub(r"(\d[\d,]*\.)(?:\s+)(\d{2})(?=\s|$)", r"\1\2", text)
    text = re.sub(r"(\d[\d,]*\.\d)\s*\n\s*(\d)(?=\s|$)", r"\1\2", text)
    text = re.sub(r"(\d[\d,]*,\d{1,2})\s*\n\s*(\d{1,2}\.\d{2})(?=\s|$)", r"\1\2", text)
    lines = []
    for line in text.splitlines():
        if lines and re.fullmatch(r"\s*(?:\(?-?\d[\d,]*\.\d{2}\)?(?:\s+|$))+", line):
            lines[-1] += " " + line.strip()
        else:
            lines.append(line)
    return "\n".join(lines)


def _multiline_contract_column_rows(text: str) -> list[tuple] | None:
    """Read wrapped native segment and revenue/cost headers by physical column."""
    lines = text.splitlines()
    start = next((i for i, line in enumerate(lines) if "合同分类" in line), None)
    if start is None:
        return None
    first = next(
        (
            i
            for i in range(start + 1, len(lines))
            if re.search(r"\d[\d,]*\.\d{2}", lines[i])
        ),
        None,
    )
    if first is None:
        return None
    columns = []
    for line in lines[start:first]:
        for m in re.finditer(r"营业收入|营业成本|营业收|营业成", line):
            if not any(abs(m.start() - x) < 2 for x, _ in columns):
                columns.append((m.start(), "收入" if "收" in m.group() else "成本"))
        if re.fullmatch(r"[\s收成]+", line):
            for m in re.finditer(r"收|成", line):
                if not any(abs(m.start() - x) < 2 for x, _ in columns):
                    columns.append((m.start(), "收入" if m.group() == "收" else "成本"))
    columns.sort()
    if len(columns) < 4 or len(columns) % 2:
        return None
    if len(columns) == 4:
        # Conventional one-segment tables already have a native reader that
        # preserves completely blank product rows and their continuation totals.
        return None
    stacked_names = any("-分" in line for line in lines[max(0, start - 3) : start])
    groups = [
        (columns[i][0] + columns[i + 1][0]) / 2 for i in range(0, len(columns), 2)
    ]
    names = ["" for _ in groups]
    for line in lines[max(0, start - 3) : start + 1]:
        if "营业收" in line or "单位" in line or "年度报告" in line:
            continue
        for m in re.finditer(r"\S+", line):
            if m.group() == "合同分类" or not re.fullmatch(
                r"[\u4e00-\u9fff、-]+", m.group()
            ):
                continue
            center = (m.start() + m.end()) / 2
            k = min(range(len(groups)), key=lambda k: abs(groups[k] - center))
            names[k] += m.group()
    names = [n.replace("-分部", "") for n in names]
    if not all(names) or names[-1] != "合计":
        return None
    headings = {
        "商品类型": ("product", "商品类型"),
        "业务类型": ("product", "业务类型"),
        "按业务类型分类": ("product", "业务类型"),
        "按经营地区分类": ("region", "按经营地区分类"),
        "按商品转让的时间分类": ("revenue_timing", "按商品转让的时间分类"),
    }
    rows = []
    dim = basis = pending = ""
    body = lines[first:] if stacked_names else lines[start + 1 :]
    for j, line in enumerate(body):
        if re.search(r"其他说明|履约义务", line):
            break
        amounts = list(re.finditer(r"-?\d[\d,]*\.\d{2}", line))
        label = re.sub(r"\s+", "", line[: amounts[0].start()] if amounts else line)
        if not amounts:
            if re.fullmatch(r"[营业收成入本]+", label):
                continue
            if re.fullmatch(r"[\u4e00-\u9fff：:]+", label) and len(label) < 15:
                pending += label
                if pending in headings:
                    dim, basis = headings[pending]
                    pending = ""
            continue
        if label.startswith("按经营地区"):
            pending = ""
        label = label if label in {"合计", "小计", "总计"} else pending + label
        pending = ""
        k = j + 1
        while k < len(body) and not re.search(r"\d[\d,]*\.\d{2}", body[k]):
            fragment = re.sub(r"\s+", "", body[k])
            if (
                not fragment
                or len(fragment) > 8
                or not re.fullmatch(r"[\u4e00-\u9fff：:、-]+", fragment)
            ):
                break
            if (
                fragment in headings
                or re.search(r"其他说明|履约义务|分摊至", fragment)
                or any(h.startswith(fragment) for h in headings)
            ):
                break
            if body[k].startswith("   "):
                break
            label += fragment
            body[k] = ""
            k += 1
        label = label.removeprefix("其中：").rstrip("：:")
        if label in headings:
            dim, basis = headings[label]
        if not dim or not label:
            continue
        used = set()
        for ordinal, m in enumerate(amounts):
            center = (m.start() + m.end()) / 2
            paired = len(amounts) % 2 == 0 and all(
                amounts[k + 1].start() - amounts[k].end() <= 4
                for k in range(0, len(amounts), 2)
            )
            if len(amounts) == len(columns):
                col = ordinal
            elif stacked_names:
                col = min(
                    range(len(columns)), key=lambda k: abs(columns[k][0] - m.start())
                )
            elif paired:
                left, right = amounts[ordinal // 2 * 2 : ordinal // 2 * 2 + 2]
                group_center = (left.start() + right.end()) / 2
                group = min(
                    range(len(groups)), key=lambda k: abs(groups[k] - group_center)
                )
                col = group * 2 + ordinal % 2
            else:
                col = min(
                    range(len(columns)), key=lambda k: abs(columns[k][0] + 2 - center)
                )
            if columns[col][1] != "收入" or col in used:
                continue
            used.add(col)
            rows.append(
                (
                    "business_segment" if label == "合计" else dim,
                    label,
                    m.group(),
                    "合同收入/合同分解合计" if label == "合计" else "合同收入/" + basis,
                    None,
                    "原收入列：" + names[col // 2] + "营业收入",
                )
            )
    return rows


def _native_contract_column_rows(text: str) -> list[tuple] | None:
    """Keep native revenue/cost column positions and each segment's identity.

    Empty cells stay empty. Classification headers reset the previous business
    basis; neither a prior-year table nor a later note supplies these cells.
    """
    multiline = _multiline_contract_column_rows(text)
    if multiline is not None:
        return multiline
    lines = [
        l
        for l in text.splitlines()
        if l.strip() and not re.search(r"年度报告|^\s*\d+(?:\s*/\s*\d+)?\s*$", l)
    ]
    start = next(
        (
            i
            for i, line in enumerate(lines)
            if "合同分类" in line or re.search(r"项目\s{2,}分部\s{2,}合计", line)
        ),
        None,
    )
    if start is None:
        return None
    header = lines[start]
    columns = (
        list(re.finditer(r"营业收入|营业成本", lines[start + 1]))
        if start + 1 < len(lines)
        else []
    )
    names = re.split(r"\s+", re.sub(r"分部\s+(\d+)", r"分部\1", header).strip())[1:]
    if len(columns) != 2 * len(names) or len(names) < 2 or names[-1] != "合计":
        return None
    centers = [(m.start() + m.end()) / 2 for m in columns]
    rows = []
    dim, basis = "", ""
    headings = {
        "商品类型": ("product", "商品类型"),
        "业务类型": ("business_segment", "业务类型"),
        "按经营地区分类": ("region", "按经营地区分类"),
        "市场或客户类型": ("region", "市场或客户类型"),
        "合同类型": ("contract_type", "合同类型"),
        "按商品转让的时间分类": ("revenue_timing", "按商品转让的时间分类"),
        "按合同期限分类": ("contract_term", "按合同期限分类"),
        "按销售渠道分类": ("sales_mode", "按销售渠道分类"),
    }
    table_lines = lines[start + 2 :]
    for index, line in enumerate(table_lines):
        if re.search(r"其他说明|履约义务|重大合同|\d+、\s*(?:税金|费用)", line):
            break
        amounts = list(re.finditer(r"-?\d[\d,]*\.\d{2}(?!%)", line))
        label = re.sub(r"\s+", "", line[: amounts[0].start()] if amounts else line)
        if index + 1 < len(table_lines):
            fragment = re.sub(r"\s+", "", table_lines[index + 1])
            if (
                re.fullmatch(r"[\u4e00-\u9fff、：:]+", fragment)
                and fragment not in headings
                and (
                    len(fragment) == 1
                    or fragment.startswith("及")
                    or label.startswith("按商品转让")
                    or label.endswith("以")
                    and fragment.startswith("外")
                    or fragment
                    in {"售收入", "销售收入", "收入", "区分类", "类：", "运营"}
                    or (
                        amounts
                        and fragment in {"机械", "点转让", "段内转让", "转让", "内转让"}
                    )
                )
            ):
                label += fragment
        if amounts and index and label.startswith("外的地区"):
            prior_label = re.sub(r"\s+", "", table_lines[index - 1])
            if prior_label.endswith("以") and not re.search(r"\d", prior_label):
                label = prior_label + label
        label = label.removeprefix("其中：").rstrip("：:")
        if label.startswith("按商品转让的时间分") and label.endswith("类"):
            label = "按商品转让的时间分类"
        if label in headings:
            dim, basis = headings[label]
        elif label in {"合计", "总计"} and dim != "revenue_timing":
            dim = "business_segment"
        elif basis == "业务类型":
            dim = "product"
        if not dim or not amounts or not label or "年度报告" in label:
            continue
        used = set()
        for amount in amounts:
            center = (amount.start() + amount.end()) / 2
            col = (
                amounts.index(amount)
                if len(amounts) == len(centers)
                else min(range(len(centers)), key=lambda i: abs(centers[i] - center))
            )
            # Costs are never silently shifted into an empty revenue column.
            if col % 2 or col in used:
                continue
            used.add(col)
            column_name = names[col // 2]
            rows.append(
                (
                    dim,
                    label,
                    amount.group(),
                    "合同收入/"
                    + (
                        "合同分解合计"
                        if label in {"合计", "总计"} and dim != "revenue_timing"
                        else basis
                    ),
                    None,
                    "原收入列：" + column_name + "营业收入",
                )
            )
    return rows


def _real_estate_settlement_rows(text: str) -> list[tuple]:
    """Read printed project settlement income, including zero and wrapped names."""
    rows = []
    sales = re.search(r"报告期内房地产销售和结转情况", re.sub(r"[ \t]+", "", text))
    if sales:
        native_heading = re.search(
            r"报\s*告\s*期\s*内\s*房\s*地\s*产\s*销\s*售\s*和\s*结\s*转\s*情\s*况", text
        )
        if native_heading:
            text = text[native_heading.start() :]
    if "出租房地产的租" in re.sub(r"\s+", "", text) and "结转收入金额" not in text:
        if "经营业态" in text and not re.search(r"项目\s+经营业态", text):
            for m in re.finditer(
                r"(?m)^\s*\d+\s+(\S+)\s+(\S+)\s+\d[\d,]*\.\d{2}\s+(\d[\d,]*\.\d{2})\s+\d",
                text,
            ):
                rows.append(
                    (
                        "lease",
                        m[2],
                        m[3],
                        "房地产出租/租金收入",
                        None,
                        "原地区：" + m[1],
                    )
                )
            return rows
        rental = re.sub(r"(?m)^.*年度报告[^\n]*$|^\s*\d+\s*/\s*\d+\s*$", "", text)
        for m in re.finditer(
            r"(?m)^\s*\d+\s+[^\s]+\s+(.+?)\s+\S+\s+\d[\d,]*\.\d+\s+(\d[\d,]*\.\d+)\s+\d+%?\s+",
            rental,
        ):
            name = re.sub(r"\s+", "", m[1])
            tail = re.match(
                r"[ \t]*(基地)[ \t]*(?=\n|$)", rental[rental.find("\n", m.end()) + 1 :]
            )
            if tail:
                name += tail[1]
            rows.append(("lease", name, m[2], "房地产出租/租金收入", None))
        return rows
    if "结转收入金额" in text and re.search(r"销售、出租", text):
        for m in re.finditer(
            r"(?m)^\s*\d+\s+[^\s]+\s+(.+?)\s+(?:销售、出租|销售)\s+((?:[\d,.]+\s+){4}[\d,.]+)\s*$",
            text,
        ):
            rows.append(
                (
                    "project",
                    re.sub(r"\s+", "", m[1]),
                    m[2].split()[3],
                    "房地产销售和结转/结转收入金额",
                    None,
                )
            )
    if "结转收入金额" in text and re.search(r"商品房|经适房", text):
        for m in re.finditer(
            r"(?m)^\s*\d+\s+[^\s]+\s+(\S+)\s+(?:商品房|经适房)\s+((?:[\d,]+\.\d{2}|-)(?:\s+(?:[\d,]+\.\d{2}|-)){4})\s*$",
            text,
        ):
            amount = m[2].split()[3]
            if amount != "-":
                rows.append(
                    ("product", m[1], amount, "房地产销售和结转/结转收入金额", None)
                )
        return rows
    if "结转收入金额" in text and re.search(r"住宅|商住|商办|综合体", text):
        lines = text.splitlines()
        heading = next((l for l in lines if "结转收入金额" in l), "")
        amount_col = heading.find("结转收入金额")
        if amount_col >= 0 and re.search(r"\d[\d,]*\.\d{2}", text):
            # Calibrate the revenue cell on complete rows; its right edge is
            # stable even when the settlement-area cell is empty.
            complete = []
            for line in lines:
                m = re.match(
                    r"\s*\d+\s+\S+\s+(.+?)\s+(?:住宅|商住|商办|综合体)\s+", line
                )
                if m:
                    ns = list(re.finditer(r"\d[\d,]*\.\d{2}", line[m.end() :]))
                    if len(ns) >= 4:
                        complete.append((lines.index(line), m.end() + ns[3].end()))
            for index, line in enumerate(lines):
                right = (
                    min(complete, key=lambda pair: abs(pair[0] - index))[1]
                    if complete
                    else None
                )
                m = re.match(
                    r"\s*\d+\s+\S+\s+(.+?)\s+(?:住宅|商住|商办|综合体)\s+", line
                )
                if not m or right is None:
                    continue
                ns = list(re.finditer(r"\d[\d,]*\.\d{2}", line[m.end() :]))
                cell = next(
                    (n for n in ns if abs(m.end() + n.end() - right) <= 3), None
                )
                if cell:
                    rows.append(
                        (
                            "product",
                            re.sub(r"\s+", "", m[1])
                            + (
                                re.sub(r"\s+", "", lines[index + 1]).split("住宅")[0]
                                if "（" in m[1]
                                and "）" not in m[1]
                                and index + 1 < len(lines)
                                and re.fullmatch(
                                    r"\s*[\u4e00-\u9fff]+[）)]\s*", lines[index + 1]
                                )
                                else ""
                            ),
                            cell.group(),
                            "房地产销售和结转/结转收入金额",
                            None,
                        )
                    )
            if rows:
                return rows
    current = None

    def flush():
        if current:
            rows.append(
                (
                    "project",
                    current[0],
                    current[1],
                    "房地产销售和结转/结转收入金额",
                    None,
                )
            )

    for line in text.splitlines():
        m = re.match(
            r"\s*\d+\s+[\u4e00-\u9fff]+\s+(?P<name>.+?)\s+(?:住宅(?:（含底商）)?|住宅、商业|商业)\s+(?P<cells>-?[\d,]+(?:\s+-?[\d,]+){4})\s*$",
            line,
        )
        if m:
            flush()
            current = [re.sub(r"\s+", "", m["name"]), m["cells"].split()[-2]]
        elif current:
            # Only a label fragment in the project's own first cell continues.
            fragment = re.match(
                r"^\s{8,}([\u4e00-\u9fffA-Z、]+(?: +[A-Z] +[\u4e00-\u9fff]+)?)\s*$",
                line,
            )
            if fragment:
                current[0] += re.sub(r"\s+", "", fragment[1])
    flush()
    m = re.search(r"实现结转收入金额\s*([\d,]+)\s*万元", text)
    if m:
        rows.append(
            (
                "business_type",
                "房地产结转收入合计",
                m[1],
                "房地产销售和结转/本期合计",
                None,
            )
        )
    return rows


def _native_company_columns(text: str) -> list[tuple] | None:
    """Keep wrapped names and business cells in their printed company columns."""
    lines = text.replace("\r", "").splitlines()
    heading = next(
        (
            i
            for i, line in enumerate(lines)
            if re.search(r"公司名称\s{2,}公司(?:类型)?\s{2,}主要(?:业务)?", line)
        ),
        None,
    )
    if heading is None:
        return None
    body = lines[heading + 1 :]
    end = next(
        (
            i
            for i, line in enumerate(body)
            if re.search(
                r"报告期内取得和处置子公司的情况|其他说明：|公司主要从事|公司及子公司主要产品|^\s*[［\[]?注[］\]]?：|^\s*2[.]本期对公司|\s指\s",
                line,
            )
        ),
        len(body),
    )
    body = body[:end]
    kind_column = next(
        (
            re.search(r"子公司|子公|参股公司|参股", line).start()
            for line in body
            if re.search(r"子公司|子公|参股公司|参股", line)
        ),
        None,
    )
    if kind_column is None or kind_column < 2:
        return None
    business_column = min(
        lines[heading].index("主要"),
        min(
            m.end()
            for line in body
            if (m := re.search(r"(?:子公司|子公|参股公司|参股)\s+", line))
        ),
    )
    groups = []
    current = None
    for i, line in enumerate(body):
        if re.search(r"年度报告|^\s*\d+\s*/\s*\d+", line):
            continue
        row_kind = re.search(r"子公司|子公|参股公司|参股", line)
        name_end = row_kind.start() if row_kind else kind_column
        fragment = re.sub(r"\s+", "", line[:name_end])
        fragment = re.sub(r"［注］|\[注\]|^注$", "", fragment)
        if fragment in {"类", "型", "类型"} and current is None:
            continue
        if not re.fullmatch(r"[\u4e00-\u9fffA-Za-z•·（）()]*", fragment):
            fragment = ""
        if fragment and (
            current is None or current[0].endswith("公司") or row_kind and current[1]
        ):
            if current:
                groups.append(current)
            current = [fragment, "", [], i]
        elif fragment and current:
            current[0] += fragment
        kind = re.search(r"子公司|子公|参股公司|参股", line)
        if kind and current:
            current[1] = "参股公司" if kind.group().startswith("参股") else "子公司"
            current[2] = re.findall(
                r"-?(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d{2})?", line[kind.end() :]
            )
    if current:
        groups.append(current)
    starts = []
    for _, _, _, start in groups:
        begin = start
        while begin and not body[begin - 1][:kind_column].strip():
            lead = body[begin - 1][business_column:].strip()
            if not lead or re.search(r"年度报告|\d+\s*/\s*\d+", lead):
                break
            if not lead.endswith(("、", "，", "的", "种")) and not (
                len(lead) >= 9
                and "、" in lead
                and not re.search(r"贸易|服务|研发|销售|等|；|，", lead)
            ):
                break
            begin -= 1
        if start >= 2 and not body[start - 2][:kind_column].strip():
            lead = re.sub(r"\s+", "", body[start - 2][business_column:])
            if re.fullmatch(r"[\u4e00-\u9fff]{2,12}的种", lead):
                begin = start - 2
        starts.append(begin)
    result = []
    for j, (name, kind, amounts, start) in enumerate(groups):
        stop = starts[j + 1] if j + 1 < len(groups) else len(body)
        # Capital may be printed on a different line than the row's type.
        number_cells = []
        for line in body[starts[j] : stop]:
            for m in re.finditer(r"-?\d[\d,]*\.\d{2}", line[business_column:]):
                number_cells.append(m.group())
        if len(number_cells) == 5 and re.search(
            r"\d+万美元", "\n".join(body[starts[j] : stop])
        ):
            number_cells.insert(
                0,
                re.search(r"\d+万美元", "\n".join(body[starts[j] : stop]))
                .group()
                .removesuffix("万美元"),
            )
        if len(number_cells) == 6:
            amounts = number_cells
        # Business cells can start one line above the wrapped actor cell.
        branches = []
        for line in body[starts[j] : stop]:
            if re.search(r"年度报告|^\s*\d+\s*/\s*\d+", line):
                continue
            cell = line[business_column:]
            cell = re.split(r"(?:USD|EUR|港币)?\s*-?\d", cell, maxsplit=1)[0]
            cell = cell.removesuffix("港币")
            branches.append(re.sub(r"\s+", "", cell))
        if kind and name:
            result.append((name, kind, "".join(branches), amounts))
    return result


def _native_company_table_rows(text: str) -> list[tuple]:
    """Read each company row independently; a blank income cannot borrow later."""
    columns = _native_company_columns(text)
    if columns is None and not re.search(
        r"注册资本\s+总资产\s+净资产\s+营业收入\s+营业利润\s+净利润", text
    ):
        return []
    if columns is not None:
        return [
            (
                "business_segment",
                name,
                amounts[3],
                "控股参股公司/营业总收入"
                if "营业总收入" in text
                else "控股参股公司/营业收入",
                None,
                kind + "：" + name,
            )
            for name, kind, _, amounts in columns
            if len(amounts) == 6
        ]
    table = re.split(r"营业利润\s+净利润", text, maxsplit=1)[1]
    table = re.split(r"报告期内取得和处置子公司的情况", table, maxsplit=1)[0]
    lines = table.splitlines()
    rows = []
    current = None

    def flush():
        if current is None:
            return
        name, kind, amounts = current
        # The six native columns are capital, assets, equity, income and profits.
        # Five values explicitly lack income; never search the following row.
        if name and len(amounts) == 6:
            rows.append(
                (
                    "business_segment",
                    name,
                    amounts[3],
                    "控股参股公司/营业收入",
                    None,
                    kind + "：" + name,
                )
            )

    for line in lines:
        kind = re.search(r"子公司|参股公(?:司)?", line)
        if kind:
            flush()
            native_name = line[: kind.start()].strip()
            name = re.sub(
                r"［注］|\[注\]",
                "",
                native_name
                if re.search(r"[A-Za-z]", native_name)
                else re.sub(r"\s+", "", native_name),
            )
            amounts = re.findall(
                r"-?(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d{2})?", line[kind.end() :]
            )
            current = [
                name,
                "参股公司" if "参股" in kind.group() else "子公司",
                amounts,
            ]
        elif (
            current
            and not current[2]
            and re.fullmatch(
                r"\s*(?:-?\d[\d,]*(?:\.\d{2})?\s+){5}-?\d[\d,]*(?:\.\d{2})?\s*", line
            )
        ):
            current[2] = line.split()
        elif (
            current
            and re.match(r"\s*[\u4e00-\u9fff]+", line)
            and not re.search(
                r"年度报告|单位|主要子公司|公司名称|^\s*名称|^\s*型$", line
            )
        ):
            # A wrapped company suffix occupies the first cell. The business
            # continuation may sit beside it and must not enter the actor.
            fragment = re.split(r"\s{2,}", line.strip())[0]
            if re.fullmatch(r"[\u4e00-\u9fff（）()]*公司|司", fragment) and not current[
                0
            ].endswith("公司"):
                current[0] += fragment
    flush()
    if not rows:
        # Native company tables declare six numeric columns. Keep the actor's
        # original row; legal scope remains qualified in its narrative evidence.
        joined = re.sub(r"(?m)^.*年度报告[^\n]*$|^\s*\d+\s*/\s*\d+\s*$", "", text)
        joined = re.sub(r"净利\s*润", "净利润", joined)
        joined = re.sub(r"参股公\s*司", "参股公司", joined)
        joined = re.split(r"营业利润\s*净利润", joined, maxsplit=1)[-1]
        joined = re.sub(r"^\s*名称\s*型\s*", "", joined)
        for m in re.finditer(
            r"(?m)^\s*(?P<name>[\u4e00-\u9fffA-Za-z（）()]+(?:[ \t]+[A-Za-z]+)?(?:[ \t]*\n[ \t]*[\u4e00-\u9fff（）()]+){0,2})\s+(?P<kind>子公司|参股公司)(?P<body>(?:(?!子公司|参股公司)[\s\S])+?)(?P<cells>(?:-?\d[\d,]*(?:\.\d{2})?\s+){5}-?\d[\d,]*(?:\.\d{2})?)(?=\s|$)",
            joined,
        ):
            cells = m["cells"].split()
            name = (
                m["name"].strip()
                if re.search(r"[A-Za-z]", m["name"])
                else re.sub(r"\s+", "", m["name"])
            )
            rows.append(
                (
                    "business_segment",
                    name,
                    cells[3],
                    "控股参股公司/营业收入",
                    None,
                    m["kind"] + "：" + name,
                )
            )
    return rows


def _native_industry_segment_rows(text: str) -> list[tuple]:
    """Read vertically wrapped industry columns without shifting empty cells."""
    lines = text.splitlines()
    start = next(
        (
            i
            for i, l in enumerate(lines)
            if re.search(r"项目\s+", l)
            and "合计" in l
            and ("行业" in l or "分部间抵" in l)
        ),
        None,
    )
    if start is None:
        return []
    cells = list(re.finditer(r"\S+", lines[start]))[1:]
    centers = [(m.start() + m.end()) / 2 for m in cells]
    labels = [[] for _ in cells]
    for l in lines[max(0, start - 1) : start + 2]:
        if "单位" in l or "适用" in l:
            continue
        if "资产总额" in l:
            break
        for m in re.finditer(r"\S+", l):
            if m.group() == "项目":
                continue
            col = min(
                range(len(cells)),
                key=lambda k: abs(centers[k] - (m.start() + m.end()) / 2),
            )
            labels[col].append(m.group())
    names = ["".join(parts) for parts in labels]
    if not names or names[-1] != "合计" or len(names) < 3:
        return []
    # The continuation's full liabilities row establishes its own physical grid.
    full = next((l for l in lines[start + 2 :] if l.strip().startswith("负债总额")), "")
    ns = list(re.finditer(r"-?\d[\d,]*\.\d{2}", full))
    if len(ns) != len(names):
        return []
    edges = [m.end() for m in ns]
    income = next(
        (l for l in lines[start + 2 :] if l.strip().startswith("营业收入")), ""
    )
    rows = []
    used = set()
    for m in re.finditer(r"-?\d[\d,]*\.\d{2}", income):
        col = min(range(len(edges)), key=lambda k: abs(edges[k] - m.end()))
        if col in used:
            continue
        used.add(col)
        rows.append(
            (
                "business_segment",
                names[col],
                m.group(),
                "报告分部/营业收入",
                None,
                "原收入列：" + names[col],
            )
        )
    return rows


def _native_note_income_rows(text: str, title: str) -> list[tuple]:
    """Read native income columns; identifiers in names never supply amounts."""
    classified = _classified_note_income_rows(text)
    if classified is not None:
        return classified
    if title == "年度主要业务数据":
        compact = re.sub(r"\s+", "", text)
        category = (
            "大宗商品经营"
            if "经营货量" in text
            else "大宗商品物流"
            if "大宗商品物流" in text
            else "生产制造"
        )
        actors = {}
        note = re.search(
            r"铁路物流、新能源物流、铝产业物流、农产品物流分别指公司子公司([^；]+?)对外提供",
            compact,
        )
        if note:
            actors.update(
                zip(
                    ("铁路物流", "新能源物流", "铝产业物流", "农产品物流"),
                    note[1].split("、"),
                )
            )
        owner = re.search(r"造船业务经营主体为公司子公司([^；。]+)", compact)
        if owner:
            actors["造船"] = owner[1]
        rows = []
        for line in text.splitlines():
            m = re.match(
                r"\s*(?:其中：)?(?:\d+(?:\.\d+)*\.?)?\s*([\u4e00-\u9fff]+)\s+([^\n]+)",
                line,
            )
            if not m:
                continue
            values = re.findall(r"-?\d[\d,]*(?:\.\d+)?%?", m[2])
            col = 2 if category == "大宗商品经营" else 0
            if (
                len(values) < 6
                or values[col].endswith("%")
                or not values[col + 1].endswith("%")
            ):
                continue
            rows.append(
                (
                    "product"
                    if category == "大宗商品经营"
                    else "service"
                    if category == "大宗商品物流"
                    else "business_segment",
                    m[1],
                    values[col],
                    "年度主要业务数据/" + category,
                    None,
                    "原子公司：" + actors[m[1]] if m[1] in actors else None,
                )
            )
        return rows
    if title == "贸易业务收入":
        match = re.search(
            r"主要是开展各类(?P<names>[\u4e00-\u9fff\s]{2,50}?)等贸易业务\s+(?P<amount>\d[\d,]*)(?=\s)",
            text,
        )
        if match and not re.search(
            r"第三方|子公司|不存在|拟|计划|尚未", text[: match.end()]
        ):
            return [
                (
                    "trade",
                    re.sub(r"\s+", "", match["names"]) + "贸易",
                    match["amount"],
                    "本期营业收入",
                    None,
                )
            ]
        if re.search(r"[√✓]适用\s*□不适用", text) and "本期营业收入" in text:
            text = text.split("贸易业务开展情况", 1)[-1].replace("\r", "")
            # Rejoin a wrapped native row label before its three printed cells.
            text = re.sub(
                r"(?m)^([\u4e00-\u9fff、]{2,45})[ \t]*\n[ \t]*([\u4e00-\u9fff、]{1,10})(?=\s+\d[\d,]*(?:\.\d+)?\s+\d)",
                r"\1\2",
                text,
            )
            return [
                (
                    "business_type",
                    m[1],
                    m[2],
                    "本期营业收入",
                    None,
                    "原子公司：" + m[1] if m[1].endswith("公司") else None,
                )
                for m in re.finditer(
                    r"(?m)^\s*([\u4e00-\u9fff、]{2,45})\s+(\d[\d,]*(?:\.\d+)?)\s+\d",
                    re.split(
                        r"贸易业务占营业收入|前五名|其他说明|\n\s*3、", text, maxsplit=1
                    )[0],
                )
            ]
        return []
    rows = []
    contract_rows = _native_contract_column_rows(text)
    if contract_rows is not None:
        rows.extend(contract_rows)
        text = re.split(r"合同分类|项目(?=\s{2,}分部\s{2,}合计)", text, maxsplit=1)[0]
    text = _join_native_income_cells(text)
    text = re.split(r"营业成本分解信息", text, maxsplit=1)[0]
    text = re.split(r"收入确认时间", text, maxsplit=1)[0]
    if "本期客户合同产生的收入情况如下" in text:
        timing = re.sub(
            r"在\s*某\s*一\s*时\s*(点|段\s*内)\s*确\s*认",
            lambda m: "在某一时" + re.sub(r"\s+", "", m[1]) + "确认",
            text,
        )
        for m in re.finditer(
            r"在某一时(点|段内)确认\s+((?:\d[\d,]*\.\d+\s+)+)", timing
        ):
            cells = m[2].split()
            rows.append(
                (
                    "revenue_timing",
                    "在某一时" + m[1] + "确认",
                    cells[-1],
                    "客户合同收入/确认时间/本期合计",
                    None,
                )
            )
    text = re.sub(
        r"((?:主营|其他)业务\s+(?:[-/]\s+){3}[-/])\s+(?=(?:主营|其他)业务)",
        r"\1\n",
        text,
    )
    cleaned = re.sub(r"(?m)^.*年度报告[^\n]*\n?", "", text.replace("\r", ""))
    cleaned = re.sub(r"(?<=\d)\s*,\s*(?=\d)", ",", cleaned)
    cleaned = re.sub(r"(\.\d{2})(?=-?\d)", r"\1 ", cleaned)
    cleaned = re.sub(r"(?m)^\s*\d+\s*/\s*\d+\s*$", "", cleaned)
    cleaned = re.sub(
        r"([\u4e00-\u9fff、]{2,40})\n\s*(件|咨询和监理)\s*\n\s*(?=\d)",
        r"\1\2 ",
        cleaned,
    )
    cleaned = re.sub(r"中国\s*[(（]\s*含港澳\s*台\s*[)）]", "中国（含港澳台）", cleaned)
    lines = cleaned.splitlines()
    for i in range(len(lines) - 1):
        m = re.match(r"\s*(?P<label>[^\d\n]+?)\s+\d[\d,]*\.\d{2}", lines[i])
        tail = lines[i + 1].strip()
        if (
            m
            and re.fullmatch(r"[\u4e00-\u9fff]{1,2}", tail)
            and tail not in {"合计", "小计"}
        ):
            lines[i] = lines[i].replace(
                m["label"], re.sub(r"\s+", "", m["label"]) + tail, 1
            )
            lines[i + 1] = ""
    for i in range(len(lines) - 1):
        current, nxt = lines[i].strip(), lines[i + 1].strip()
        if (
            re.fullmatch(r"[\u4e00-\u9fff、]{2,40}", current)
            and current
            not in {
                "商品类型",
                "按经营地区分类",
                "主营业务收入",
                "其他业务收入",
                "主营业务成本",
                "其他业务成本",
                "合计",
            }
            and re.match(r"(?:服务(?:收入)?|发与销售|件|咨询和监理)\s+\d", nxt)
        ):
            lines[i + 1] = current + nxt
            lines[i] = ""
    cleaned = "\n".join(lines)
    main_only_regions = False
    main = re.search(r"(?m)^\s*主营业务\s+(\d[\d,]*\.\d{2})", cleaned)
    geography = re.search(r"按经营地区分类([\s\S]+?)(?=其他说明|履约义务|$)", cleaned)
    if main and geography:
        region_values = re.findall(
            r"(?m)^\s*(?:境内|境外)[^\d\n]*?(\d[\d,]*\.\d{2})", geography[1]
        )
        main_only_regions = bool(region_values) and sum(
            Decimal(v.replace(",", "")) for v in region_values
        ) == Decimal(main[1].replace(",", ""))
    basis = ""
    dimension = ""
    segment_labels = []
    current_columns = (
        "合同分类" in cleaned and "营业收入" in cleaned and "营业成本" in cleaned
    )
    conventional_years = False
    aggregate_income_columns = False
    business_basis = ""
    # Join only printed note labels, never classification headings into a row.
    cleaned = re.sub(r"固定资产试\s*运行销售", "固定资产试运行销售", cleaned)
    cleaned = re.sub(r"(?:其中：)?在某一\s*时点确认\s*\n", "在某一时点确认 ", cleaned)
    cleaned = re.sub(
        r"(?:其中：)?在某一\s*时点确认\s*(?=\d)", "在某一时点确认 ", cleaned
    )
    cleaned = re.sub(r"在某一\s*时段确认\s*-\s*-\s*", "\n", cleaned)
    cleaned = re.sub(
        r"固定资产试运行销售\s*\n\s*(?=\d)", "固定资产试运行销售 ", cleaned
    )
    cleaned = re.sub(r"(?m)^\s*[-/]\s+[-/]\s+(?=(?:主营|其他)业务)", "", cleaned)
    cleaned = re.sub(r"按商品转让的时间\s*分类", "按商品转让的时间分类", cleaned)
    cleaned = re.sub(r"按商品转让的时\s*间分类", "按商品转让的时间分类", cleaned)
    cleaned = re.sub(r"(?<=\.\d{2})\s+(?=合计\s+\d)", "\n", cleaned)
    for line in cleaned.splitlines():
        if re.search(
            r"公司前五名客户|客户名称|履约义务的说明|分摊至剩余履约义务|其他说明", line
        ):
            basis, dimension = "", ""
        compact = re.sub(r"\s+", "", line)
        if title.startswith("营业收入和营业成本"):
            section = re.fullmatch(r"[（(]\d+[)）][.．]?(主营业务|其他业务)", compact)
            if section:
                basis, dimension = section[1] + "收入", "product"
        if title == "项目销售收入":
            if "项目本期发生额上期发生额" in compact:
                current_columns = True
            dimension, basis = "project", "房地产销售收入"
        elif title == "贸易业务收入":
            if "贸易业务开展情况本期营业收入" in compact:
                current_columns = True
            dimension, basis = "trade", "本期营业收入"
        else:
            if compact == "营业收入和营业成本":
                basis, dimension = "营业收入", "product"
            if re.search(
                r"(?:主营|其他)业务收入(?:和(?:主营|其他)业务成本)?[:：]?$", compact
            ) or re.fullmatch(
                r"((?:主营|其他)业务收入(?:主营|其他)业务成本){2}", compact
            ):
                basis = "主营业务收入" if "主营业务收入" in compact else "其他业务收入"
                dimension = "product"
            elif re.search(r"(?:主营|其他)业务成本$", compact):
                basis, dimension = "", ""
            if "按商品转让的时间分类" in compact:
                basis, dimension = "收入确认时点", "revenue_timing"
            if "合同产生的收入的情况" in compact:
                basis, dimension = "合同产生的收入", "contract_type"
            if "商品类型" == compact:
                basis, dimension = "全部营业收入/商品类型", "product"
            if "按销售渠道分类" in compact:
                basis, dimension = "全部营业收入/销售渠道", "sales_mode"
            if "主营业务分地区列示如下" in compact:
                basis, dimension = "主营业务收入/地区", "region"
            if "按经营地区分类" in compact:
                basis, dimension = (
                    (
                        "主营业务收入/经营地区"
                        if main_only_regions
                        else "全部营业收入/经营地区"
                    ),
                    "region",
                )
            if "市场或客户类型" in compact:
                basis, dimension = "全部营业收入/市场或客户类型", "region"
            if "营业收入、营业成本的明细" in compact:
                basis, dimension = "营业收入明细", "product"
                business_basis = ""
            elif "营业收入明细" in compact:
                basis, dimension = "营业收入明细", "business_type"
            report_dim = re.fullmatch(
                r"[A-C][.．]主营业务[（(]分(行业|产品|地区)[)）]", compact
            )
            if report_dim:
                basis, dimension = (
                    "主营业务收入",
                    {"行业": "industry", "产品": "product", "地区": "region"}[
                        report_dim[1]
                    ],
                )
                business_basis = ""
            if "国家或地区" in compact:
                basis, dimension = "对外交易收入", "region"
            if "分部间抵销" in compact and "合计" in compact and "收入" not in compact:
                header = re.sub(r"分部\s*\d+\s*", "", line)
                segment_labels = re.sub(
                    r"^\s*(?:项目|合同分类|202\d\s*年)\s*", "", header
                ).split()
                # Native numbered segment headers have no repeated year row.
                if re.search(r"分部\s*\d+", line):
                    current_columns = True
                if re.match(r"202\d\s*年", header.strip()):
                    current_columns = True
            if re.search(r"[^\s]+-分部", compact) and compact.endswith("合计"):
                aggregate_income_columns = True
                conventional_years = False
            # A conventional current/prior header must be present; an isolated
            # sentence with a number is not an income row.
            if re.search(r"(?:本期|202\d年).*(?:上期|202\d年)", compact) or compact in {
                "收入成本收入成本",
                "营业收入营业成本营业收入营业成本",
                "营业收入营业成本营业收入营业成本营业收入营业成本营业收入营业成本",
            }:
                current_columns = True
                if re.search(r"本期.*上期", compact) or compact == "收入成本收入成本":
                    conventional_years = True
        match = re.match(
            r"^\s*(?P<label>.+?)\s+(?P<values>(?:\(?-?\d[\d,]*(?:\.\d+)?\)?|-|/)(?:\s+(?:\(?-?\d[\d,]*(?:\.\d+)?\)?|-|/))*)\s*$",
            line,
        )
        if not match or not current_columns:
            continue
        label = re.sub(r"\s+", "", match["label"])
        values = match["values"].split()
        if (
            not re.search(r"[\u4e00-\u9fff]", label)
            or label in {"项目", "合计", "总计"}
            and not (
                label == "合计"
                and (
                    basis in {"营业收入", "主营业务收入", "其他业务收入"}
                    or basis == "营业收入明细"
                    or basis.startswith(("全部营业收入", "主营业务收入/"))
                )
            )
            or "合计" in label
            and label != "分部营业收入合计"
            and not (
                label == "合计"
                and (
                    basis in {"营业收入", "主营业务收入", "其他业务收入"}
                    or basis == "营业收入明细"
                    or basis.startswith(("全部营业收入", "主营业务收入/"))
                )
            )
            or "年度" in label
        ):
            continue
        if title == "项目销售收入":
            # Layout may omit a blank current cell. A one-value row is accepted
            # only when its printed placement is in the current column, handled
            # below by the header/row geometry marker retained in the span.
            if label in _prior_only_income_labels(text):
                continue
            rows.append((dimension, label, values[0], basis, None))
            continue
        if title == "贸易业务收入":
            if not re.search(r"[√✓]适用\s*□不适用", text) or not values:
                continue
            rows.append((dimension, label, values[0], basis, None))
            continue
        if segment_labels and any(
            b in label
            for b in ("对外交易收入", "分部间交易收入", "分部营业收入合计", "营业收入")
        ):
            column_basis = next(
                b
                for b in (
                    "分部间交易收入",
                    "对外营业收入",
                    "对外交易收入",
                    "分部营业收入合计",
                    "营业收入",
                )
                if b in label
            )
            paired_years = len(values) == 2 * len(segment_labels)
            cells = values[::2] if paired_years else values
            labels = list(segment_labels)
            if not paired_years and column_basis in {"对外交易收入", "对外营业收入"}:
                labels = [l for l in labels if "抵销" not in l]
            elif not paired_years and column_basis == "分部间交易收入":
                # Compact parsers omit blanks. The native report's reconciliation
                # fixes missing internal cells as external == segment total.
                totals = {
                    r[1]: r[2] for r in rows if r[3] in {"营业收入", "分部营业收入合计"}
                }
                external = {
                    r[1]: r[2] for r in rows if r[3] in {"对外交易收入", "对外营业收入"}
                }
                labels = [
                    l
                    for l in labels
                    if l != "合计" and ("抵销" in l or totals.get(l) != external.get(l))
                ]
            if len(cells) != len(labels):
                continue
            for name, value in zip(labels, cells):
                if name == "未分配项目" or value == "-":
                    continue
                adjustment = (
                    RowClass.CONSOLIDATION_ADJUSTMENT if "抵销" in name else None
                )
                val = "-" + value[1:-1] if value.startswith("(") else value
                rows.append(
                    (
                        "adjustment" if adjustment else "business_segment",
                        name,
                        val,
                        column_basis,
                        adjustment,
                    )
                )
            continue
        if values[0] in {"-", "/"}:
            continue
        if label in {"合计", "小计", "其中：合同产生的收入", "其他收入"} and (
            basis in {"主营业务收入", "其他业务收入", "营业收入", "营业收入明细"}
            or basis == "营业收入明细"
            or basis.startswith(("全部营业收入", "主营业务收入/"))
        ):
            rows.append(
                (
                    (
                        dimension
                        if basis == "营业收入明细" or title == "报告分部的财务信息"
                        else "business_type"
                    ),
                    "主营业务"
                    if label == "小计" and basis == "主营业务收入"
                    else label.removeprefix("其中："),
                    values[0],
                    "营业收入"
                    if basis.startswith("全部营业收入/商品类型/")
                    else basis
                    if basis in {"营业收入明细", "营业收入"}
                    or title == "报告分部的财务信息"
                    else "营业收入/" + basis,
                    None,
                )
            )
            continue
        category = re.fullmatch(r"(?:[12][．.])?(主营业务|其他业务)", label)
        if category:
            business_basis = category[1]
            if not dimension:
                # The separate native revenue/cost header handles these totals.
                continue
            if dimension == "revenue_timing":
                # Parent total for timing children, not a geographic/sales row.
                continue
            if dimension == "product":
                basis = "全部营业收入/商品类型/" + business_basis
            rows.append(("business_type", category[1], values[0], "营业收入", None))
            continue
        if re.match(r"^(?:主营业务收入|其他业务收入)[(（]?[a-z]?[)）]?$", label):
            name = re.sub(r"[(（][a-z][)）]", "", label)
            rows.append(("business_type", name, values[0], "营业收入", None))
            continue
        if label == "固定资产试运行销售":
            rows.append(("product", label, values[0], "固定资产试运行销售收入", None))
            continue
        if basis and dimension:
            if any(t in label for t in ["成本", "说明", "报告", "日期"]) or values[
                0
            ] in {"-", "/"}:
                continue
            amount = (
                values[-2]
                if (aggregate_income_columns or segment_labels)
                and not conventional_years
                and len(values) >= 2
                else values[0]
            )
            label = label.removeprefix("其中：").rstrip("：:")
            if label.startswith("与客户间的运输合同产生的"):
                label = label.removeprefix("与客户间的运输合同产生的")
            row_basis = (
                basis + "/" + business_basis if dimension == "revenue_timing" else basis
            )
            rows.append((dimension, label, amount, row_basis, None))
    return rows


def _prior_only_income_labels(text: str) -> set[str]:
    """Blank current cells must be distinguished from one-value current rows.

    Derive column positions from complete two-value rows in the original layout.
    Plain text without positions cannot locate an isolated value in either year.
    """
    numbered = []
    pairs = []
    for line in text.splitlines():
        matches = list(re.finditer(r"-?\d[\d,]*\.\d{2}", line))
        if not matches or re.search(r"合计|总计|单位", line):
            continue
        label = re.sub(r"\s+", "", line[: matches[0].start()])
        numbered.append((label, matches))
        if len(matches) == 4 and re.search(r"\s{3,}", line):
            pairs.append((matches[0].start(), matches[2].start()))
        if len(matches) == 2 and re.search(r"\s{3,}", line):
            pairs.append((matches[0].start(), matches[1].start()))
    boundary = sum((a + b) / 2 for a, b in pairs) / len(pairs) if pairs else None
    return {
        label
        for label, matches in numbered
        if len(matches) == 1 and (boundary is None or matches[0].start() > boundary)
    }


def _current_sparse_income_label(text: str) -> str | None:
    """Locate one printed sparse income cell using both native year totals.

    Plain owner text can lose blank-column positions. Accept a printed value
    only if the first table's current total requires it and the prior total
    already reconciles without it; never infer a missing amount or cost.
    """
    if not re.search(r"本期发生额\s+上期发生额\s+收入\s+成本\s+收入\s+成本", text):
        return None
    complete = []
    sparse = []
    for line in text.splitlines():
        m = re.fullmatch(r"\s*(主营业务|其他业务|合计)\s+(.+?)\s*", line)
        if m is None:
            continue
        cells = m[2].split()
        if not all(re.fullmatch(r"-?\d[\d,]*\.\d{2}", c) for c in cells):
            return None
        amounts = [Decimal(c.replace(",", "")) for c in cells]
        if m[1] == "合计":
            if len(amounts) != 4 or len(sparse) != 1 or not complete:
                return None
            label, value = sparse[0]
            if (
                value != 0
                and sum(r[0] for r in complete) + value == amounts[0]
                and sum(r[2] for r in complete) == amounts[2]
            ):
                return label
            return None
        if len(amounts) == 4:
            complete.append(amounts)
        elif len(amounts) == 1:
            sparse.append((m[1], amounts[0]))
        else:
            return None
    return None


def _complete_income_decimal_tails(cells: str, tails: str) -> str:
    """Append printed continuation digits only to visibly incomplete decimals."""
    fragments = iter(tails.split())
    return re.sub(
        r"(?<![\d.])(\d[\d,]*\.\d)(?=\s|$)", lambda m: m[1] + next(fragments, ""), cells
    )


def _sparse_revenue_pair_labels(text: str) -> set[str]:
    if not re.search(
        r"本期(?:发生额|金额)上期(?:发生额|金额)(?:项目)?收入成本收入成本",
        re.sub(r"\s+", "", text),
    ):
        return set()
    complete, sparse, totals = [], [], None
    for m in re.finditer(r"(?m)^\s*(主营业务|其他业务|合计)\s+([^\n]+)", text):
        cells = m[2].split()
        if not all(re.fullmatch(r"\d[\d,]*\.\d{2}", c) for c in cells):
            continue
        vals = [Decimal(c.replace(",", "")) for c in cells]
        if m[1] == "合计":
            totals = vals
            break
        if len(vals) == 4:
            complete.append(vals)
        elif len(vals) == 2:
            sparse.append((m[1], vals))
    if (
        totals
        and len(totals) == 4
        and sparse
        and complete
        and all(
            sum(r[col] for r in complete) + sum(r[1][j] for r in sparse) == totals[col]
            for j, col in enumerate((0, 2))
        )
    ):
        return {r[0] for r in sparse}
    return set()


def _lessor_income_rows(text: str) -> list[tuple]:
    """Recover wrapped tenants/assets without moving prior-only rent left."""
    text = re.sub(r"(\d[\d,]*\.\d{2})(?=\d[\d,]*\.\d{2})", r"\1 ", text)
    pieces = re.split(r"(?m)(?=^\s*承租方名称)", text)
    if len(pieces) > 2:
        return [row for piece in pieces[1:] for row in _lessor_income_rows(piece)]
    rows = []
    prior_only = _prior_only_income_labels(text)
    pending = ""
    current = None

    def flush():
        if current is None:
            return
        cp, asset, amount = current
        if amount != "-":
            rows.append(
                (
                    "lease",
                    asset,
                    amount,
                    "本公司作为出租方/本期确认的租赁收入",
                    None,
                    "承租方：" + cp,
                )
            )

    for line in text.splitlines():
        if not line.strip() or re.search(
            r"本公司作为出租方|年度报告|单位[:：]|承租方名称|租赁资产种类|本期确认|上期确认|^\s*(?:租赁|赁)?收入(?:\s+(?:租赁|赁)?收入)?\s*$|适用|^\s*\d+(?:\s*/\s*\d+)?\s*$",
            line,
        ):
            continue
        m = re.match(
            r"^(.*?)\s+(-|\d[\d,]*\.\d+|0)(?:\s+(-|\d[\d,]*(?:\.\d+)?|0))?\s*$", line
        )
        if m:
            flush()
            label = pending + re.sub(r"\s+", "", m[1])
            pending = ""
            cols = re.split(r"\s{2,}", m[1].strip())
            if len(cols) == 2 and (m[3] or re.sub(r"\s+", "", m[1]) not in prior_only):
                current = [
                    label.removesuffix(re.sub(r"\s+", "", cols[1])),
                    re.sub(r"\s+", "", cols[1]),
                    m[2],
                ]
                continue
            asset = re.search(
                r"(投资性房地产|投资性房地|固定资产|植物租摆|房屋及建筑物|房屋建筑物|房屋租赁|房屋及车辆|房屋及场地|车辆|房屋|土地使用权|场地租赁|广告经营权|机器设备|设备)(?:、机器(?:设备)?)?$",
                label,
            )
            current = None
            if asset and (m[3] or re.sub(r"\s+", "", m[1]) not in prior_only):
                current = [label[: asset.start()], asset.group(), m[2]]
        elif current is not None:
            # Layout keeps continuation columns separated; append each to its
            # own cell instead of manufacturing a combined counterparty/asset.
            cols = re.split(r"\s{2,}", line.strip())
            if cols:
                fragment = re.sub(r"\s+", "", cols[0])
                if re.fullmatch(r"产(?:、固定资产)?|固定资产|机器设备", fragment):
                    current[1] += fragment
                    continue
                if (
                    re.search(
                        r"(?:公司|合作社|事务所|管理局|所属单位|所属公司)[）)]?$",
                        current[0],
                    )
                    and len(cols) == 1
                ):
                    flush()
                    current = None
                    pending = fragment
                    continue
                current[0] += fragment
            if len(cols) > 1:
                current[1] += re.sub(r"\s+", "", cols[1])
        else:
            pending += re.sub(r"\s+", "", line)
    flush()
    return rows


def _native_trust_income_rows(text: str) -> list[tuple]:
    """Keep the委托方 and受托方 wrapped cells of the applicable trust table."""
    if "本公司受托管理/承包情况表" not in text:
        return []
    table = text.split("本公司受托管理/承包情况表", 1)[1]
    if re.match(r"[:：]?\s*□适用\s*√不适用", table):
        return []
    table = re.split(r"关联托管/承包情况说明|本公司委托管理", table, maxsplit=1)[0]
    rows = []
    current = None
    columns = None
    for line in table.splitlines():
        m = re.match(
            r"\s*(?P<party>\S+)\s{2,}(?P<actor>\S+)\s{2,}(?P<kind>股权托管|其他资产托管)\s+[^\n]+?(?:公允定价|协议(?:价格|定价|价)|市场价)\s+(?P<value>\d[\d,]*\.\d{2}|0)\s*$",
            line,
        )
        if m:
            current = [m["party"], m["actor"], m["kind"], m["value"]]
            columns = (m.start("actor"), m.start("kind"))
            rows.append(current)
        elif current and columns:
            actor_col, kind_col = columns
            party = re.sub(r"\s+", "", line[:actor_col])
            actor = re.sub(r"\s+", "", line[actor_col:kind_col])
            if re.fullmatch(
                r"[\u4e00-\u9fff（）()《》]+", party or " "
            ) and re.fullmatch(r"[\u4e00-\u9fff（）()]+", actor or " "):
                current[0] += party
                current[1] += actor
            else:
                current = None
    return [
        (
            "service",
            kind,
            value,
            "本公司受托管理/承包/本期确认的托管收益",
            None,
            "委托方：" + party + "；受托方：" + actor,
        )
        for party, actor, kind, value in rows
    ]


def _native_simple_related_sales_columns(text: str) -> list[tuple] | None:
    """Read the original seller cells; a continuation never starts a new party."""
    if "获批的交易" in text and "额度" in text:
        return _native_current_purchase_rows(text)
    lines = re.sub(
        r"关联交易内\s*容", "关联交易内容", text.replace("\r", "")
    ).splitlines()
    heading = next(
        (
            i
            for i, line in enumerate(lines)
            if re.search(r"关联方\s{2,}关联交易内(?:容)?", line)
        ),
        None,
    )
    if heading is None:
        return None
    data = lines[heading + 1 :]
    end = next(
        (
            i
            for i, line in enumerate(data)
            if re.search(
                r"根据本公司|购销商品、提供和接受劳务|关联受托管理|本公司作为出租方",
                line,
            )
        ),
        len(data),
    )
    data = data[:end]
    pairs = []
    content_columns = []
    for line in data:
        amounts = list(re.finditer(r"-?\d[\d,]*\.\d{2}|(?<![\d.,])0(?![\d.,])", line))
        if len(amounts) == 2:
            pairs.append([(m.start() + m.end()) / 2 for m in amounts])
        prefix = line[: amounts[0].start()] if amounts else ""
        m = re.match(r"\s*\S+\s{2,}(\S+)", prefix)
        if m:
            content_columns.append(m.start(1))
    if not content_columns:
        return None
    year_headers = list(
        re.finditer(r"本期(?:发生额|金额)|上期(?:发生额|金额)", lines[heading])
    )
    if not pairs and len(year_headers) != 2:
        return None
    # The printed year headers also locate an all-prior table; its current cells
    # remain empty rather than falling back to the first amount in each row.
    midpoint = (
        sum((a + b) / 2 for a, b in pairs) / len(pairs)
        if pairs
        else sum((m.start() + m.end()) / 2 for m in year_headers) / 2
    )
    content_column = sorted(content_columns)[len(content_columns) // 2]
    page_midpoints = {}
    page_start = 0
    for boundary in [i for i, line in enumerate(data) if "年度报告" in line] + [
        len(data)
    ]:
        page_pairs = []
        for line in data[page_start:boundary]:
            amounts = list(
                re.finditer(r"-?\d[\d,]*\.\d{2}|(?<![\d.,])0(?![\d.,])", line)
            )
            if len(amounts) == 2:
                page_pairs.append(sum((m.start() + m.end()) / 2 for m in amounts) / 2)
        if page_pairs:
            midpoint = sum(page_pairs) / len(page_pairs)
        for i in range(page_start, boundary):
            page_midpoints[i] = midpoint
        page_start = boundary
    rows = []
    previous = None
    pending_party = ""
    for line_index, line in enumerate(data):
        midpoint = page_midpoints[line_index]
        if (
            not line.strip()
            or re.fullmatch(r"\s*\d+(?:\s*/\s*\d+)?\s*", line)
            or re.search(
                r"年度报告|^\s*\d+\s*/\s*\d+|单位|适用|出售商品/提供劳务情况表|购销商品|本期发生额|上期发生额",
                line,
            )
        ):
            continue
        amounts = list(re.finditer(r"-?\d[\d,]*\.\d{2}|(?<![\d.,])0(?![\d.,])", line))
        party = re.sub(r"\s+", "", line[:content_column])
        content = re.sub(
            r"\s+",
            "",
            line[content_column : amounts[0].start()]
            if amounts
            else line[content_column:],
        )
        if amounts:
            prefix = line[: amounts[0].start()].strip()
            cells = re.split(r"\s{2,}", prefix)
            if len(cells) >= 2:
                party = re.sub(r"\s+", "", cells[0])
                content = re.sub(r"\s+", "", "".join(cells[1:]))
                content_column = line.find(cells[1])
            elif re.sub(r"\s+", "", prefix) == "合计":
                party = content = "合计"
            if party == "合计":
                content = "合计"
                pending_party = ""
            if not content:
                previous = None
                pending_party = ""
                continue
            party = pending_party + party
            pending_party = ""
            current = next(
                (m for m in amounts if (m.start() + m.end()) / 2 < midpoint), None
            )
            previous = [
                "product"
                if content == "销售商品"
                and (not party.endswith("公司") or party == "母公司")
                else "service",
                content,
                current.group() if current else None,
                "出售商品/提供劳务/本期发生额",
                None,
                "交易对方：" + party,
            ]
            if current and party:
                rows.append(previous)
        elif party:
            if previous is not None and re.fullmatch(
                r".{0,8}(?:公司|司|限合伙[）)]|业[（(]有限合伙[）)])", party
            ):
                previous[5] += party
            else:
                pending_party += party
        elif content and previous is not None:
            previous[1] += content
    return [tuple(row) for row in rows]


def _native_current_purchase_rows(text: str) -> list[tuple]:
    """Read current purchases separately from approved limits and prior cells."""
    text = text.split("采购商品/接受劳务情况表", 1)[-1]
    text = text.split("出售商品/提供劳务情况表", 1)[0]
    rows = []
    for section in re.split(r"(?m)^.*年度报告[^\n]*$", text):
        lines = section.splitlines()
        starts = [
            m.start(1)
            for l in lines
            if re.search(r"\d[\d,]*\.\d{2}", l)
            and (m := re.match(r"\s*\S+\s{2,}(\S+)", l))
            and not re.search(r"关联方|单位|是否|度（|额度", l)
        ]
        if not starts:
            continue
        column = sorted(starts)[len(starts) // 2]
        current_edges = [
            ns[0].end()
            for line in lines
            if len(
                ns := list(re.finditer(r"\d[\d,]*\.\d{2}|(?<![\d.,])0(?![\d.,])", line))
            )
            >= 2
            and not re.search("单位|年度报告|本期发生额|上期发生额", line)
        ]
        if not current_edges:
            continue
        current_right = sorted(current_edges)[len(current_edges) // 2]
        actor = content = ""
        amount = None

        def flush(actor, content, amount):
            if actor and content and amount:
                rows.append(
                    (
                        "product",
                        content,
                        amount,
                        "采购商品/接受劳务/本期发生额",
                        None,
                        "交易对方：" + actor,
                    )
                )

        for line in lines:
            if not line.strip() or re.search(
                r"单位|^\s*关联方(?:\s|$)|关联交易|是否超过|获批|度（|额度|内容|本期发生额|上期发生额|^\s*[□√]|^\s*\d+\s*/\s*\d+\s*$",
                line,
            ):
                continue
            party = re.sub(r"\s+", "", line[:column])
            if party and actor.endswith(
                ("公司", "检验站", "研究院", "工厂", "分厂", "学校", "其他关联方")
            ):
                flush(actor, content, amount)
                actor = content = ""
                amount = None
            if party and re.fullmatch(r"[\u4e00-\u9fff（）()《》]+", party):
                actor += party
            ns = list(re.finditer(r"\d[\d,]*\.\d{2}|(?<![\d.,])0(?![\d.,])", line))
            current = next((m for m in ns if abs(m.end() - current_right) <= 4), None)
            boundary = ns[0].start() if ns else current_right - 14
            fragment = re.sub(r"\s+", "", line[column:boundary])
            if re.fullmatch(r"[\u4e00-\u9fffA-Za-z、/]+", fragment or " "):
                content += fragment
            if current:
                amount = current.group()
        flush(actor, content, amount)
    return rows


def _native_related_sales_columns(text: str) -> list[tuple] | None:
    """Bind wrapped party and content cells to their printed two-year row."""
    if "获批的交易" in text and "额度" in text:
        return _native_current_purchase_rows(text)
    lines = re.sub(
        r"关联交易内\s*容", "关联交易内容", text.replace("\r", "")
    ).splitlines()
    heading = next(
        (
            i
            for i, l in enumerate(lines)
            if re.search(r"关联方\s{2,}关联交易内(?:容)?", l)
        ),
        None,
    )
    if heading is None:
        return None
    if not any(
        "、" in line[: m.start()]
        for line in lines[heading + 1 :]
        if (m := re.search(r"-?\d[\d,]*\.\d{2}|(?<![\d.,])0(?![\d.,])", line))
    ):
        return _native_simple_related_sales_columns(text)
    data = lines[heading + 1 :]
    end = next(
        (
            i
            for i, l in enumerate(data)
            if re.search(
                r"根据本公司|购销商品、提供和接受劳务|关联受托管理|本公司作为出租方", l
            )
        ),
        len(data),
    )
    data = data[:end]
    rows = []
    # Each repeated page header resets physical columns. Content and party
    # fragments above/below a centred amount stay with that row, not its neighbour.
    sections = re.split(r"(?m)^.*年度报告[^\n]*$", "\n".join(data))
    for section in sections:
        block = section.splitlines()
        anchors = []
        content_starts = []
        pairs = []
        for i, line in enumerate(block):
            amounts = list(
                re.finditer(r"-?\d[\d,]*\.\d{2}|(?<![\d.,])0(?![\d.,])", line)
            )
            if not amounts:
                continue
            anchors.append((i, amounts))
            if len(amounts) == 2:
                pairs.append(sum((a.start() + a.end()) / 2 for a in amounts) / 2)
            prefix = line[: amounts[0].start()]
            cells = re.match(r"\s*\S+\s{2,}(\S+)", prefix)
            if cells:
                content_starts.append(cells.start(1))
        if not anchors or not content_starts:
            continue
        if not pairs:
            # A continuation can contain only current-only and prior-only rows.
            # Preserve the inherited year header instead of dropping this page.
            rows.extend(
                _native_simple_related_sales_columns(lines[heading] + "\n" + section)
                or []
            )
            continue
        column = min(content_starts)
        midpoint = sum(pairs) / len(pairs)
        cells = [[[], []] for _ in anchors]
        for i, line in enumerate(block):
            if not line.strip() or re.search(
                r"年度报告|单位|适用|获批的交易|是否超过交易|额度|^\s*(?:[（(]如适|用[）)])\s*$|本期发生额|上期发生额|出售商品/提供劳务情况表|^\s*\d+\s*/\s*\d+\s*$",
                line,
            ):
                continue
            distances = [abs(a[0] - i) for a in anchors]
            nearest = [
                k for k, distance in enumerate(distances) if distance == min(distances)
            ]
            k = nearest[0]
            amounts = list(
                re.finditer(r"-?\d[\d,]*\.\d{2}|(?<![\d.,])0(?![\d.,])", line)
            )
            prefix = line[: amounts[0].start()] if amounts else line
            party = re.sub(r"\s+", "", prefix[:column])
            content = re.sub(r"\s+", "", prefix[column:])
            if content.startswith(")") and party.count("(") > party.count(")"):
                party += ")"
                content = content[1:]
            if not amounts:
                before = [j for j, a in enumerate(anchors) if a[0] < i]
                after = [j for j, a in enumerate(anchors) if a[0] > i]
                if (
                    party
                    and before
                    and re.fullmatch(
                        r".{0,8}(?:公司|所属单位|所属公司)[）)]?|司", party
                    )
                ):
                    k = before[-1]
                elif (
                    party
                    and after
                    or (
                        content
                        and after
                        and re.match(r"购买|采购|销售|提供|接受", content)
                        and (
                            not before
                            or not "".join(cells[before[-1]][1]).endswith(("、", "，"))
                        )
                    )
                ):
                    k = after[0]
                elif content and len(content) < 10 and before:
                    k = before[-1]
            if len(nearest) > 1 and not party and not (content and len(content) < 10):
                next_k = nearest[-1]
                # A new party starts the next vertically centred row. A short
                # one-line previous cell has no continuation above that row.
                previous_content = "".join(cells[k][1])
                if (party and len(party) > 8) or (
                    content and len(previous_content) < 10
                ):
                    k = next_k
            cells[k][0].append(party)
            cells[k][1].append(content)
        for k, (_, amounts) in enumerate(anchors):
            party, content = ("".join(v) for v in cells[k])
            if party == "合计":
                content = "合计"
            current = next(
                (a for a in amounts if (a.start() + a.end()) / 2 < midpoint), None
            )
            if not party or not content or not current:
                continue
            rows.append(
                (
                    "product"
                    if content == "销售商品"
                    and (not party.endswith("公司") or party == "母公司")
                    else "service",
                    content,
                    current.group(),
                    "出售商品/提供劳务/本期发生额",
                    None,
                    "交易对方：" + party,
                )
            )
    return rows


def _physical_main_income_rows(text: str) -> list[tuple] | None:
    """Read only the physical revenue column and its wrapped row label."""
    if not re.search(
        r"主营业务分(?:行业|产品|地区|销售模式)情况", text
    ) or not re.search(r"营业收入[ \t]{3,}营业成本", text):
        return None
    rows = []
    dim = None
    pending = ""
    current = None
    edge = None
    label_end = None
    for line in text.splitlines():
        if "主营业务分行业、分产品、分地区、分销售模式情况的说明" in line:
            break
        heading = re.search(r"主营业务分(行业|产品|地区|销售模式)情况", line)
        if heading:
            if current:
                rows.append(tuple(current))
            current = None
            pending = ""
            edge = None
            label_end = None
            dim = {
                "行业": "industry",
                "产品": "product",
                "地区": "region",
                "销售模式": "sales_mode",
            }[heading[1]]
            continue
        if not dim or re.search(r"年度报告|^\s*\d+\s*/", line):
            continue
        if "营业收入" in line and "营业成本" in line:
            edge = (line.index("营业收入") + line.index("营业成本")) / 2
            label_end = max(1, line.index("营业收入") - 1)
            continue
        if edge is None:
            continue
        amounts = list(re.finditer(r"-?\d[\d,]*\.\d{2}", line))
        revenue = amounts[0] if amounts and amounts[0].start() <= edge else None
        prefix = line[: revenue.start()] if revenue else line[:label_end]
        fragment = re.sub(r"\s+", "", prefix)
        if not re.fullmatch(r"[\u4e00-\u9fff：:]+", fragment) or fragment in {
            "分行",
            "业",
            "分产",
            "品",
            "分地",
            "区",
            "销售",
            "模式",
            "毛利率",
            "百分点",
        }:
            fragment = ""
        if re.search(r"上年|增减|（%）|营业收入|营业成本|毛利率", line):
            continue
        if revenue:
            if current:
                rows.append(tuple(current))
            label = (
                pending
                if not fragment or fragment in {"业务", "类", "店", "加工", "联营"}
                else ""
            ) + fragment
            pending = ""
            current = None
            if label:
                current = [dim, label, revenue.group(), "主营业务收入", None]
        elif fragment:
            if amounts:
                if current:
                    rows.append(tuple(current))
                current = None
                pending = fragment
            elif current:
                current[1] += fragment
            else:
                pending += fragment
    if current:
        rows.append(tuple(current))
    return rows


def _physical_current_income_summary(text: str) -> list[tuple] | None:
    """Use the current revenue/cost physical columns, including a total below its label."""
    lines = text.splitlines()
    header = next(
        (
            i
            for i, l in enumerate(lines)
            if len(re.findall(r"(?<!营业)收入|营业收入|成本", l)) == 4
            and not re.search(r"\d", l)
        ),
        None,
    )
    if header is None or not re.search(r"收入\s{3,}(?:营业)?成本", lines[header]):
        return None
    columns = list(re.finditer(r"(?:营业)?收入|(?:营业)?成本", lines[header]))
    if len(columns) != 4:
        return None
    centers = [(m.start() + m.end()) / 2 for m in columns]
    rows = []
    label = ""
    for line in lines[header + 1 :]:
        if re.search(
            r"[（(]2[)）]|营业收入、营业成本的分解|收入分解|[12][)）]\s*(?:主营业务|其他业务)",
            line,
        ):
            break
        m = re.match(r"\s*(主营业务|其他业务|合计)\s", line)
        if m:
            label = m[1]
        if not label:
            continue
        for amount in re.finditer(r"-?\d[\d,]*\.\d{2}", line):
            col = min(
                range(4),
                key=lambda k: abs(centers[k] - (amount.start() + amount.end()) / 2),
            )
            if col == 0:
                rows.append(("business_type", label, amount.group(), "营业收入", None))
    return list(dict.fromkeys(rows))


def _native_current_company_income_rows(text: str) -> list[tuple]:
    """Keep the name column with its printed current revenue, across vertical wraps."""
    start = re.search(r"本(?:期|年)发生额", text)
    if not start:
        return []
    block = text[start.end() :]
    if not re.match(r"\s+上(?:期|年)发生额", block):
        block = re.split(r"上(?:期|年)发生额|[（(]续[)）]", block, maxsplit=1)[0]
    block = re.split(r"其他说明|[（(]4[)）]", block, maxsplit=1)[0]
    rows = []
    actor = ""
    value = None
    for line in block.splitlines():
        if re.sub(r"\s+", "", line) in {
            "营业收",
            "入",
            "综合收",
            "益总额",
            "经营活动",
            "现金流量",
        }:
            continue
        if re.search(
            r"营业收入|净利润|综合收益|经营活动|子公司|年度报告|现金流量|上期发生额|金流量|^\s*额\s|^\s*\d+\s*/",
            line,
        ):
            continue
        amounts = list(re.finditer(r"-?\d[\d,]*\.\d{2}", line))
        if amounts and len(amounts) not in {4, 8}:
            continue
        prefix = line[: amounts[0].start()] if amounts else line
        fragment = re.sub(r"\s+", "", prefix)
        if not re.fullmatch(r"[\u4e00-\u9fff（）()]+", fragment):
            fragment = ""
        if fragment and fragment not in {
            "司名",
            "称",
            "子公",
            "司名称",
            "金流量",
            "额",
        }:
            actor += fragment
        if amounts:
            value = amounts[0].group()
        if actor.endswith("公司") and value:
            rows.append(
                (
                    "business_segment",
                    actor,
                    value,
                    "重要非全资子公司/本期营业收入",
                    None,
                    "原子公司：" + actor,
                )
            )
            actor = ""
            value = None
    return rows


def _project_native_income_span(
    selection: CoreEvidenceSelection, span: CoreEvidenceSpan
) -> tuple[SemanticRecord, ...] | None:
    """Native one-column revenue or transposed segment-income table, no sums."""
    title = span.section_title
    if title not in {
        "营业收入和营业成本情况",
        "主营业务原表",
        "原关联受托收入",
        "原终止经营收入",
        "原前五客户销售额",
        "产业板块主营业务收入",
        "主营业务地区原行",
        "具名公司主营业务收入",
        "关联销售原表",
        "出租情况原表",
        "各品牌盈利",
        "直营店和加盟店盈利",
        "线上线下销售渠道盈利",
        "各地区盈利",
        "补充财务原格",
        "按销售模式",
        "新能源汽车收入及补贴",
        "报告分部的财务信息",
        "收入附注原生栏目",
        "年度主要业务数据",
        "分部地理主营收入",
        "商标使用费收入",
        "项目销售收入",
        "房地产结转收入",
        "主营业务收入补充说明",
        "贸易业务收入",
        "电量收入及成本",
        "关联服务及出租收入",
        "经营租赁收入",
        "主营业务分业务",
        "境外子公司收入",
        "细分行业收入",
        "治疗领域收入",
        "渠道收入",
        "其他收入扣除明细",
        "主体营业收入",
        "联营企业收入",
        "转租收入",
        "融资租赁收入",
        "关联租出资产收入",
        "非全资子公司收入",
        "在建项目收入",
        "经营正文收入",
        "合营企业收入",
        "收入确认交叉单元",
        "关联服务交易收入",
        "临时关联服务收入",
        "受托管理收入",
        "行业产品销售收入",
    }:
        return None
    si = _prepared_for(selection, span, "segment_dimension")
    mi = _prepared_for(selection, span, "operating_revenue")
    text = (
        span.excerpt
        if title
        in {
            "收入确认交叉单元",
            "联营企业收入",
            "合营企业收入",
            "主体营业收入",
            "贸易业务收入",
        }
        or "合同分类" in span.excerpt
        or "-分部" in span.excerpt
        else _join_native_income_cells(span.excerpt)
    )
    if title in {"联营企业收入", "合营企业收入"}:
        kind = title.removesuffix("收入")
        cue = "重要" + kind + "的主要财务信息"
        if cue in text:
            convention, active = text.split(cue, 1)
            active = re.split(
                r"重要(?:合营|联营)企业的主要财务信息|\n\s*[（(]\d+[)）]\.?\s*",
                active,
                maxsplit=1,
            )[0]
            if re.match(r"\s*□适用\s*√不适用", active):
                return ()
            # The report-wide financial unit may be carried before a section
            # whose own heading does not repeat it (e.g. the telecom report).
            text = convention + cue + active
    text = re.sub(
        r"((?:主营|其他)业务\s+(?:[-/]\s+){3}[-/])\s+(?=(?:主营|其他)业务)",
        r"\1\n",
        text,
    )
    text = re.sub(r"营业收\s*\n\s*入\s*\n\s*(?=\d)", "营业收入 ", text)
    text = re.sub(r"营业收\s*\n\s*入", "营业收入", text)
    text = re.sub(r"一、营业\s*\n\s*收入", "营业收入", text)
    if "合同分类" not in text and title != "主体营业收入":
        text = re.sub(r"(\.\d{2})(?=-?\d)", r"\1 ", text)
    if title == "报告分部的财务信息":
        years = list(re.finditer(r"(?m)^\s*202\d\s*年(?=[^\n]*分部间抵销)", text))
        if len(years) > 1:
            text = text[: years[1].start()]
    unit = _unit_from_excerpt(text)
    if title == "经营正文收入":
        m = re.search(r"收入(?:达到)?\s*(?:人民币)?\s*\d[\d,.]*\s*(亿元|万元)", text)
        unit = m[1] if m else None
    if title == "主营业务收入补充说明" and re.search(
        r"收入\s*和成本金额分别为\s*[\d,]+\s*万元", text
    ):
        unit = "万元"
    if title == "商标使用费收入" and re.search(
        r"商标使用费\s*\d[\d,]*\.\d+\s*万元", text
    ):
        unit = "万元"
    if not unit:
        return ()
    extra_rows = []
    if title == "原前五客户销售额":
        for m in re.finditer(
            r"(?m)^\s*(?:\d+\s+客户\s*(\d+)|(合计)\s+/)\s+(\d[\d,]*\.\d{2})",
            span.excerpt,
        ):
            extra_rows.append(
                (
                    "customer",
                    "客户" + m[1] if m[1] else "合计",
                    m[3],
                    "前五名客户/销售额",
                    None,
                )
            )
        for m in re.finditer(
            r"(?m)^\s*\d+\s+([^\n]+?)\s{2,}(\d[\d,]*\.\d{2})\s+\d", span.excerpt
        ):
            actor = re.sub(r"\s+", "", m[1])
            if actor.endswith("公司"):
                extra_rows.append(
                    (
                        "customer",
                        actor,
                        m[2],
                        "前五名客户/销售额",
                        None,
                        "交易对方：" + actor,
                    )
                )
    if title == "原关联受托收入":
        # Fixed first and last table columns; trustee and period do not enter the party.
        table = span.excerpt.split("依据", 1)[-1]
        party = ""
        pending = None
        for line in table.splitlines():
            if re.search(r"[注]|年度报告|^\s*\d+\s*$", line):
                continue
            cells = re.split(r"\s{2,}", line.strip())
            amount = re.search(r"(\d[\d,]*\.\d{2})\s*$", line)
            if line[:10].strip():
                first = re.sub(r"\s+", "", line[:10])
                if first and not re.search(r"受托|委托|类型|收益|依据", first):
                    party += first
            if amount:
                if pending:
                    extra_rows.append(
                        (
                            "business_type",
                            "资产托管",
                            pending,
                            "关联受托管理",
                            None,
                            "交易对方：" + party,
                        )
                    )
                pending = amount[1]
            if pending and party.endswith("公司"):
                extra_rows.append(
                    (
                        "business_type",
                        "资产托管",
                        pending,
                        "关联受托管理",
                        None,
                        "交易对方：" + party,
                    )
                )
                party = ""
                pending = None
    if title == "原终止经营收入":
        for m in re.finditer(
            r"项\s*目\s+([^\n]+)\n\s*本年数[^\n]+\n营业收入\s+(\d[\d,]*\.\d{2})",
            span.excerpt,
        ):
            name = re.sub(r"\s+|\[注\]", "", m[1])
            extra_rows.append(
                (
                    "business_type",
                    name,
                    m[2],
                    "终止经营营业收入",
                    None,
                    "终止经营原主体：" + name + "；本期打印零，不推当前经营",
                )
            )
    if title == "主营业务原表":
        physical = _physical_main_income_rows(span.excerpt)
        if not physical:
            return None
        rows = physical
    else:
        rows = []
    physical_summary = (
        _physical_current_income_summary(span.excerpt)
        if title in {"营业收入和营业成本情况", "收入附注原生栏目"}
        and re.search(r"本(?:期|年)发生额", span.excerpt)
        else None
    )
    if title == "主营业务原表":
        pass
    elif physical_summary is not None:
        rows = [
            *physical_summary,
            *[
                row
                for row in (_classified_note_income_rows(text) or [])
                if row[3] != "营业收入"
            ],
        ]
    elif title in {"营业收入和营业成本情况", "收入附注原生栏目"} and re.search(
        r"项目\s+本年发生额", text
    ):
        current = re.split(r"[（(]续[)）]|项目\s+上年发生额", text, maxsplit=1)[0]
        rows = []
        for m in re.finditer(
            r"(?m)^\s*(主营业务|其他业务|合计)\s+(\d[\d,]*\.\d{2})\s+\d[\d,]*\.\d{2}\s*$",
            current,
        ):
            rows.append(("business_type", m[1], m[2], "营业收入", None))
    elif title != "主营业务原表":
        rows = []
    if title in {"原前五客户销售额", "原关联受托收入", "原终止经营收入"}:
        rows = extra_rows
    initial_rows = rows
    rows = (
        _native_industry_segment_rows(span.excerpt)
        if title == "报告分部的财务信息"
        else initial_rows
    )
    if title in {
        "产业板块主营业务收入",
        "主营业务地区原行",
        "具名公司主营业务收入",
        "关联销售原表",
        "出租情况原表",
        "各品牌盈利",
        "直营店和加盟店盈利",
        "线上线下销售渠道盈利",
        "各地区盈利",
    }:
        original_text = span.excerpt
        table_text = (
            re.split(r"注\s*1[：:]", original_text, maxsplit=1)[0]
            if title == "产业板块主营业务收入"
            else original_text
        )
        if title in {
            "各品牌盈利",
            "直营店和加盟店盈利",
            "线上线下销售渠道盈利",
            "各地区盈利",
        }:
            # A-approved interpretation of the observed apparel-table conflict.
            # This ruling is limited to the frozen official version, not a rule
            # for silently correcting units in later, unseen disclosures.
            if (
                selection.report.document_version
                != "2d2e73f7ab29177abdcf8e98b116bbddcfdbbd61b540c64096efcf1ffa90f7e8"
            ):
                return ()
            # Require the same reported total in an independent yuan revenue table.
            totals = [
                vs[0]
                for n, vs in _native_wrapped_amount_rows(table_text)
                if n == "合计"
            ]
            corroborated = any(
                "服装" in sp.excerpt
                and _unit_from_excerpt(sp.excerpt) == "元"
                and any(
                    v.replace(",", "") in re.sub(r"[\s,]+", "", sp.excerpt)
                    for v in totals
                )
                for sp in selection.spans
                if sp is not span
            )
            if not corroborated:
                return ()
            unit = "元"
        for name, values in _native_wrapped_amount_rows(table_text):
            if not values:
                continue
            qualifier = None
            dimension = "business_type"
            label = name
            header = title
            if title == "产业板块主营业务收入":
                dimension = "industry"
            elif title == "主营业务地区原行":
                dimension = "region"
                header = "主营业务分地区"
            elif title == "关联销售原表":
                if name not in {"合计"} and not name.endswith(
                    (
                        "公司",
                        "研究院",
                        "设计院",
                        "研究所",
                        "医院",
                        "中心",
                        "学院",
                        "大队",
                        "CO.,LTD",
                    )
                ):
                    continue
                label = "合计" if name == "合计" else "销售商品/提供劳务"
                header = "关联交易/销售商品及提供劳务"
                qualifier = None if name == "合计" else "交易对方：" + name
            elif title == "出租情况原表":
                if name == "合计":
                    label = "合计"
                elif "租赁办公区租金" in name:
                    name = name.replace("租赁办公区租金", "")
                    label = "租赁办公区租金"
                else:
                    continue
                header = "关联租赁/出租情况"
                qualifier = (
                    None
                    if name == "合计"
                    else "原栏目：出租方名称；按出租情况章节，交易对方：" + name
                )
            elif title == "具名公司主营业务收入":
                dimension = "business_segment"
                header = "控股参股公司/主营业务收入"
                qualifier = "原公司：" + name
                for context in selection.spans:
                    for alias, full, _ in _native_actor_definitions(context.excerpt):
                        if alias == name and "；原主体：" + full not in qualifier:
                            qualifier += "；原主体：" + full
            else:
                dimension = (
                    "region"
                    if title == "各地区盈利"
                    else "sales_mode"
                    if title in {"直营店和加盟店盈利", "线上线下销售渠道盈利"}
                    else "product"
                )
                qualifier = "金额按元解释；原表单位：万元，与同报告独立服装收入元表冲突；原打印表头保留"
            rows.append((dimension, label, values[0], header, None, qualifier))
    if title == "行业产品销售收入":
        compact = re.sub(r"\s+", "", text)
        if "产品档次" in compact and "产销率" in compact:
            for m in re.finditer(r"(?m)^\s*(高档|中低档)\s+([^\n]+)", text):
                values = re.findall(r"-?\d[\d,]*\.\d{2}", m[2])
                if len(values) >= 6:
                    rows.append(("product", m[1], values[5], "产品情况/销售收入", None))
        elif "线上销售平台" in compact:
            for m in re.finditer(
                r"(?m)^\s*(\S+)\s+(高档|中低档)\s+(\d[\d,]*\.\d{2})", text
            ):
                rows.append(
                    (
                        "product",
                        m[2],
                        m[3],
                        "线上销售情况/本期销售收入",
                        None,
                        "交易对方：" + m[1],
                    )
                )
        elif "按不同类型披露公司主营业务构成" in compact:
            blocks = re.split(r"(按产品档次|按销售渠道|按地区分部)", text)
            for index in range(1, len(blocks), 2):
                label = blocks[index]
                dim = {
                    "按产品档次": "product",
                    "按销售渠道": "sales_mode",
                    "按地区分部": "region",
                }[label]
                basis = "主营业务构成/" + label
                for line in _join_segment_label_amounts(
                    blocks[index + 1], core_answer_repair=True
                ).splitlines():
                    m = re.match(r"\s*(.+?)\s+(\d[\d,]*\.\d{2})(?:\s|$)", line)
                    if m:
                        rows.append((dim, re.sub(r"\s+", "", m[1]), m[2], basis, None))
        else:
            dim = "sales_mode" if "渠道类型" in compact else "region"
            basis = (
                "销售渠道/本期销售收入"
                if dim == "sales_mode"
                else "区域情况/本期销售收入"
            )
            for m in re.finditer(
                r"(?m)^\s*([^\d\n]+?)\s+(\d[\d,]*\.\d{2})(?:\s|$)", text
            ):
                name = re.sub(r"\s+", "", m[1])
                if not re.search(r"单位|适用|收入|渠道类型|区域名称|比重|%", name):
                    rows.append((dim, name, m[2], basis, None))
    if title == "临时关联服务收入":
        pending = ""
        for line in span.excerpt.replace("\r", "").splitlines():
            m = re.match(
                r"\s*(?:(?P<party>.+?)\s+)?(?:其他关联人|参股子公司)\s+"
                r"(?P<direction>提供劳务|购买商品|接受劳务)\s+(?P<name>\S+)\s+"
                r"市场定价\s+(?P<value>\d[\d,]*\.\d{2})\s+",
                line,
            )
            if m:
                if m["direction"] == "提供劳务":
                    rows.append(
                        (
                            "service",
                            m["name"],
                            m["value"],
                            "临时公告未披露关联交易/本期收入",
                            None,
                            "交易对方："
                            + pending
                            + re.sub(r"\s+", "", m["party"] or ""),
                        )
                    )
                pending = ""
            elif re.fullmatch(r"\s*[\u4e00-\u9fff（）：()]{2,30}\s*", line):
                pending += re.sub(r"\s+", "", line)
            else:
                pending = ""
    if title == "受托管理收入":
        trust_text = re.split(r"收益\s*\n", text, maxsplit=1)[-1]
        for m in re.finditer(
            r"(?P<party>[\u4e00-\u9fff（）()\s]+?有限公司)\s+本公司\s+"
            r"(?P<name>股权托管)\s+\d{4}\.\d{1,2}\.\d{1,2}\s+"
            r"\d{4}\.\d{1,2}\.\d{1,2}\s+[^\d]+?(?P<value>\d[\d,]*\.\d{2})",
            trust_text,
        ):
            rows.append(
                (
                    "service",
                    m["name"],
                    m["value"],
                    "本公司受托管理/承包/本期确认的托管收益",
                    None,
                    "委托方：" + re.sub(r"\s+", "", m["party"]),
                )
            )
    if title == "主营业务收入补充说明":
        m = re.search(
            r"投资性房地产[^。]+收入和成本金额分别为\s*([\d,]+)\s*万元",
            re.sub(r"\s+", "", text),
        )
        if m:
            unit = "万元"
            rows.append(
                ("product", "投资性房地产", m[1], "其他业务收入/投资性房地产", None)
            )
        m = re.search(
            r"(减：行业间交易抵消|行业间抵消|分部抵消|分部抵销)\s+(-?[\d,]+\.\d{2})",
            text,
        )
        if m:
            rows.append(
                (
                    "adjustment",
                    m[1],
                    m[2],
                    "主营业务分行业/分部抵消",
                    RowClass.CONSOLIDATION_ADJUSTMENT,
                )
            )
        total = re.search(r"(主营业务合计|合计)\s+(-?[\d,]+\.\d{2})", text)
        if total:
            rows.append(("industry", total[1], total[2], "主营业务收入", None))
    if title == "房地产结转收入":
        rows.extend(_real_estate_settlement_rows(span.excerpt))
    if title == "收入确认交叉单元":
        header = next(
            (line for line in text.splitlines() if "收入确认时间" in line), ""
        )
        columns = list(re.finditer(r"销售商品及其他|提供劳务|其他业务收入", header))
        if len(columns) >= 2:
            centers = [(m.start() + m.end()) / 2 for m in columns]
            for line in text.splitlines():
                timing = re.search(r"在某一时(?:点|段内)确认", line)
                if timing:
                    for amount in re.finditer(r"\d[\d,]*\.\d{2}", line):
                        # Printed column placement retains empty cells; numbers
                        # must not be shifted to the preceding nonempty column.
                        center = (amount.start() + amount.end()) / 2
                        column = min(
                            range(len(columns)), key=lambda i: abs(centers[i] - center)
                        )
                        rows.append(
                            (
                                "revenue_timing",
                                columns[column].group(),
                                amount.group(),
                                "收入确认时间/" + timing.group(),
                                None,
                            )
                        )
    if title == "关联服务交易收入":
        party = None
        for line in text.splitlines():
            heading = re.search(r"与(.+?)的交易[：:]", line)
            if heading:
                party = re.sub(r"\s+", "", heading[1])
            if not party:
                continue
            row = re.match(
                r"\s*(.+?收入)\s+(?:提供劳务|金融服务)\s+(?:\([^)]*\)\s*)*(\d[\d,]*)\s+[\d,]+\s*$",
                line,
            )
            if row:
                rows.append(
                    (
                        "service",
                        re.sub(r"\s+", "", row[1]),
                        row[2],
                        "重大关联交易/本期收入",
                        None,
                        "交易对方：" + party,
                    )
                )
    if title == "经营正文收入":
        compact = re.sub(r"\s+", "", text)
        for m in re.finditer(
            r"(?P<name>房地产开发销售|商品房|经济适用房|委建代建)(?:项目)?(?:结转)?(?:业务)?营业收入(?P<amount>\d[\d,.]*)万元",
            compact,
        ):
            rows.append(
                (
                    "business_type",
                    m["name"],
                    m["amount"],
                    "经营业务/房地产结转收入",
                    None,
                )
            )
        m = re.search(r"公司市政业务实现营业收入(?P<amount>\d[\d,.]*)万元", compact)
        if m:
            rows.append(
                ("business_type", "市政业务", m["amount"], "经营业务/营业收入", None)
            )
        for m in re.finditer(
            r"(?P<name>[\u4e00-\u9fff]{2,12})收入(?:\d+)?(?:达到)?人民币(?P<amount>\d[\d,.]*)亿元",
            compact,
        ):
            if m["name"] != "营业" and not re.search(
                r"拟|计划|尚未|将", _sentence_containing(compact, m.start())
            ):
                rows.append(
                    (
                        "business_segment",
                        m["name"],
                        m["amount"],
                        "经营业务/本期收入",
                        None,
                    )
                )
        international = re.search(
            r"\d{4}年(?P<name>[\u4e00-\u9fff]{2,12}业务)[^。]+，收入达到人民币(?P<amount>\d[\d,.]*)亿元",
            compact,
        )
        if international:
            rows.append(
                (
                    "business_segment",
                    international["name"],
                    international["amount"],
                    "经营业务/本期收入",
                    None,
                )
            )
        for m in re.finditer(
            r"公司实现(?P<name>[^。；，]{2,20})收入(?P<amount>\d[\d,.]*)(亿元|万元)",
            compact,
        ):
            if m["name"] == "营业":
                continue
            rows.append(
                ("business_segment", m["name"], m["amount"], "经营业务/本期收入", None)
            )
        for m in re.finditer(
            r"(?P<actor>[\u4e00-\u9fff]{2,30})全年实现(?P<name>[^。；，]{2,15})总收入(?P<amount>\d[\d,.]*)(亿元|万元)",
            compact,
        ):
            rows.append(
                (
                    "business_segment",
                    m["actor"],
                    m["amount"],
                    m["name"] + "/本期总收入",
                    None,
                    "原子公司：" + m["actor"],
                )
            )
            for child in re.finditer(
                r"来自(?P<name>第三方项目)的(?P<business>[^。；，]{2,15})收入(?P<amount>\d[\d,.]*)(亿元|万元)",
                compact,
            ):
                rows.append(
                    (
                        "business_segment",
                        child["name"] + child["business"],
                        child["amount"],
                        child["business"] + "/第三方项目/本期收入",
                        None,
                        "原子公司：" + m["actor"],
                    )
                )
    if title == "商标使用费收入":
        compact = re.sub(r"\s+", "", text)
        receipt = re.search(
            r"([^。③④]+?)与海外经营实体签订商标[^。]+?在此协议下[^。]+?本期收取([^。]+?)商标使用费(\d[\d,]*\.\d+)万元",
            compact,
        )
        if receipt:
            rows.append(
                (
                    "service",
                    "商标使用费",
                    receipt[3],
                    "其他关联交易/收取商标使用费",
                    None,
                    "原子公司：" + receipt[1] + "；交易对方：" + receipt[2],
                )
            )
            unit = "万元"
    if title == "收入附注原生栏目":
        timing = re.search(
            r"在一段时间履约确认收入的金额为\s*(\d[\d,]*\.\d{2})元", text
        )
        if timing:
            rows.append(
                (
                    "revenue_timing",
                    "在一段时间履约确认收入",
                    timing[1],
                    "合同收入/商品转让时间",
                    None,
                )
            )
    if title == "分部地理主营收入":
        for m in re.finditer(
            r"(?m)^\s*(中国境内|中国境外|合\s*计)\s+(\d[\d,]*\.\d{2})", text
        ):
            rows.append(
                ("region", re.sub(r"\s+", "", m[1]), m[2], "对外主营业务收入", None)
            )
    if title == "报告分部的财务信息" and re.search(
        r"项目\s+主营业务收入\s+分部间抵销\s+合计", text
    ):
        table = re.split(r"注：", text, maxsplit=1)[0]
        for m in re.finditer(
            r"(?m)^\s*([\u4e00-\u9fff]+)\s+(\d[\d,]*\.\d{2})\s+(\d[\d,]*\.\d{2})\s+(\d[\d,]*\.\d{2})\s*$",
            table,
        ):
            for basis, value in zip(("抵销前", "抵销金额", "抵销后"), m.groups()[1:]):
                adjustment = (
                    RowClass.CONSOLIDATION_ADJUSTMENT if basis == "抵销金额" else None
                )
                rows.append(
                    (
                        "adjustment" if adjustment else "business_segment",
                        m[1],
                        value,
                        "主营业务收入/" + basis,
                        adjustment,
                    )
                )
    if title == "经营租赁收入":
        # The following maturity schedule contains future receipts, not income.
        text = re.split(
            r"于资产负债表日后|未折现的租赁收款额|剩余租赁期", text, maxsplit=1
        )[0]
        for m in re.finditer(
            r"(?m)^\s*([\u4e00-\u9fff]{2,30})\s+(\d[\d,]*\.\d+)(?:\s|$)", text
        ):
            if m[1] == "项目":
                continue
            rows.append(("service", m[1], m[2], "作为出租人的经营租赁/租赁收入", None))
        if "未计入租赁收款额的可变" in text:
            for m in re.finditer(
                r"(?m)^\s*([\u4e00-\u9fff]{2,30})\s+\d[\d,]*\.\d+\s+(\d[\d,]*\.\d+)",
                text,
            ):
                rows.append(
                    ("service", m[1], m[2], "作为出租人的经营租赁/可变租赁收入", None)
                )
    if title in {"转租收入", "融资租赁收入"}:
        name = (
            "转租使用权资产取得的收入"
            if title == "转租收入"
            else "租赁投资净额的融资收益"
        )
        m = re.search(re.escape(name) + r"\s+(\d[\d,]*\.\d+)", text)
        if m and (title == "转租收入" or re.search(r"√适用\s*□不适用", text)):
            rows.append(
                (
                    "service",
                    name,
                    m[1],
                    "作为承租人/转租收入" if title == "转租收入" else title,
                    None,
                )
            )
    if title == "关联租出资产收入":
        compact = re.sub(r"(?<=[\u4e00-\u9fff])\s+(?=[\u4e00-\u9fff])", "", text)
        for m in re.finditer(
            r"(?P<party>[\u4e00-\u9fff]{2,45}公司(?:[\u4e00-\u9fff]{1,8}分公司)?)同一实际控制人\s*[（(][^）)]+[)）]\s*租出资产(?P<name>租赁收入)\s+(?P<value>\d[\d,]*\.\d+)",
            compact,
        ):
            rows.append(
                (
                    "service",
                    m["name"],
                    m["value"],
                    "日常关联交易/租出资产",
                    None,
                    "承租方：" + m["party"].removeprefix("现金结算"),
                )
            )
    if title == "其他收入扣除明细":
        compact = re.sub(r"\s+", "", text)
        for m in re.finditer(
            r"[16][.．](?P<name>正常经营之外的其他业务收入|未形成或难以形成稳定业务模式的业务所产生的收入)"
            r"(?P<row>[\s\S]*?)(?=\d+[.．][\u4e00-\u9fff]|与主营业务无关的业务收入小计|[一二三四五六七八九十]+、|$)",
            compact,
        ):
            # A blank item ends at the next native row or subtotal. Its amount
            # cannot be recovered by scanning forward into a different item.
            value = re.search(r"\d[\d,]*\.\d{2}", m["row"])
            if value is None:
                continue
            rows.append(
                (
                    "business_type",
                    m["name"],
                    value.group(),
                    "其他业务收入扣除明细/本年度",
                    None,
                )
            )
        section = re.split(r"2\.\s*不具备", text, maxsplit=1)[0]
        seen = set()
        for m in re.finditer(
            r"(?m)^\s*([\u4e00-\u9fff]{2,12})\s+(\d[\d,]*\.\d+)\s*元", section
        ):
            if m[1] not in seen:
                rows.append(
                    ("business_type", m[1], m[2], "其他业务收入扣除明细/本年度", None)
                )
                seen.add(m[1])
    if title in {"细分行业收入", "治疗领域收入", "渠道收入"}:
        joined = _join_segment_label_amounts(
            _join_pdf_soft_breaks(text), core_answer_repair=True
        )
        joined = joined.replace("同行业同领域产品毛利率情况", "")
        joined = re.sub(r"(?<=不适用)(?=合计\s+\d)", "\n", joined)
        joined = re.sub(
            r"(?m)^([\u4e00-\u9fff]{1,10})\n(?=[\u4e00-\u9fff]+\s+\d[\d,]*\.\d+)",
            r"\1",
            joined,
        )
        for line in joined.splitlines():
            m = re.match(r"\s*([\u4e00-\u9fff-]+)\s+(\d[\d,]*\.\d+)", line)
            if (
                m
                and (m[1] != "合计" or title == "治疗领域收入")
                and not line[m.end() :].lstrip().startswith("%")
            ):
                name = (
                    m[1]
                    .removeprefix("同行业同领域产品毛利率情况")
                    .removeprefix("详见情况说明")
                )
                rows.append(
                    (
                        "industry"
                        if title == "细分行业收入"
                        else "product"
                        if title == "治疗领域收入"
                        else "sales_mode",
                        name,
                        m[2],
                        title + "/主营业务",
                        None,
                    )
                )
    if title == "主体营业收入":
        rows.extend(_native_company_table_rows(text))
    if title == "非全资子公司收入":
        rows.extend(_native_current_company_income_rows(span.excerpt))
    if title == "非全资子公司收入" and not rows:
        single = re.search(r"(?m)^\s*([^\n]+及其子公司)(?:[（(]注[)）])?\s*$", text)
        amount = re.search(r"(?m)^\s*营业收入\s+(\d[\d,]*)\s+[\d,]+\s*$", text)
        if single and amount:
            name = re.sub(r"\s+", "", single[1])
            rows.append(
                (
                    "business_segment",
                    name,
                    amount[1],
                    "重要非全资子公司/本期营业收入/内部交易抵销前",
                    None,
                    "原子公司：" + name,
                )
            )
        text = re.sub(
            r"(?m)^(?P<name>[\u4e00-\u9fff]+)[ \t]+(?P<cells>[^\n]*\d[\d,]*\.\d[^\n]*)\n\s*(?P<suffix>[\u4e00-\u9fff]+)\s+(?P<tails>\d(?:\s+\d)+)\s*$",
            lambda m: (
                m["name"]
                + m["suffix"]
                + " "
                + _complete_income_decimal_tails(m["cells"], m["tails"])
            ),
            text,
        )
        current = re.search(
            r"(?:子公司名称\s+)?本(?:期|年)发生额\s+上(?:期|年)发生额(?P<table>[\s\S]+)",
            re.sub(r"子\s*公\s*司\s*名\s*称", "子公司名称", text),
        )
        if current:
            table = re.split(r"[（(]4[)）]|其他说明", current["table"], maxsplit=1)[0]
            table = re.split(r"经营活动现金\s*流\s*量", table)[-1]
            # Header wraps are not company-name fragments. Preserve only
            # native company rows, and attach a below-row legal-name tail.
            table = re.sub(
                r"营业收入|净利润|综合收\s*益\s*总\s*额|经营活动\s*现\s*金流量|子公司名称",
                "",
                table,
            )
            table = re.sub(
                r"(?m)^\s*(?P<name>[\u4e00-\u9fff（）()]+)\s+(?P<cells>\d[\d,]*\.\d{2}(?:\s+-?\d[\d,]*\.\d{2}){7})\s*\n\s*(?P<tail>[\u4e00-\u9fff（）()]+)\s*$",
                lambda m: (
                    m.group()
                    if m["name"].endswith("公司")
                    else m["name"] + m["tail"] + " " + m["cells"]
                ),
                table,
            )
            for m in re.finditer(
                r"(?m)^\s*(?P<name>[\u4e00-\u9fffA-Za-z（）()\s]{2,60}?)\s+(?P<amount>\d[\d,]*\.\d{2})(?:\s+-?\d[\d,]*\.\d{2}){7}\s*$",
                table,
            ):
                name = re.sub(r"\s+", "", m["name"])
                rows.append(
                    (
                        "business_segment",
                        name,
                        m["amount"],
                        "重要非全资子公司/本期营业收入",
                        None,
                        "原子公司：" + name,
                    )
                )
    if title == "在建项目收入" and "本期确认" in text:
        table = re.split(r"其他说明|4、", text, maxsplit=1)[0]
        for m in re.finditer(
            r"(?P<name>(?:G\d+|镇巴[（(])[\s\S]+?)\s+BOT\s+\d[\d,]*\s+\d+\s*月\s+\d+%\s+(?P<amount>\d[\d,]*\.\d{2})",
            table,
        ):
            name = re.sub(r"\s+", "", m["name"]).split("符合预期")[-1]
            # Project rows begin with a route identifier or the native project name.
            start = re.search(r"G\d+|镇巴[（(]", name)
            if start:
                rows.append(
                    (
                        "service",
                        name[start.start() :],
                        m["amount"],
                        "在建重大项目/本期确认收入",
                        None,
                    )
                )
    if title == "主体营业收入" and re.search(r"主要业务\s+注册资本", text):
        table = re.split(r"营业收入\s+净利润", text, maxsplit=1)[-1]
        table = re.sub(r"(?<=[\u4e00-\u9fff])\s+(?=[\u4e00-\u9fff])", "", table)
        for m in re.finditer(
            r"(?P<name>[\u4e00-\u9fff]+有限(?:责任)?公司)\s+100[.]00\s+[\s\S]*?(?P<cells>\d[\d,]*\.\d{2}(?:\s+-?\d[\d,]*\.\d{2}){4})|(?P<other>[\u4e00-\u9fff]+有限(?:责任)?公司)\s+51[.]00\s+[\s\S]*?(?P<othercells>\d[\d,]*\.\d{2}(?:\s+-?\d[\d,]*\.\d{2}){4})",
            table,
        ):
            name = m["name"] or m["other"]
            cells = (m["cells"] or m["othercells"]).split()
            rows.append(
                (
                    "business_segment",
                    name,
                    cells[3],
                    "控股参股公司/营业收入",
                    None,
                    "原子公司：" + name,
                )
            )
    if title in {"联营企业收入", "合营企业收入"}:
        for block in re.split(r"(?m)^\s*项目[^\n]*", span.excerpt):
            revenue = re.search(r"(?m)^\s*营业收入\s+(\d[\d,]*\.\d{2})", block)
            before = re.split(r"流动资产", block, maxsplit=1)[0]
            # Two identical printed legal names identify current/prior columns.
            fragments = re.findall(
                r"(?m)^\s*([\u4e00-\u9fff（）()]+)\s{2,}([\u4e00-\u9fff（）()]+)\s*$",
                before,
            )
            if revenue and fragments:
                left = "".join(v[0] for v in fragments)
                right = "".join(v[1] for v in fragments)
                # A single final character may sit underneath only the first name.
                left += "".join(re.findall(r"(?m)^\s+(司)\s*$", before))
                if left == right and left.endswith("公司"):
                    rows.append(
                        (
                            "business_segment",
                            left,
                            revenue[1],
                            "重要" + kind + "/本期营业收入",
                            None,
                            kind + "：" + left,
                        )
                    )
    if title in {"联营企业收入", "合营企业收入"}:
        # Each printed page has its own repeated current/prior company columns.
        # A blank current company cell cannot borrow a neighbouring company's value.
        for block in re.split(r"(?m)^.*年度报告[^\n]*$", span.excerpt):
            revenue = re.search(r"(?m)^[ \t]*营业收入[ \t]+([^\n]+)", block)
            assets = re.search(r"(?m)^\s*流动资产", block)
            if not revenue or not assets:
                continue
            prefix = block[: assets.start()]
            prefix = re.split(
                r"(?:期末|年末)余额/本(?:期|年)发生额\s+(?:期初|年初)余额/上(?:期|年)发生额",
                prefix,
            )[-1]
            lines = [
                line
                for line in prefix.splitlines()
                if line.strip() and not re.search(r"适用|财务信息|单位|原联营", line)
            ]
            header = next(
                (
                    j
                    for j, line in enumerate(lines)
                    if len(re.findall(r"[\u4e00-\u9fffA-Za-z（）()]+", line)) >= 4
                ),
                None,
            )
            if header is None:
                continue
            cells = list(re.finditer(r"[\u4e00-\u9fffA-Za-z（）()]+", lines[header]))
            centers = [(m.start() + m.end()) / 2 for m in cells]
            names = [m.group() for m in cells]
            for line in lines[header + 1 :]:
                for m in re.finditer(r"[\u4e00-\u9fffA-Za-z（）()]+", line):
                    col = min(
                        range(len(centers)),
                        key=lambda k: abs(centers[k] - (m.start() + m.end()) / 2),
                    )
                    names[col] += m.group()
            # A tall neighbouring name may start one line above the common header.
            for line in lines[:header]:
                for m in re.finditer(r"[\u4e00-\u9fffA-Za-z（）()]+", line):
                    col = min(
                        range(len(centers)),
                        key=lambda k: abs(centers[k] - (m.start() + m.end()) / 2),
                    )
                    names[col] = m.group() + names[col]
            count = len(names) // 2
            if count < 2 or names[:count] != names[count:]:
                continue
            for amount in re.finditer(r"\d[\d,]*\.\d{2}", revenue.group()):
                col = min(
                    range(len(centers)),
                    key=lambda k: abs(centers[k] - (amount.start() + amount.end()) / 2),
                )
                if col < count:
                    rows.append(
                        (
                            "business_segment",
                            names[col],
                            amount.group(),
                            "重要" + kind + "/本期营业收入",
                            None,
                            kind + "：" + names[col],
                        )
                    )
    if title in {"联营企业收入", "合营企业收入"} and not rows:
        native_header = re.search(
            r"(?:期末|年末)余额/本(?:期|年)发生额\s+(?:期初|年初)余额/上(?:期|年)发生额(?P<names>[\s\S]+?)(?=流动资产)",
            text,
        )
        native_revenue = re.search(
            r"(?m)^\s*营业收入\s+((?:\d[\d,]*\.\d{2}\s*)+)", text
        )
        if native_header and native_revenue:
            lines = [
                line for line in native_header["names"].splitlines() if line.strip()
            ]
            parts = [
                re.findall(r"[\u4e00-\u9fffA-Za-z（）()]+", line) for line in lines
            ]
            names = []
            centers = []
            if parts and len(parts[0]) >= 2:
                first = list(re.finditer(r"[\u4e00-\u9fffA-Za-z（）()]+", lines[0]))
                centers = [(m.start() + m.end()) / 2 for m in first]
                names = [m.group() for m in first]
                for line in lines[1:]:
                    for m in re.finditer(r"[\u4e00-\u9fffA-Za-z（）()]+", line):
                        column = min(
                            range(len(centers)),
                            key=lambda k: abs(centers[k] - (m.start() + m.end()) / 2),
                        )
                        names[column] += m.group()
            if not names or not (
                all(n.endswith("公司") for n in names)
                or names[: len(names) // 2] == names[len(names) // 2 :]
            ):
                names = re.findall(
                    r"[\u4e00-\u9fff（）()]+?有限公司",
                    re.sub(r"\s+", "", native_header["names"]),
                )
            values = native_revenue[1].split()
            count = len(names) // 2
            if (
                count >= 2
                and names[:count] == names[count:]
                and (len(values) == len(names) or centers)
            ):
                if len(values) == len(names):
                    current_values = list(zip(names[:count], values[:count]))
                else:
                    # A sparse associate table retains empty company columns.
                    # Match printed cell positions, never shift the next actor.
                    revenue_line = native_revenue.group().splitlines()[-1]
                    income_cells = list(re.finditer(r"\d[\d,]*\.\d{2}", revenue_line))
                    current_values = []
                    for cell in income_cells:
                        column = min(
                            range(len(centers)),
                            key=lambda k: abs(
                                centers[k] - (cell.start() + cell.end()) / 2
                            ),
                        )
                        if column < count:
                            current_values.append((names[column], cell.group()))
                rows.extend(
                    (
                        "business_segment",
                        n,
                        v,
                        "重要" + kind + "/本期营业收入",
                        None,
                        kind + "：" + n,
                    )
                    for n, v in current_values
                )
        single = re.search(r"(?m)^\s*([\u4e00-\u9fff]{2,20})\s*\n\s*202\d\s*年", text)
        amount = re.search(r"(?m)^\s*营业收入\s+(\d[\d,]*)\s+[\d,]+\s*$", text)
        if single and amount:
            kind = "合营企业" if title == "合营企业收入" else "联营企业"
            rows.append(
                (
                    "business_segment",
                    single[1],
                    amount[1],
                    "重要" + kind + "/本期营业收入",
                    None,
                    kind + "：" + single[1],
                )
            )
        header = re.search(r"本期[^\n]+上期[^\n]+\n([^\n]+)", text)
        revenue = re.search(r"(?m)^\s*营业收入\s+((?:\d[\d,]*\.\d+\s*){4})", text)
        if header and revenue and not rows:
            names = header[1].split()
            cells = revenue[1].split()
            if len(names) == 4:
                rows.extend(
                    (
                        "business_segment",
                        name,
                        value,
                        "重要" + kind + "/本期营业收入",
                        None,
                        kind + "：" + name,
                    )
                    for name, value in zip(names[:2], cells[:2])
                )
    if title in {"联营企业收入", "合营企业收入"} and not rows:
        active = text.split("重要" + kind + "的主要财务信息", 1)[-1]
        if re.search(r"√适用\s*□不适用", active[:50]):
            header = re.search(
                r"(?:期末|年末)余额/本(?:期|年)发生额\s+(?:期初|年初)余额/上(?:期|年)发生额(?P<names>[\s\S]+?)(?=流动资产)",
                active,
            )
            revenue = re.search(r"(?m)^\s*营业收入\s+((?:\d[\d,]*\.\d{2}\s*)+)", active)
            if header and revenue:
                name_lines = [
                    l.strip() for l in header["names"].splitlines() if l.strip()
                ]
                # Compact extraction is column-major. The first company ends at
                # 公司; a truncated 有限公 suffix is explicitly completed by the
                # same associate's ownership table in the evidence selection.
                names = re.findall(
                    r"[\u4e00-\u9fff]+?(?:有限公司|股份有限公司)",
                    re.sub(r"\s+", "", header["names"]),
                )
                values = revenue[1].split()
                if (
                    len(values) == 2
                    and len(names) >= 2
                    and names[0] == names[len(names) // 2]
                ):
                    rows.append(
                        (
                            "business_segment",
                            names[0],
                            values[0],
                            "重要"
                            + ("联营企业" if title == "联营企业收入" else "合营企业")
                            + "/本期营业收入",
                            None,
                            title.removesuffix("收入") + "：" + names[0],
                        )
                    )
                elif len(values) == 1 and len(name_lines) >= 2:
                    # The two period columns can name different associates.
                    # Keep the current actor's vertically wrapped left cell.
                    fragments = [re.split(r"\s{2,}", l.strip())[0] for l in name_lines]
                    actor = "".join(fragments)
                    if actor.endswith("公司"):
                        rows.append(
                            (
                                "business_segment",
                                actor,
                                values[0],
                                "重要" + kind + "/本期营业收入",
                                None,
                                kind + "：" + actor,
                            )
                        )
                elif len(values) == 2 and len(name_lines) == 1:
                    names = name_lines[0].split()
                    if len(names) == 2 and names[0] == names[1]:
                        name = names[0]
                        if name.endswith("有限公"):
                            full = re.search(
                                re.escape(name) + "司", re.sub(r"\s+", "", text)
                            )
                            if full:
                                name = full.group()
                        rows.append(
                            (
                                "business_segment",
                                name,
                                values[0],
                                "重要" + kind + "/本期营业收入",
                                None,
                                kind + "：" + name,
                            )
                        )
    if title == "主营业务分业务":
        joined = _join_segment_label_amounts(
            _join_pdf_soft_breaks(text), core_answer_repair=True
        )
        for line in joined.splitlines():
            row = _parse_segment_row(line)
            if row and row[0] != "合计":
                rows.append(("business_type", row[0], row[1], "主营业务分业务", None))
    if title == "境外子公司收入":
        for m in re.finditer(
            r"(?m)^\s*([A-Za-z]+(?:\s+[A-Za-z]+){1,6})\s+资产收购\s+[^\n]+?\s+(\d[\d,]*\.\d+)\s+\d",
            text.replace("Silver Fern\nFarms Limited", "Silver Fern Farms Limited"),
        ):
            rows.append(
                (
                    "business_segment",
                    m[1],
                    m[2],
                    "境外资产/本报告期营业收入",
                    None,
                    "原子公司：" + m[1],
                )
            )
    if title == "电量收入及成本" and "售电量" in text and "收入" in text:
        for line in text.splitlines():
            m = re.match(r"\s*([\u4e00-\u9fff]{2,10})\s+(.*)", line)
            if not m:
                continue
            cells = re.findall(r"-?\d[\d,]*\.\d+%?", m[2])
            if (
                len(cells) >= 7
                and cells[1].endswith("%")
                and cells[3].endswith("%")
                and not cells[4].endswith("%")
            ):
                rows.append(
                    (
                        "product",
                        m[1],
                        cells[4],
                        "电力行业电量、收入及成本/本期收入",
                        None,
                    )
                )
    if title == "关联服务及出租收入":
        lessor = "本公司作为出租方" in text
        if lessor:
            rows.extend(_lessor_income_rows(text))
        elif "本公司受托管理/承包情况表" in text:
            rows.extend(_native_trust_income_rows(span.excerpt))
            current = None
            for line in re.split(r"关联托管/承包情况说明", span.excerpt, maxsplit=1)[
                0
            ].splitlines():
                m = re.match(
                    r"^\s*(\S+)\s+(\S+)\s+(其他资产托管|股权托管)\s+[^\n]+?协议(?:价格|定价|价)\s+(\d[\d,]*\.\d+)",
                    line,
                )
                if m and not _native_trust_income_rows(span.excerpt):
                    current = [
                        "service",
                        m[3],
                        m[4],
                        "本公司受托管理/承包/本期确认的托管收益",
                        None,
                        "委托方：" + m[1] + "；受托方：" + m[2],
                    ]
                    rows.append(current)
                elif (
                    current
                    and re.search(r"公司|中心", line)
                    and not re.search(r"情况|本公司|年度报告", line)
                ):
                    cells = re.split(r"\s{2,}", line.strip())
                    if (
                        len(cells) >= 2
                        and re.fullmatch(r"[\u4e00-\u9fff（）()①-⑳]+", cells[0])
                        and re.fullmatch(r"[\u4e00-\u9fff（）()]+", cells[1])
                    ):
                        party, actor = current[5].split("；受托方：")
                        current[5] = (
                            party
                            + re.sub(r"\s+", "", cells[0])
                            + "；受托方："
                            + actor
                            + re.sub(r"\s+", "", cells[1])
                        )
                    elif len(cells) == 1:
                        current[5] += re.sub(r"\s+", "", cells[0])
        else:
            seller_column = "本期金额" if "本期金额" in text else "本期发生额"
            native_sales = _native_related_sales_columns(span.excerpt)
            if native_sales is not None:
                rows.extend(native_sales)
            if native_sales is None and re.search(r"关联方\s+关联交易内容", text):
                pending = ""
                has_layout_year_pair = any(
                    re.search(r"\d[\d,]*\.\d{2} {3,}\d[\d,]*\.\d{2}", line)
                    for line in text.splitlines()
                )
                prior_only = (
                    _prior_only_income_labels(text) if has_layout_year_pair else set()
                )
                for line in text.splitlines():
                    if not line.strip() or re.search(
                        r"年度报告|^\s*\d+\s*/\s*\d+|适用|单位|^\s*关联方\s|本期发生额|本期金额|财务报表附注|二[○〇]二[\u4e00-\u9fff]+年度|股份有限公司$|出售商品",
                        line,
                    ):
                        continue
                    m = re.match(
                        r"^\s*(?P<party>.*?)\s+(?P<name>[\u4e00-\u9fff、，]{1,30})\s+(?P<amount>-?\d[\d,]*\.\d{2})(?:\s+-?\d[\d,]*\.\d{2})?\s*$",
                        pending + " " + line if pending else line,
                    )
                    if m:
                        if re.sub(r"\s+", "", m["party"] + m["name"]) in prior_only:
                            pending = ""
                            continue
                        party = re.sub(r"\s+", "", m["party"])
                        pending = ""
                        if party:
                            rows.append(
                                (
                                    "product"
                                    if m["name"] == "销售商品"
                                    and (
                                        not party.endswith("公司") or party == "母公司"
                                    )
                                    else "service",
                                    m["name"],
                                    m["amount"],
                                    "出售商品/提供劳务/" + seller_column,
                                    None,
                                    "交易对方：" + party,
                                )
                            )
                    elif re.fullmatch(r"[\u4e00-\u9fff\s]+", line):
                        fragment = re.sub(r"\s+", "", line)
                        if (
                            not pending
                            and rows
                            and len(rows[-1]) == 6
                            and re.fullmatch(
                                r"司|公司|限公司|(?:有限(?:责任)?公司)|[\u4e00-\u9fff]{1,12}(?:分公司|店)",
                                fragment,
                            )
                        ):
                            last = rows[-1]
                            rows[-1] = (*last[:5], last[5] + fragment)
                        else:
                            pending += fragment
                    elif re.search(r"\d", line):
                        pending = ""
            for m in re.finditer(
                r"(?m)^\s*([^\s]+)\s+(租金收入|租赁收入)\s+(\d[\d,]*\.\d+)", text
            ):
                rows.append(
                    (
                        "service",
                        m[2],
                        m[3],
                        "出售商品/提供劳务/" + seller_column,
                        None,
                        "交易对方：" + m[1],
                    )
                )
            for m in re.finditer(r"管理服务费\s+(\d[\d,]*\.\d+)", text):
                rows.append(
                    (
                        "service",
                        "管理服务费",
                        m[1],
                        "出售商品/提供劳务/" + seller_column,
                        None,
                    )
                )
    if title == "收入附注原生栏目" and "按商品类型分解的" in text:
        note = text.split("其他说明", 1)[-1]
        for m in re.finditer(
            r"(?P<segment>[\u4e00-\u9fff]{2,12}分部)的其他之营业收入包括(?P<body>[^；。]+)",
            re.sub(r"\s+", "", note),
        ):
            for item in re.finditer(
                r"(?P<name>[\u4e00-\u9fff]{2,30}?)(?:收入)?(?P<value>\d[\d,]*\.\d{2})元",
                re.split(r"，其他之营业成本|其他之营业成本", m["body"], maxsplit=1)[0],
            ):
                name = item["name"].removeprefix("及").removesuffix("收入")
                if name == "租赁":
                    name += "收入"
                rows.append(
                    (
                        "product",
                        name,
                        item["value"],
                        "合同商品类型/其他收入说明",
                        None,
                        "原收入列：" + m["segment"].split("的")[-1] + "营业收入",
                    )
                )
    if (
        title
        in {
            "收入附注原生栏目",
            "年度主要业务数据",
            "项目销售收入",
            "贸易业务收入",
            "报告分部的财务信息",
        }
        and physical_summary is None
    ):
        rows.extend(_native_note_income_rows(text, title))
    headed_rows = (
        _headed_segment_income_rows(span.excerpt)
        if title == "报告分部的财务信息"
        else None
    )
    if headed_rows is not None:
        rows = headed_rows
    if title == "补充财务原格":
        rows = _accounting_supplement_rows(span.excerpt)
    for line in text.splitlines():
        if headed_rows is not None or title in {
            "主营业务原表",
            "原前五客户销售额",
            "原关联受托收入",
            "原终止经营收入",
        }:
            continue
        if physical_summary is not None:
            continue
        if title == "营业收入和营业成本情况" and re.match(
            r"\s*[12][)）]\s*(主营业务|其他业务)", line
        ):
            # Detailed subtables are owned by their native main/other columns;
            # this generic summary stops before their separate total rows.
            break
        if title in {
            "补充财务原格",
            "收入附注原生栏目",
            "年度主要业务数据",
            "分部地理主营收入",
            "项目销售收入",
            "房地产结转收入",
            "主营业务收入补充说明",
            "贸易业务收入",
            "电量收入及成本",
            "关联服务及出租收入",
            "经营租赁收入",
            "主营业务分业务",
            "境外子公司收入",
            "细分行业收入",
            "治疗领域收入",
            "渠道收入",
            "其他收入扣除明细",
            "主体营业收入",
            "联营企业收入",
            "转租收入",
            "融资租赁收入",
            "关联租出资产收入",
            "非全资子公司收入",
            "在建项目收入",
            "经营正文收入",
            "合营企业收入",
            "收入确认交叉单元",
            "关联服务交易收入",
        }:
            continue
        if title == "报告分部的财务信息":
            # The PDF owner may place the next expense row on the same line.
            line = re.split(r"二[.．、]\s*营业费用", line, maxsplit=1)[0]
        numbers = re.findall(r"(?<![\d.])-?\d[\d,]*(?:\.\d+)?", line)
        if title == "营业收入和营业成本情况":
            m = re.match(r"\s*(主营业务|其他业务|合计)\s+", line)
            columns = next(
                (
                    re.findall(r"收入|成本", h)
                    for h in text.splitlines()
                    if re.fullmatch(r"\s*(?:(?:营业)?(?:收入|成本)\s*){4}", h)
                ),
                [],
            )
            cells = line[m.end() :].split() if m else []
            if (
                m
                and len(columns) == 4
                and (
                    len(cells) == 4
                    or len(cells) == 2
                    and m[1] in _sparse_revenue_pair_labels(text)
                    or len(cells) == 1
                    and re.sub(r"\s+", "", line[: line.find(cells[0])])
                    not in _prior_only_income_labels(text)
                    or len(cells) == 1
                    and m[1] == _current_sparse_income_label(text)
                )
                and cells[columns.index("收入")] not in {"-", "/"}
            ):
                rows.append(
                    (
                        "business_type",
                        m[1],
                        cells[columns.index("收入")],
                        "营业收入",
                        None,
                    )
                )
        elif title == "按销售模式":
            m = re.match(r"\s*([\u4e00-\u9fff]{2,20})\s+", line)
            if m and len(numbers) == 4 and m[1] not in {"总计", "合计"}:
                rows.append(("sales_mode", m[1], numbers[2], "销售收入", None))
        elif title == "新能源汽车收入及补贴":
            m = re.match(r"\s*([\u4e00-\u9fff]{2,20})\s+", line)
            if m and numbers and m[1] not in {"合计", "总计"}:
                rows.append(("product", m[1], numbers[0], "收入", None))
        else:
            if rows and (
                "主营业务收入/抵销前" in {r[3] for r in rows}
                or "报告分部/营业收入" in {r[3] for r in rows}
            ):
                continue
            if title == "报告分部的财务信息" and (
                "主营业务（分" in text
                or re.search(r"分部\s*\d+|202\d\s*年[^\n]+分部间抵销", text)
            ):
                # This native table labels numbered segment columns explicitly.
                continue
            header = next(
                (
                    "项目 " + re.sub(r"\s*\n\s*", "", m[1])
                    for m in re.finditer(
                        r"(?m)^\s*项目\s+([^\n]+(?:\n[^\n]+)?分部间抵销\s+合计)", text
                    )
                ),
                "",
            )
            labels = header.split()[1:]
            if labels and title == "报告分部的财务信息":
                header_line = next(
                    (
                        l
                        for l in text.splitlines()
                        if l.strip().startswith("项目 ") and "分部间抵销" in l
                    ),
                    "",
                )
                if header_line:
                    lines = text.splitlines()
                    following = lines[
                        lines.index(header_line) + 1 : lines.index(header_line) + 2
                    ]
                    if following and re.fullmatch(
                        r"\s*[\u4e00-\u9fff]+\s*", following[0]
                    ):
                        cells = list(re.finditer(r"\S+", header_line))[1:]
                        fragment = re.search(r"\S+", following[0])
                        column = min(
                            range(len(cells)),
                            key=lambda k: abs(
                                (cells[k].start() + cells[k].end()) / 2
                                - (fragment.start() + fragment.end()) / 2
                            ),
                        )
                        labels[column] += fragment.group()
            if len(labels) < 3 or not (
                all(label.endswith("分部") for label in labels[:-2])
                or labels[-2:] == ["分部间抵销", "合计"]
            ):
                wrapped = re.search(r"月\s*31\s*日\s*([\s\S]+?)\n\s*营业收入\s", text)
                if not wrapped:
                    continue
                header = re.sub(r"\s*\n\s*", "", wrapped[1])
                header = re.sub(r"(及配件)(?=工程)", r"\1 ", header)
                header = re.sub(r"(询和监理)(?=发电)", r"\1 ", header)
                labels = header.split()
                if len(labels) != 6 or labels[-2:] != ["分部间抵销", "合计"]:
                    continue
            basis = next(
                (
                    b
                    for b in (
                        "分部间交易收入",
                        "对外营业收入",
                        "对外交易收入",
                        "主营业务收入",
                        "营业总收入",
                        "营业收入",
                    )
                    if b in re.sub(r"\s+", "", line)
                ),
                None,
            )
            if not basis or len(numbers) < len(labels) - 1:
                continue
            # Native 一. ordinal is not an amount; if a numeric ordinal exists skip it.
            numbers = re.findall(r"-?\d[\d,]*\.\d+", line)
            income_labels = (
                [label for label in labels if label != "分部间抵销"]
                if basis in {"对外交易收入", "对外营业收入"}
                and len(numbers) == len(labels) - 1
                else labels
            )
            if basis == "分部间交易收入" and len(numbers) == len(labels) - 1:
                income_labels = [label for label in labels if label != "合计"]
            if len(numbers) != len(income_labels):
                continue
            for label, value in zip(income_labels, numbers):
                if label == "合计" and title != "报告分部的财务信息":
                    continue
                adjustment = (
                    RowClass.CONSOLIDATION_ADJUSTMENT if "抵销" in label else None
                )
                rows.append(
                    (
                        "adjustment" if adjustment else "business_segment",
                        label,
                        value,
                        basis,
                        adjustment,
                    )
                )
    records = []
    if title == "报告分部的财务信息" and re.search(
        r"分部\s*\d+|202\d\s*年[^\n]+分部间抵销", text
    ):
        rows.extend(_native_note_income_rows(text, "收入附注原生栏目"))
    if title in {"电量收入及成本", "贸易业务收入"}:
        actor = None
        actor_pages = []
        for candidate in selection.spans:
            m = (
                re.search(
                    r"全资子公司([\u4e00-\u9fff]{2,20}公司)作为增量配网售电企业",
                    re.sub(r"\s+", "", candidate.excerpt),
                )
                if title == "电量收入及成本"
                else re.search(
                    r"公司的批发业务主要是子公司([\u4e00-\u9fff]{2,20}公司)的进出口贸易",
                    re.sub(r"\s+", "", candidate.excerpt),
                )
            )
            if m:
                actor = m[1]
                actor_pages = [candidate.page, *candidate.continuation_pages]
                break
        if actor:
            for candidate in selection.spans:
                for definition in re.finditer(
                    r"(?m)^[ \t]*([^\n]{1,80}?)[ \t]+指[ \t]+([^\n]+)",
                    candidate.excerpt,
                ):
                    if re.sub(r"\s+", "", definition[1]) == actor:
                        actor = definition[2].strip()
                        actor_pages.extend(
                            [candidate.page, *candidate.continuation_pages]
                        )
            rows = [(*row[:5], "原子公司：" + actor) for row in rows]
            for item in [si, mi]:
                if item is not None:
                    # The owner keeps the evidence that establishes the native
                    # actor as context; numbers remain tied to this table.
                    ev = item.evidence.model_copy(
                        update={
                            "subject_evidence_pages": tuple(dict.fromkeys(actor_pages))
                        }
                    )
                    if item is si:
                        si = item.model_copy(update={"evidence": ev})
                    else:
                        mi = item.model_copy(update={"evidence": ev})
    if title == "关联服务及出租收入" and "受托方由" in text:
        transfer = re.search(
            r"受托方由[^，。]+变更为([^，。]+)", re.sub(r"\s+", "", text)
        )
        if transfer:
            actor = transfer[1]
            for candidate in selection.spans:
                for alias, full_name, _ in _native_actor_definitions(candidate.excerpt):
                    if alias == actor:
                        actor = full_name
            rows = [
                (*row[:5], row[5].split("；受托方：")[0] + "；受托方：" + actor)
                for row in rows
            ]
    for row_index, row in enumerate(rows):
        dim, name, value, basis, row_class = row[:5]
        qualifier = row[5] if len(row) > 5 else None
        if basis == "房地产销售和结转/结转收入金额":
            associated = re.search(
                r"不含联营([^、，）)]+?)项目", re.sub(r"\s+", "", text)
            )
            if associated and associated[1] in name:
                qualifier = "联营项目：" + name + "；不含在集团结转合计内"
        if (
            title in {"年度主要业务数据", "商标使用费收入", "补充财务原格"}
            and qualifier
            and qualifier.startswith("原子公司：")
        ):
            actor = qualifier.removeprefix("原子公司：").split("；", 1)[0]
            for candidate in selection.spans:
                for alias, full_name, _ in _native_actor_definitions(candidate.excerpt):
                    if alias == actor:
                        qualifier = qualifier.replace(
                            "原子公司：" + actor, "原子公司：" + full_name
                        )
        if title in {"联营企业收入", "合营企业收入"} and name.endswith("有限公"):
            full = next(
                (
                    m.group()
                    for candidate in selection.spans
                    if (
                        m := re.search(
                            re.escape(name) + "司",
                            re.sub(r"\s+", "", candidate.excerpt),
                        )
                    )
                ),
                None,
            )
            if full:
                if qualifier:
                    qualifier = qualifier.replace(name, full)
                name = full
        for item, model in ((si, Segment), (mi, Measurement)):
            if item is None:
                continue
            kwargs = (
                {"dimension": dim, "label": name}
                if model is Segment
                else {
                    "metric_type": MetricType.OPERATING_REVENUE,
                    "logical_slot": LogicalSlot.REVENUE,
                    "measured_object": name,
                    "segment_dimension": dim,
                    "segment_label": name,
                    "relationship_context": basis,
                }
            )
            records.append(
                _base_fact(
                    model,
                    report=selection.report,
                    record_id=f"owned:{item.evidence.evidence_id}:{model.__name__}:{dim}:{name}:{basis}:row:{row_index}",
                    field_id="segment_dimension"
                    if model is Segment
                    else "operating_revenue",
                    chapter_task=ChapterTask.EXTRACT_SEGMENT_FINANCIALS,
                    evidence=item.evidence,
                    source_native=SourceNativeValue(
                        name=name,
                        value=value,
                        unit=unit,
                        header=basis,
                        qualifier="分部间抵销" if row_class else qualifier,
                    ),
                    row_class=row_class,
                    excerpt_subject=text,
                    **kwargs,
                )
            )
            if qualifier and qualifier.startswith("联营项目："):
                records[-1] = records[-1].model_copy(
                    update={
                        "subject_scope": SubjectScope.BUSINESS_SEGMENT,
                        "subject_basis": SubjectBasis.DIRECT_SOURCE_WORDING,
                    }
                )
            if (
                title
                in {"主体营业收入", "联营企业收入", "合营企业收入", "非全资子公司收入"}
                or title == "补充财务原格"
                and qualifier
                and qualifier.startswith("原子公司：")
                or title
                in {
                    "贸易业务收入",
                    "经营正文收入",
                    "电量收入及成本",
                    "年度主要业务数据",
                    "商标使用费收入",
                }
                and qualifier
            ):
                records[-1] = records[-1].model_copy(
                    update={
                        "subject_scope": SubjectScope.BUSINESS_SEGMENT
                        if title != "补充财务原格"
                        and qualifier
                        and any(
                            t in qualifier for t in ("联营企业", "合营企业", "参股公司")
                        )
                        else SubjectScope.NAMED_SUBSIDIARY,
                        "subject_basis": SubjectBasis.DIRECT_SOURCE_WORDING,
                    }
                )
    if (
        title in {"临时关联服务收入", "关联服务及出租收入"}
        and "本集团" in text
        or title == "临时关联服务收入"
    ):
        records = [
            r.model_copy(
                update={
                    "subject_scope": SubjectScope.CONSOLIDATED_GROUP,
                    "subject_basis": SubjectBasis.DIRECT_SOURCE_WORDING,
                }
            )
            for r in records
        ]
    if "母公司财务报表" in text or title == "受托管理收入":
        records = [
            r.model_copy(
                update={
                    "subject_scope": SubjectScope.ISSUER,
                    "subject_basis": SubjectBasis.DIRECT_SOURCE_WORDING,
                }
            )
            for r in records
        ]
    if title == "关联服务及出租收入" and "本公司受托管理/承包情况表" in text:
        for index, record in enumerate(records):
            qualifier = record.source_native.qualifier or ""
            actor = qualifier.split("；受托方：")[-1]
            issuer = next(
                (
                    full
                    for candidate in selection.spans
                    for alias, full, _ in _native_actor_definitions(candidate.excerpt)
                    if alias in {"公司", "本公司", "上市公司"}
                ),
                "",
            )
            records[index] = record.model_copy(
                update={
                    "subject_scope": SubjectScope.ISSUER
                    if actor in {"本公司", issuer}
                    else SubjectScope.NAMED_SUBSIDIARY,
                    "subject_basis": SubjectBasis.DIRECT_SOURCE_WORDING,
                }
            )
    if title in {"原终止经营收入", "原关联受托收入"}:
        records = [
            r.model_copy(
                update={
                    "subject_scope": (
                        SubjectScope.CONSOLIDATED_GROUP
                        if r.source_native.name == "合计"
                        else SubjectScope.BUSINESS_SEGMENT
                    )
                    if title == "原终止经营收入"
                    else SubjectScope.ISSUER,
                    "subject_basis": SubjectBasis.DIRECT_SOURCE_WORDING,
                }
            )
            for r in records
        ]
    if title == "补充财务原格" and "母公司利润表" in span.excerpt:
        records = [
            r.model_copy(
                update={
                    "subject_scope": SubjectScope.ISSUER,
                    "subject_basis": SubjectBasis.DIRECT_SOURCE_WORDING,
                }
            )
            for r in records
        ]
    if title == "具名公司主营业务收入":
        for index, record in enumerate(records):
            full = (record.source_native.qualifier or "").split("；原主体：")[-1]
            associated = any(
                name == full and associate
                for sp in selection.spans
                for name, _, associate in _native_equity_business_rows(sp.excerpt)
            )
            records[index] = record.model_copy(
                update={
                    "subject_scope": SubjectScope.BUSINESS_SEGMENT
                    if associated
                    else SubjectScope.NAMED_SUBSIDIARY,
                    "subject_basis": SubjectBasis.DIRECT_SOURCE_WORDING,
                }
            )
    if title == "境外子公司收入":
        records = [
            r.model_copy(
                update={
                    "subject_scope": SubjectScope.NAMED_SUBSIDIARY,
                    "subject_basis": SubjectBasis.DIRECT_SOURCE_WORDING,
                }
            )
            for r in records
        ]
    return tuple(records)


def _owned_product_action_bindings(excerpt: str) -> list[dict[str, Any]]:
    """Keep current subsidiary product branches and transaction directions."""
    # Remove printed page furniture before joining a word across a page break.
    native_text = re.sub(
        r"(?m)^.*年度报告[^\n]*$|^\s*\d+(?:\s*/\s*\d+)?\s*$", "", excerpt
    )
    text = re.sub(r"\s+", "", native_text)
    bindings = []

    def add(name, action, actor, verb="销售", header=None):
        bindings.append(
            {
                "name": name,
                "action": action,
                "actor": actor,
                "verb": verb,
                "header": header,
                "subject_basis": SubjectBasis.DIRECT_SOURCE_WORDING,
            }
        )

    def current(clause):
        return not re.search(
            r"第三方|不从事|不销售|未销售|未开展|不购销|未购销|尚未|拟|计划|将销售|将推出|拟推出",
            clause,
        )

    # A current manufacturing declaration governs its own major-product matrix.
    # Industry discussion, future strategy and product-cost lists lie outside it.
    matrix = re.search(
        r"公司从事的主营业务是([^。]+?)等及以上产品配件的制造和销售。[\s\S]*?主要产品如下：[\s\S]+?(?=（二）公司经营模式|报告期内公司新增重要非主营业务|$)",
        text,
    )
    if matrix and not re.search(r"拟|计划|尚未", matrix[1]):
        names = re.split(r"、", matrix[1]) + ["配件"]
        table = matrix.group()
        for m in re.finditer(
            r"(?:包含|已形成\d+-\d+行、)([^。]+?)(?:等系列产品|全产品系列)", table
        ):
            names.extend(re.split(r"、(?!大马力)", m[1]))
        # Printed product-name cells may wrap across lines. Descriptive prose
        # supplies no extra action beyond the owner's declared matrix.
        for m in re.finditer(
            r"(?m)^\s*(全地形消\s*防车|消防泵|风力\s*灭火机|插秧机|收割机|ATV\s*全\s*地形车|电动\s*ATV|摩托车)\s*$",
            native_text,
        ):
            names.append(re.sub(r"\s+", "", m[1]))
        representative = re.search(r"以([^。]+?)为核心代表", table)
        if representative:
            names.append(representative[1])
        for name in dict.fromkeys(names):
            for action in (ActivityAction.PRODUCES, ActivityAction.SELLS):
                add(name, action, "公司及合并子公司", "制造和销售", "当前主要产品矩阵")
    actual = re.search(r"公司([^。]+?)等产品产销量同比增加所致", text)
    if actual and "产销量情况说明" in text:
        for name in actual[1].split("、"):
            for action in (ActivityAction.PRODUCES, ActivityAction.SELLS):
                add(name, action, "公司及合并子公司", "产销量", "本期产销量说明")

    # Native media/service enumeration retains each noun and direction.
    for m in re.finditer(r"公司影视业务主要包括([^。]+?)等板块", text):
        for branch in m[1].split("、"):
            for suffix, actions in [
                ("制作与销售", (ActivityAction.PRODUCES, ActivityAction.SELLS)),
                ("销售", (ActivityAction.SELLS,)),
                ("服务", (ActivityAction.PROVIDES_SERVICE,)),
                ("租赁", (ActivityAction.PROVIDES_SERVICE,)),
            ]:
                for part in (
                    branch.split("与")
                    if not branch.endswith("制作与销售")
                    else [branch]
                ):
                    if part.endswith(suffix) and not (
                        suffix == "销售" and part.endswith("制作与销售")
                    ):
                        name = (
                            part.removesuffix(suffix)
                            if suffix in {"制作与销售", "销售"}
                            else part
                        )
                        for action in actions:
                            add(name, action, "公司及合并子公司", suffix)
    m = re.search(r"公司为各类影视节目与剧目提供包括([^。]+?)等全流程技术服务", text)
    if m:
        for name in re.split(r"、|及", m[1]):
            add(name, ActivityAction.PROVIDES_SERVICE, "公司及合并子公司", "提供")
    m = re.search(r"公司[^。]+拓展(新媒体直播、[^。]+?)等业务", text)
    if m and not re.search(r"拟|计划|尚未", m.group()):
        for name in re.split(r"、|及", m[1]):
            add(name, ActivityAction.PROVIDES_SERVICE, "公司及合并子公司", "拓展")
    if "公司已形成多平台协同发展的业务格局" in text:
        m = re.search(r"涵盖([^。]+?)等多个领域", text)
        if m and "媒体广告代理" in m[1]:
            add(
                "媒体广告代理",
                ActivityAction.PROVIDES_SERVICE,
                "公司及合并子公司",
                "代理",
            )
    m = re.search(r"公司旅游业务[^。]+主要收入来源包括([^。]+?)等", text)
    if m:
        for name in re.split(r"、|和", m[1]):
            if name.endswith("销售"):
                add(
                    name.removesuffix("销售"),
                    ActivityAction.SELLS,
                    "公司及合并子公司",
                    "销售",
                )
            else:
                add(
                    name,
                    ActivityAction.OPERATES
                    if name.endswith("经营")
                    else ActivityAction.PROVIDES_SERVICE,
                    "公司及合并子公司",
                    "经营" if name.endswith("经营") else "服务",
                )
    m = re.search(r"业务涉及([^。]+?)等多元领域", text)
    if m and "影视城" in text and "报告期内" in text:
        for name in m[1].split("、"):
            add(
                name,
                ActivityAction.PROVIDES_SERVICE,
                "公司及合并子公司",
                "服务",
                "当前基地业务",
            )
    if re.search(r"公司自\d{4}年起布局基金投资业务", text):
        add("基金投资", ActivityAction.OPERATES, "公司及合并子公司", "投资")
    for actor, kind, business, _ in _native_company_columns(excerpt) or []:
        if not current(business):
            continue
        entries = []
        m = re.match(r"(.+?)制造销售", business)
        if m:
            entries.extend(
                (m[1], a, "制造销售")
                for a in (ActivityAction.PRODUCES, ActivityAction.SELLS)
            )
        if business.rstrip("等") == "服务托管":
            entries.append(("服务托管", ActivityAction.PROVIDES_SERVICE, "托管"))
        if "节目制作、技术开发服务、影视设备租赁" in business:
            entries.extend(
                (name, ActivityAction.PROVIDES_SERVICE, "服务")
                for name in business.removesuffix("等").split("、")
            )
        if "广告业务" in business and re.search(r"代理|制作", business):
            entries.append(("广告业务", ActivityAction.PROVIDES_SERVICE, "代理"))
        for name, action, verb in entries:
            add(name, action, actor, verb, "控股参股公司原业务")
            if kind == "参股公司":
                bindings[-1]["subject_scope"] = SubjectScope.BUSINESS_SEGMENT
    for m in re.finditer(
        r"([\u4e00-\u9fff]+有限公司)为本公司[^。]+全资子公司[^。]*。(?:[^。]*。){0,2}?公司经营范围：([^。]+)。",
        text,
    ):
        if m[2].rstrip("等") == "投资管理、资产管理、投资咨询":
            for name in m[2].removesuffix("等").split("、"):
                add(
                    name,
                    ActivityAction.PROVIDES_SERVICE,
                    m[1],
                    "服务",
                    "原全资子公司经营范围",
                )
    if "已签订的重大采购合同截至本报告期的履行情况" in text and "√适用□不适用" in text:
        section = re.split(
            r"已签订的重大采购合同截至本报告期的履行情况", native_text, maxsplit=1
        )[1].split("成本分析表", 1)[0]
        for m in re.finditer(
            r"(?m)^\s*([\u4e00-\u9fff]{2,8}频道整\s*频道\s*(?:电视)?\s*广告资源)",
            section,
        ):
            add(
                re.sub(r"\s+", "", m[1]),
                ActivityAction.PURCHASES,
                "公司及合并子公司",
                "采购",
                "当期重大采购合同履行",
            )
        for m in re.finditer(
            r"(?m)^\s*([\u4e00-\u9fff]{2,8}频道整(?:频道)?)[^\n]*\n\s*((?:电视)?(?:频道)?广告资源)",
            section,
        ):
            add(
                m[1] + m[2],
                ActivityAction.PURCHASES,
                "公司及合并子公司",
                "采购",
                "当期重大采购合同履行",
            )

    # A branch's own grammar governs its named objects, independently of
    # neighbouring branches, product illustrations, or future orders.
    for m in re.finditer(
        r"业务主要包括([^；。]+?)(?:的研发、生产和销售|等产品的生产与销售|的研发、生产与销售)",
        text,
    ):
        if current(m.group()):
            for name in m[1].split("、"):
                name = name.removeprefix("公司输变电").removesuffix("及其他输变电产品")
                if name:
                    for action in (ActivityAction.PRODUCES, ActivityAction.SELLS):
                        add(name, action, "公司及合并子公司", "生产与销售")
    coal = re.search(
        r"业务主要包括(煤炭)的开采与销售以及(电力)及(热力)的生产和供应", text
    )
    if coal and current(coal.group()):
        for action in (ActivityAction.PRODUCES, ActivityAction.SELLS):
            add(coal[1], action, "公司及合并子公司", "开采与销售")
        for name in (coal[2], coal[3]):
            for action in (ActivityAction.PRODUCES, ActivityAction.PROVIDES_SERVICE):
                add(name, action, "公司及合并子公司", "生产和供应")
    cycle = re.search(r"同时为[^。]+提供([^。]+?)等全周期的能源解决方案", text)
    if cycle and current(cycle.group()):
        for name in re.split(r"、|及", cycle[1]):
            add(name, ActivityAction.PROVIDES_SERVICE, "公司及合并子公司", "提供")
    resources = re.search(
        r"资源贸易涉及([^。]+?)等冶金工业原料。主要业务模式[^。]+?采购，销售给", text
    )
    if resources and current(resources.group()):
        for name in resources[1].split("、"):
            for action in (ActivityAction.PURCHASES, ActivityAction.SELLS):
                add(name, action, "公司及合并子公司", "采购、销售")
    service = re.search(r"供应链服务包含([^。]+?)等，主要依托", text)
    if service and current(service.group()):
        if "提供风险管理咨询服务" in text:
            add(
                "风险管理咨询",
                ActivityAction.PROVIDES_SERVICE,
                "公司及合并子公司",
                "提供",
            )
        for name in service[1].split("、"):
            add(name, ActivityAction.PROVIDES_SERVICE, "公司及合并子公司", "服务")
        for names in re.findall(r"为[^。]+?提供([^。]+?)(?:等各类服务|服务)", text):
            for name in names.split("、"):
                if name in {"物流", "期货交割", "风险管理咨询"}:
                    add(
                        name,
                        ActivityAction.PROVIDES_SERVICE,
                        "公司及合并子公司",
                        "提供",
                    )
    for m in re.finditer(
        r"([\u4e00-\u9fff（）()]+有限(?:责任)?公司)：为公司主要从事([^。]+?)(?:业务)?的子公司",
        text,
    ):
        actor, branch = m.groups()
        actor = actor.lstrip("（）()")
        if not current(branch):
            continue
        if branch.endswith("购销"):
            for action in (ActivityAction.PURCHASES, ActivityAction.SELLS):
                add(branch.removesuffix("购销"), action, actor, "购销")
        elif branch == "黑色金属贸易流通":
            add("黑色金属", ActivityAction.SELLS, actor, "贸易流通")
        else:
            for name in re.split(r"、|以及", branch):
                if name in {"船代", "货代", "加工配送", "招标代理"}:
                    add(name, ActivityAction.PROVIDES_SERVICE, actor, "服务")
    for actor, kind, business, _ in _native_company_columns(excerpt) or []:
        if kind != "子公司" or not current(business):
            continue
        goods = re.match(r"(.+?)(?:的制造、销售|的生产、销售|开采及销售)", business)
        if goods:
            for name in goods[1].split("、"):
                if "研发" in name:
                    continue
                for action in (ActivityAction.PRODUCES, ActivityAction.SELLS):
                    add(name, action, actor, "生产、销售")

    # Explicit operating lists preserve direction; a risk-price list is not a purchase.
    services = re.search(r"为其提供大宗([^。]+?)等的一体化供应链服务", text)
    if services and current(services.group()):
        for name in services[1].split("、"):
            add(name, ActivityAction.PROVIDES_SERVICE, "公司及合并子公司", "提供")
    for m in re.finditer(r"本公司及控股子公司(?:向|为)[^。]+(?:。|$)", text):
        clause = m.group()
        if not current(clause):
            continue
        # Each roman-numbered transaction keeps the company's original direction.
        for part in re.split(r"[iv]+\.", clause):
            goods = re.search(r"(采购|销售)([^；。]+?)等(?:商品|原材料)", part)
            if goods:
                for name in goods[2].split("、"):
                    add(
                        name,
                        ActivityAction.PURCHASES
                        if goods[1] == "采购"
                        else ActivityAction.SELLS,
                        "公司及合并子公司",
                        goods[1],
                    )
            service = re.search(
                r"提供([\u4e00-\u9fff、]{2,70}?)等(?:物)?(?:流)?服务", part
            )
            if service:
                for name in service[1].split("、"):
                    add(
                        name,
                        ActivityAction.PROVIDES_SERVICE,
                        "公司及合并子公司",
                        "提供",
                    )
    for m in re.finditer(
        r"将其子公司([^。]+?(?:有限责任公司|有限公司))委托本公司子公司([^。]+?(?:有限责任公司|有限公司))经营管理",
        text,
    ):
        if current(m.group()):
            add(m[1], ActivityAction.OPERATES, m[2], "经营管理")
    if "主营业务为中成药的生产与销售" in text:
        representative = re.search(r"以([^。]+?)为代表的产品", text)
        if representative:
            for name in representative[1].split("、"):
                for action in (ActivityAction.PRODUCES, ActivityAction.SELLS):
                    add(name, action, "公司及合并子公司", "生产与销售")
    if "公司选取销售序列中具有代表性的重点品种" in text:
        for m in re.finditer(r"代表品种包括([^；。]+?)等?[；。]", text):
            for name in m[1].removesuffix("等").split("、"):
                add(name, ActivityAction.SELLS, "公司及合并子公司")
        top = re.search(r"主要品种为([^。]+)。", text)
        if top:
            for name in top[1].split("、"):
                add(name, ActivityAction.SELLS, "公司及合并子公司")
    if "中药材在公司原材料采购中占有重要位置" in text:
        m = re.search(r"这些基地所供应的([^。]+?)等中药材", text)
        if m:
            for name in m[1].split("、"):
                add(name, ActivityAction.PURCHASES, "公司及合并子公司", "采购")
    owner = re.search(r"(?m)^\s*([\u4e00-\u9fff]{2,20}商业)下属零售药店", excerpt)
    if owner and "主要销售" in text:
        actor = owner[1]
        goods = re.search(r"主要销售([^。]+?)等。", text)
        if goods:
            for name in goods[1].split("、"):
                add(name, ActivityAction.SELLS, actor)
        if "采购中西成药及饮片" in text:
            add("中西成药及饮片", ActivityAction.PURCHASES, actor, "采购")
    for actor, kind, business, _ in _native_company_columns(excerpt) or []:
        if kind != "子公司" or not current(business):
            continue
        if re.search(r"生产及销售中药产品|制造销售中药产品", business):
            names = ["中药产品"]
            covered = re.search(r"产品涵盖([^。]+?)(?:等多个领域|$)", business)
            if covered:
                names.extend(covered[1].split("、"))
            for name in names:
                for action in (ActivityAction.PRODUCES, ActivityAction.SELLS):
                    add(name, action, actor, "生产及销售", "控股公司原业务")
        enumerated = re.search(r"^([^、，；。]+?)开发、经营、销售(?:等)?$", business)
        if enumerated:
            for action, verb in (
                (ActivityAction.OPERATES, "开发经营"),
                (ActivityAction.SELLS, "销售"),
            ):
                add(enumerated[1], action, actor, verb, "控股公司原业务")
        operated = re.search(r"经营(?!和|及|、)([^、，；。]+)", business)
        if operated:
            for name in operated[1].split("、"):
                add(name, ActivityAction.OPERATES, actor, "经营", "控股公司原业务")
    native_services = re.search(
        r"铁路物流、新能源物流、铝产业物流、农产品物流分别指公司子公司([^；]+?)对外提供的市场化物流服务",
        text,
    )
    if native_services:
        for name, actor in zip(
            ("铁路物流", "新能源物流", "铝产业物流", "农产品物流"),
            native_services[1].split("、"),
        ):
            add(name, ActivityAction.PROVIDES_SERVICE, actor, "对外提供")
    logistics = re.search(
        r"综合物流指公司子公司([^。]+?)对外提供的市场化物流服务，主要包括([^。]+)", text
    )
    if logistics:
        actor = logistics[1]
        for name in re.split(r"等|综合物流方面", logistics[2], maxsplit=1)[0].split(
            "、"
        ):
            add(name, ActivityAction.PROVIDES_SERVICE, actor, "对外提供")
    if "生产制造板块包括造船、选矿和油脂加工" in text:
        for name in ("选矿", "油脂加工"):
            add(name, ActivityAction.PROCESSES, "公司及合并子公司", "生产制造")
        owner = re.search(r"造船业务经营主体为公司子公司([^；。]+)", text)
        if owner and re.search(r"交付\d+艘", text):
            for action in (ActivityAction.PRODUCES, ActivityAction.SELLS):
                add("船舶", action, owner[1], "造船交付")

    # Ownership and present sales govern the product list in that same branch.
    # Later plans do not negate the list and do not create additional products.
    owned = list(
        re.finditer(
            r"(?P<actor>[\u4e00-\u9fff]{2,12}|[A-Za-z]+(?:[A-Za-z]+)?)[（(](?:公司|全资子公司)持有其[^）)]+股权[)）]",
            text,
        )
    )
    for index, owner in enumerate(owned):
        branch = text[
            owner.end() : owned[index + 1].start()
            if index + 1 < len(owned)
            else len(text)
        ]
        intro = branch.split("该公司", 1)[0]
        products = re.search(r"(?:该公司)?主要产品(?:为|有)([^。]+)。", branch)
        if not products or not re.search(r"销售", intro) or not current(intro):
            continue
        for category in re.split(r"，以及", products[1]):
            category = re.sub(r"等(?:药品|原料药及中间体)?$", "", category)
            for name in re.split(r"[、，,]", category):
                if re.fullmatch(r"[\u4e00-\u9fff（）()]{2,40}", name):
                    add(name, ActivityAction.SELLS, owner["actor"])
    for m in re.finditer(r"(?P<names>[^。；，]{2,40})等重点产品销售同比翻\d+倍", text):
        if current(m.group()):
            for name in m["names"].split("、"):
                add(name, ActivityAction.SELLS, "公司及合并子公司")
    for m in re.finditer(
        r"销售通信产品收入指销售(?P<names>[^。]+?)等通信产品而产生的收入", text
    ):
        if current(m.group()):
            for name in m["names"].split("、"):
                add(name, ActivityAction.SELLS, "公司及合并子公司")
    platform = re.search(
        r"省级平台：以(?P<actor>[^。；，]+)为核心省级平台，负责统一采购", text
    )
    if platform and current(platform.group()) and "药品" in text:
        add("药品", ActivityAction.PURCHASES, platform["actor"], "采购")
    table = re.split(r"营业利润\s*净利润", excerpt, maxsplit=1)
    if len(table) == 2 and _native_company_columns(excerpt) is None:
        for m in re.finditer(
            r"(?m)^\s*(?P<actor>[\u4e00-\u9fffA-Za-z]+(?: [A-Za-z]+)?)\s+子公司\s+(?P<body>[^\d]+?)(?=\d[\d,]*\.\d{2})",
            table[1].split("报告期内取得和处置", 1)[0],
        ):
            body = re.sub(r"\s+", "", m["body"])
            sale = re.search(r"(?P<names>.+?)(?:的研发、生产与销售|的销售)", body)
            if sale and current(body):
                for name in re.split(r"[、，]|及", sale["names"]):
                    name = (
                        name.split("的研发", 1)[0].removesuffix("的").removesuffix("等")
                    )
                    if name:
                        add(name, ActivityAction.SELLS, m["actor"])

    # Each subsection declares its own operator; a brand is never the object.
    for branch in re.split(r"[（(][一二三四五六][)）]", text):
        owner = re.search(
            r"业务主要由子公司(.+?有限公司(?:和[^。]+?有限公司)?)从事", branch
        )
        if not owner or not current(branch):
            continue
        actor = owner[1].replace("有限公司和", "有限公司/")
        if re.search(r"直接向[^。]+销售生猪", branch):
            add("生猪", ActivityAction.SELLS, actor)
        if "外购仔猪" in branch:
            add("仔猪", ActivityAction.PURCHASES, actor, "外购")
        products = re.search(
            r"产品(?:主要)?为[“\"][^”\"]+[”\"](?:和[“\"][^”\"]+[”\"])?品牌的([^。]+)",
            branch,
        )
        if products and re.search(r"销售|流通渠道|出口", branch):
            cell = re.split(r"以及相关产品", products[1], maxsplit=1)[0].removeprefix(
                "各类分切"
            )
            for name in re.split(r"、|及", cell):
                if name:
                    add(name, ActivityAction.SELLS, actor)
        # Brand products are named goods; the marketing model affirms delivery.
        products = re.search(r"产品主要有([^。]+?)等。", branch)
        if products and re.search(r"营销业务模式|销售", branch):
            for name in re.split(r"、", products[1]):
                add(name, ActivityAction.SELLS, actor)

    for m in re.finditer(
        r"子公司([^。]+?)从事[^。]+的生产和销售，产品为[“\"][^”\"]+[”\"]品牌的([^。]+)。",
        text,
    ):
        if not current(_sentence_containing(text, m.start())):
            continue
        actor = m[1].replace("有限公司和", "有限公司/")
        # “蔬菜及番茄沙司类罐头” is one printed product, not two fragments.
        for name in re.split(r"、|和(?=蔬菜)", m[2]):
            add(name, ActivityAction.SELLS, actor)
    for m in re.finditer(
        r"子公司([^。]+?)从事[^。]+的生产和销售，产品包括([^。]+)。", text
    ):
        if not current(_sentence_containing(text, m.start())):
            continue
        actor = (
            m[1].replace("有限公司、", "有限公司/").replace("有限公司和", "有限公司/")
        )
        cell = re.search(r"各类([^，]+)产品", m[2])
        if cell:
            for name in cell[1].split("、"):
                add(name + "产品", ActivityAction.SELLS, actor)
    for m in re.finditer(
        r"([^。]+?)食品以牛排及肉牛产品为主导，集加工、销售、服务于一体[^。]+。", text
    ):
        if current(_sentence_containing(text, m.start())):
            actor = re.split(r"[；，]", m[1])[-1] + "食品"
            add("牛排", ActivityAction.SELLS, actor)
    for m in re.finditer(
        r"(?:^|[。；])([^。；]{2,12}食品)[^。]+开发([^。]+?)产品开拓餐饮新市场", text
    ):
        if current(_sentence_containing(text, m.start())):
            for name in re.split(r"及|和|、", m[2]):
                add(name + "产品", ActivityAction.SELLS, m[1])
    # Current performance paragraphs provide sales evidence independently of
    # a product's mere development or an IP/brand list.
    for m in re.finditer(
        r"([^。，]{2,12})推出新品([^。]+?)，\d+款新品，\d{4}年新品[^。]+销售额[^。]+。",
        text,
    ):
        if current(_sentence_containing(text, m.start())):
            for name in m[2].split("、"):
                add(name, ActivityAction.SELLS, m[1])
    for m in re.finditer(
        r"([^。]{2,12}食品)以[“\"]([^”\"]+)[”\"]为核心[^。]+推出了([^。]+?)等衍生产品，成为明星单品。",
        text,
    ):
        if current(_sentence_containing(text, m.start())):
            add(m[2], ActivityAction.SELLS, m[1])
            for name in m[3].split("、"):
                if name.endswith(("肉", "肉馅")):
                    add(name, ActivityAction.SELLS, m[1])
    for m in re.finditer(
        r"([^。]{2,12})推出[“\"][^”\"]+[”\"]系列([^。]+?)等\d+款新产品。重点采用全渠道营销",
        text,
    ):
        if current(_sentence_containing(text, m.start())):
            for name in m[2].split("、"):
                add(name, ActivityAction.SELLS, m[1])
    for m in re.finditer(r"完成[^。]+产品的研发及上市，包括([^。]+)。", text):
        if current(_sentence_containing(text, m.start())):
            actor_match = re.search(r"(?:^|。)([^。]{2,12})多措并举", text[: m.start()])
            if not actor_match:
                continue
            cell = re.split(r"，以及", m[1], maxsplit=1)
            for name in cell[0].split("、"):
                add(name, ActivityAction.SELLS, actor_match[1])
            if len(cell) > 1 and cell[1].endswith("棒棒糖"):
                add("棒棒糖", ActivityAction.SELLS, actor_match[1])
    for m in re.finditer(
        r"([\u4e00-\u9fff]{2,15}肉品)不断优化[\s\S]+?(?=上海爱森|$)", text
    ):
        if current(m.group()) and "持续热销" in m.group():
            goods = re.search(r"[；，]([^；，]+?)入驻[^。；，]+后持续热销", m.group())
            if goods:
                for name in goods[1].split("、"):
                    add(name, ActivityAction.SELLS, m[1])
    for sentence in re.split(r"(?<=。)", text):
        if not current(sentence):
            continue
        if "白条肉三维销售模式" in sentence and "年度白条销售超额完成" in sentence:
            add("白条肉", ActivityAction.SELLS, "公司及合并子公司")
        if "猪副产品收入表现良好" in sentence:
            add("猪副产品", ActivityAction.SELLS, "公司及合并子公司")
        if re.search(r"公司饲料贸易业务板块业务规模下降", sentence):
            add("饲料", ActivityAction.SELLS, "公司及合并子公司")
        if re.search(r"采购端通过饲料集采", sentence):
            add("饲料", ActivityAction.PURCHASES, "公司及合并子公司", "采购")
        if "生猪采购" in sentence and "公司" in sentence:
            add("生猪", ActivityAction.PURCHASES, "公司及合并子公司", "采购")
        if "本公司从事油品销售收入" in sentence:
            add("油品", ActivityAction.SELLS, "本公司")
        if re.search(r"本公司与客户之间的销售合同通常包含转让", sentence):
            m = re.search(r"转让相关(.+?)，销售(.+?)及安装的履约义务", sentence)
            if m:
                for name in [*m[1].split("及"), m[2]]:
                    add(name, ActivityAction.SELLS, "本公司")
    if re.search(r"公司主要产品包括[^。]+饮用水等，主要品牌包括", text):
        clause = re.search(r"公司主要产品包括[^。]+", text)[0]
        if current(clause):
            add("饮用水", ActivityAction.SELLS, "公司及合并子公司")
    # The native category establishes direction; a customer's 采购项目 does not.
    for m in re.finditer(
        r"(?<!不)(?<!未)(?<!拟)销售商品(.+?)(?=销售商品|购买商品|接受劳务|提供劳务|金额合计|$)",
        text,
    ):
        row = m[1]
        if not current(row):
            continue
        for product in re.finditer(
            r"车道自助发卡机|车道[^。]{0,90}?自助缴费机|高速公路机电系统设备", row
        ):
            add(
                "车道自助缴费机" if "缴费机" in product[0] else product[0],
                ActivityAction.SELLS,
                "公司及合并子公司",
                header="销售商品",
            )
    if (
        "向关联方采购商品" in text
        and not re.search(r"(?:不|未|拟|计划|将)采购商品", text)
        and re.search(r"设备及安全设施采购\d[\d,]*\.\d+\d", text)
    ):
        add(
            "设备及安全设施",
            ActivityAction.PURCHASES,
            "公司及合并子公司",
            "采购",
            "实际执行金额",
        )
    # Native subsidiary rows retain their own actor and action. Numeric columns
    # and application fields do not contribute product names.
    if "主要控股参股公司分析" in text:
        for m in re.finditer(
            r"(?m)^\s*(?P<actor>[\u4e00-\u9fff]{2,12})\s+子公司\s+(?P<body>[^\d。]{1,120})(?=\d)",
            excerpt,
        ):
            actor, body = m["actor"], re.sub(r"\s+", "", m["body"])
            if not current(body):
                continue
            goods = re.search(
                r"(?P<names>日用化工产品[（(]磷酸盐系列[)）])的制造、加工、销售", body
            )
            if goods:
                add(goods["names"], ActivityAction.SELLS, actor)
            if "水力发电、售电" in body:
                add("电力", ActivityAction.SELLS, actor, "售电")
            sale = re.search(r"(?P<names>磷化工、磷酸盐产品、洗涤用品)生产销售", body)
            if sale:
                for name in sale["names"].split("、"):
                    add(name, ActivityAction.SELLS, actor)
    if "企业集团的构成" in text and "业务性质" in text:
        table = re.split(
            r"在子公司的持股比例不同于表决权比例|重要的非全资子公司",
            excerpt,
            maxsplit=1,
        )[0]
        table = re.sub(r"(有限(?:责任)?)\s*\n\s*(公司)", r"\1\2", table)
        for m in re.finditer(
            r"(?m)^\s*(?P<actor>[\u4e00-\u9fff]{2,45}有限(?:责任)?公司)\s+(?P<location>[^\s]+)\s+[\d,.]+\s+[^\s]+\s+(?P<body>[\s\S]+?)(?=\s+\d+(?:\.\d+)?\s)",
            table,
        ):
            actor, body = m["actor"], re.sub(r"\s+", "", m["body"])
            if not current(body) or "（注" in actor:
                continue
            trade = re.search(
                r"(?:主要从事)?(?P<names>[\u4e00-\u9fff、及]{2,40})购销", body
            )
            sale = re.search(
                r"(?:主要从事)?(?P<names>[\u4e00-\u9fff、]{2,40})(?:开采、精选和|加工及|的生产与)销售",
                body,
            )
            if trade:
                for name in re.split(r"、|及", trade["names"].removeprefix("主要从事")):
                    add(name, ActivityAction.SELLS, actor, "购销")
                    add(name, ActivityAction.PURCHASES, actor, "购销")
            elif sale:
                for name in sale["names"].removeprefix("主要从事").split("、"):
                    add(name, ActivityAction.SELLS, actor)
    for m in re.finditer(
        r"子公司(?P<actor>[\u4e00-\u9fff]{2,12})[：:](?P<body>[^。]+)。", text
    ):
        sale = re.search(r"[，,](?P<name>[\u4e00-\u9fff]{2,12})销售量价齐升", m["body"])
        if sale and current(m["body"]):
            add(sale["name"], ActivityAction.SELLS, m["actor"])
    for m in re.finditer(
        r"目前公司的[^。]+主要有[^。]*?(?P<name>磷酸氢钙)[^。]+。[^。]+产品主要供应[^。]+。",
        text,
    ):
        if current(m.group()):
            add(m["name"], ActivityAction.SELLS, "公司及合并子公司", "供应")
    return bindings


def _owned_goods_bindings(excerpt: str) -> list[dict[str, Any]]:
    """Named current goods from direct actions or owned transaction columns."""
    # Remove printed page furniture before joining a word across a page break.
    native_text = re.sub(
        r"(?m)^.*年度报告[^\n]*$|^\s*\d+(?:\s*/\s*\d+)?\s*$", "", excerpt
    )
    text = re.sub(r"\s+", "", native_text)
    bindings = []

    def add(name, action, actor, verb):
        bindings.append(
            {
                "name": name,
                "action": action,
                "actor": actor,
                "verb": verb,
                "subject_basis": SubjectBasis.DIRECT_SOURCE_WORDING,
            }
        )

    for sentence in re.split(r"(?<=。)", text):
        if re.search(r"尚未|第三方|不从事|未销售|拟|计划|将销售|预研", sentence):
            continue
        owned = re.search(
            r"风电主机装备业务及关键配套业务主要包括([^。]+)主机销售等。公司通过招投标的方式获取主机订单",
            text,
        )
        if (
            owned
            and "公司通过招投标的方式获取主机订单" in sentence
            and not re.search(r"不|未|拟|计划|将|第三方", owned[1])
        ):
            add("风电主机", ActivityAction.SELLS, "公司", "销售")
        if re.search(r"公司(?:的)?塔筒业务主要包括[^。]+销售业务", sentence):
            add("塔筒", ActivityAction.SELLS, "公司", "销售")
        if re.search(r"公司风机配件销售时", sentence):
            add("风机配件", ActivityAction.SELLS, "公司", "销售")
        if re.search(r"本公司电力产品销售于[^。]+省电网公司", sentence):
            add("电力", ActivityAction.SELLS, "本公司", "销售")
        if re.search(
            r"公司控股子公司([^。]+?)主要从事叶片的设计、研发及制造业务", sentence
        ):
            actor = re.search(r"公司控股子公司([^。]+?)主要从事", sentence)[1]
            add("叶片", ActivityAction.PRODUCES, actor, "制造")
        if re.search(
            r"通过向[^。]+供应商采购[^。]+的风机零部件", sentence
        ) and re.search(r"由公司[^。]+生产制造", sentence):
            add("风机零部件", ActivityAction.PURCHASES, "公司", "采购")
    if "出售商品/提供劳务情况表" in text:
        table = text.split("出售商品/提供劳务情况表", 1)[1].split(
            "购销商品、提供和接受劳务", 1
        )[0]
        if re.search(r"√适用□不适用", table) and re.search(
            r"废旧物资处置\d[\d,]*\.\d+", table
        ):
            add("废旧物资", ActivityAction.SELLS, "本公司", "出售")
    if re.search(
        r"报告期内，公司累计获取电站建设指标[^。]+完成电站项目转让规模", text
    ) and not re.search(r"(?:拟|计划|未)完成电站项目转让", text):
        add("电站产品", ActivityAction.SELLS, "本公司", "销售")

    # The affirmative owned trade row itself supplies the names. Its income
    # stays in the revenue evidence, never in a physical-quantity field.
    if "报告期内公司存在贸易业务收入" in text:
        table = text.split("报告期内公司存在贸易业务收入", 1)[1].split("贸易业务占", 1)[
            0
        ]
        row = re.search(r"主要是开展各类([\u4e00-\u9fff]{2,30})等贸易业务\d", table)
        if row and not re.search(
            r"第三方|子公司|不存在|拟|计划|尚未|未开展", table[: row.end()]
        ):
            for name in re.split(r"及|、", row[1]):
                add(
                    name,
                    ActivityAction.SELLS,
                    "本集团" if "本集团" in text else "公司",
                    "销售",
                )

    for sentence in re.split(r"(?<=。)", text):
        if re.search(
            r"尚未|第三方公司|(?:不|未|拟|计划|将)(?:从事|开展|采购|销售|出售|购买|消耗)",
            sentence,
        ):
            continue
        direct = re.search(
            r"(?<!第三方)(?:本公司|公司)采购([\u4e00-\u9fff]{2,12})生产加工成", sentence
        )
        if direct and not re.search(r"子公司|第三方|供应商", sentence[: direct.end()]):
            add(direct[1], ActivityAction.PURCHASES, "公司", "采购")
        sale = re.search(
            r"报告期内，公司累计实现([\u4e00-\u9fff]{2,12})销售量达\d", sentence
        )
        if sale:
            add(sale[1], ActivityAction.SELLS, "公司", "销售")
        energy = re.search(
            r"本集团已采用[^。]+降低([\u4e00-\u9fff]{2,8})消耗量", sentence
        )
        if energy:
            bindings.append(
                {
                    "name": energy[1],
                    "action": None,
                    "actor": "本集团",
                    "verb": "消耗",
                    "header": "能源",
                }
            )
        purchase = re.search(
            r"本集团大部分的([\u4e00-\u9fff]{2,8})消耗须以[^。]+在国内购买", sentence
        )
        if purchase:
            add(purchase[1], ActivityAction.PURCHASES, "本集团", "购买")
        received = re.search(r"向本集团(?:出售|销售)([^。]+?)而向其支付", sentence)
        if received:
            name = re.split(r"所需的", received[1])[-1]
            if re.fullmatch(r"[\u4e00-\u9fff]{2,12}", name):
                add(name, ActivityAction.PURCHASES, "本集团", "采购")
        offered = re.search(
            r"本集团向[^。]+?(?:销售|出售)([\u4e00-\u9fff]{2,12}?)(?:取得的?收入|的收入|取得的?费用|，|。)",
            sentence,
        )
        if offered and not re.search(
            r"商品|服务|价格|收入|费用|代理|折扣|折让|返利|因素|资产|情况|业务的",
            offered[1],
        ):
            add(offered[1], ActivityAction.SELLS, "本集团", "销售")
        content_purchase = re.search(
            r"(?:^|[、，和])([^、，和]{2,12}产品)采购费是指[^。]+向本集团", sentence
        )
        if content_purchase:
            add(content_purchase[1], ActivityAction.PURCHASES, "本集团", "采购")

    # Ownership comes from the table section; counterparty names never identify
    # goods. The group direction is distinct from its ultimate parent's name.
    for match in re.finditer(
        r"(?:采购商品/接受劳务情况表|出售商品/提供劳务情况表)[\s\S]+?(?=购销商品、提供和接受劳务的关联交易说明|$)",
        excerpt,
    ):
        block = match.group()
        if not re.search(r"[√✓]适用\s*□不适用", block):
            continue
        for row in re.finditer(
            r"(?:^|\n|\s)(购买|购|售)([\u4e00-\u9fff]{1,12})\s+\d[\d,]*\.\d+", block
        ):
            verb, name = row[1], row[2]
            if name.endswith("服务"):
                continue
            add(
                name,
                ActivityAction.SELLS if verb == "售" else ActivityAction.PURCHASES,
                "公司",
                verb,
            )
    if "采购商品/接受劳务" in text and re.search(r"本集团关联方关联交易", text):
        for m in re.finditer(
            r"采购商品(?:及接受劳务)?(航空配餐|航材)(?:采购)?费[^。]*?\d", text
        ):
            add(m[1], ActivityAction.PURCHASES, "本集团", "采购")
        if "文创产品采购费" in text:
            add("文创产品", ActivityAction.PURCHASES, "本集团", "采购")
    if "出售商品/提供劳务" in text and re.search(r"本集团关联方关联交易", text):
        table = text.split("本公司除子公司外", 1)[0]
        for m in re.finditer(r"销售商品(航空配餐)(?:[（(][a-z]+[)）])?\d", table):
            add(m[1], ActivityAction.SELLS, "本集团", "销售")
    return bindings


def _native_equity_business_rows(excerpt: str) -> list[tuple[str, str, bool]]:
    """Read physical equity rows with their wrapped name and business columns."""
    rows = []
    for page in re.split(r"(?m)^.*年度报告[^\n]*$", excerpt):
        lines = page.splitlines()
        hi = next(
            (i for i, l in enumerate(lines) if "业务性质" in l and "注册地" in l), None
        )
        if hi is None:
            continue
        associate = "合营企业或联营" in page or "权益法核算" in page
        body = []
        for line in lines[hi + 1 :]:
            if re.search(
                r"在子公司的持股比例|持股比例不同于表决权|重要的?合营企业|[（(][23][)）]|^\s*.+?\s+指\s+",
                line,
            ):
                break
            if re.search(
                r"^\s*直接|^\s*名称|^\s*会计处理|^\s*\d+(?:\s*/\s*\d+)?\s*$", line
            ):
                continue
            body.append(line)
        pattern = (
            r"^(?P<name>.+?)\s{2,}(?P<geo>\S+)\s{2,}(?P<reg>\S+)\s{2,}(?P<business>.+?)\s{2,}(?P<ratio>\d{1,3}\.\d{2})\s+(?:\d|权益法)"
            if associate
            else r"^(?P<name>.+?)\s{2,}(?P<capital>(?:[A-Z]+)?-?\d[\d,]*\.\d+)\s*(?P<geo>\S+)\s{2,}(?P<reg>\S+)\s{2,}(?P<business>.+?)\s{2,}(?P<ratio>\d{1,3}\.\d{2})\s+\d"
        )
        anchors = [(i, m) for i, l in enumerate(body) if (m := re.match(pattern, l))]
        # The geographical/capital cells are vertically centred in each row.
        # Choose row boundaries using those centres, rather than assigning a
        # wrapped business line to whichever centre happens to be nearest.
        states = {0: (0.0, [])}
        for k, (anchor, m) in enumerate(anchors):
            limit = anchors[k + 1][0] if k + 1 < len(anchors) else len(body)
            next_states = {}
            for start, (score, bounds) in states.items():
                for stop in range(anchor + 1, limit + 1):
                    used = [j for j in range(start, stop) if body[j].strip()]
                    if not used:
                        continue
                    cost = score + ((used[0] + used[-1]) / 2 - anchor) ** 2
                    if any(not body[j].strip() for j in range(used[0], used[-1])):
                        cost += 1000
                    # A line break inside a printed word belongs to the same
                    # cell, even where vertical rounding makes centres tie.
                    left = re.sub(
                        r"\s+",
                        "",
                        body[used[-1]][m.start("business") : m.start("ratio")],
                    )
                    after = next(
                        (j for j in range(stop, len(body)) if body[j].strip()), None
                    )
                    right = (
                        re.sub(
                            r"\s+",
                            "",
                            body[after][m.start("business") : m.start("ratio")],
                        )
                        if after is not None
                        else ""
                    )
                    words = (
                        "计算机",
                        "机械设备",
                        "软件",
                        "开发",
                        "销售",
                        "设备",
                        "仪器",
                        "技术",
                        "系统",
                        "光源",
                        "灯具",
                        "灯泡",
                        "装饰",
                        "加工",
                        "产品",
                        "封装",
                        "发光二极管",
                        "制造",
                        "技术咨询",
                        "运营",
                        "管理",
                        "设计",
                        "贸易",
                        "租赁",
                        "仪表",
                        "陶瓷滤波器",
                    )
                    if (
                        left.endswith(("、", "及", "与", "和"))
                        or right.startswith(("、", "及", "与", "和"))
                        or any(
                            left.endswith(word[:j]) and right.startswith(word[j:])
                            for word in words
                            for j in range(1, len(word))
                        )
                    ):
                        cost += 100
                    if (
                        after is not None
                        and after < limit
                        and body[after][: m.start("geo")].strip()
                        and not right
                    ):
                        cost += 100
                    if stop not in next_states or cost < next_states[stop][0]:
                        next_states[stop] = (cost, [*bounds, (start, stop)])
            states = next_states
        if not anchors:
            continue
        _, boundaries = states[len(body)]
        for (anchor, m), (start, stop) in zip(anchors, boundaries):
            business_start = m.start("business")
            business_end = m.start("ratio")
            name_end = m.start("geo")
            actor = []
            business = []
            for line in body[start:stop]:
                raw_name = m["name"] if line == body[anchor] else line[:name_end]
                if (
                    not associate
                    and line != body[anchor]
                    and len(line) - len(line.lstrip()) >= m.start("capital")
                ):
                    raw_name = ""
                raw_name = re.split(
                    r"(?:^|\s)(?:[A-Z]+)?-?\d[\d,]*\.\d+", raw_name, maxsplit=1
                )[0]
                fragment = re.sub(r"\s+", "", raw_name)
                if fragment.startswith("&HKD"):
                    fragment = ""
                if fragment and not re.search(
                    r"持股|主要|经营地|注册地|子公司名称|会计处理", fragment
                ):
                    actor.append(fragment)
                business.append(re.sub(r"\s+", "", line[business_start:business_end]))
            name = "".join(actor)
            nature = "".join(business)
            if name and nature:
                rows.append((name, nature, associate))
    return rows


def _native_product_matrix_bindings(excerpt: str) -> list[dict[str, Any]]:
    """Bind native products to their explicitly grouped parent/subsidiary cell."""
    if "公司名称" in excerpt or not re.search(
        r"母子公司\s+产品名称\s+产品说明", excerpt
    ):
        return []
    lines = excerpt.splitlines()
    header = next(i for i, l in enumerate(lines) if "母子公司" in l and "产品名称" in l)
    rows = []
    scope = None
    description = r"保留|获得|用于|广泛|清凉|消炎|滋补|为数据|森林|产品包装|制作"
    for index in range(header + 1, len(lines)):
        line = lines[index].strip()
        if "主要经营模式" in line:
            break
        if re.search(r"母公司|子公司", line):
            scope = "issuer" if "母公司" in line else "consolidated_group"
            line = re.split(r"母公司|子公司", line, maxsplit=1)[1].strip()
        if not line or scope is None:
            continue
        m = re.match(
            r"(?P<name>[\u4e00-\u9fff、（）()]{1,20})\s+(?:" + description + ")", line
        )
        if m:
            name = m["name"]
        elif re.fullmatch(r"[\u4e00-\u9fff]{1,15}", line):
            following = "".join(l.strip() for l in lines[index + 1 : index + 3])
            if not re.match(
                r"(?:[（(][^）)]+[)）])?(?:" + description + ")", following
            ):
                continue
            name = line
        elif line.startswith(("（", "(")) and rows:
            rows[-1][0] += line
            continue
        else:
            continue
        rows.append([name, scope])
    bindings = []
    for name, scope in rows:
        for native_name in (
            name.split("、") if not re.search(r"[（(]", name) else [name]
        ):
            if not native_name:
                continue
            for action, verb in [
                (ActivityAction.PRODUCES, "生产"),
                (ActivityAction.SELLS, "销售"),
            ]:
                bindings.append(
                    {
                        "name": native_name,
                        "action": action,
                        "verb": verb,
                        "actor": "本公司" if scope == "issuer" else "公司及合并子公司",
                        "subject_scope": SubjectScope(scope),
                        "subject_basis": SubjectBasis.DIRECT_SOURCE_WORDING,
                        "header": "原母子公司产品矩阵/产销",
                        "qualifier": "母公司"
                        if scope == "issuer"
                        else "公司子公司产品",
                    }
                )
    return bindings


def _native_business_verb_objects(
    business: str,
) -> list[tuple[str, ActivityAction, str]]:
    """Bind explicit enumerated business verbs to their noun; never infer from a category."""
    business = (
        business.replace("安装服务与技术支持", "安装、技术支持")
        .replace("销售及安装服务", "销售及安装")
        .replace("及设备安装服务", "及安装")
        .replace("及维护服务", "及维护")
        .replace("、安调及维护服务", "、安调及维护")
        .replace("修理及相关“四技”服务", "修理")
        .replace("自产产品，并提供售后及相关技术服务", "")
    )
    business = re.sub(r"研发及销售", "销售", business)
    business = re.sub(r"^精毛纺织制品，", "精毛纺织制品、", business)
    business = business.replace("合同能源管理、城市热网节能方案", "城市热网节能方案")
    actions = {
        "生产": ActivityAction.PRODUCES,
        "制造": ActivityAction.PRODUCES,
        "组装": ActivityAction.PRODUCES,
        "加工": ActivityAction.PROCESSES,
        "销售": ActivityAction.SELLS,
        "零售": ActivityAction.SELLS,
        "经销": ActivityAction.SELLS,
        "分销": ActivityAction.SELLS,
        "转售": ActivityAction.SELLS,
        "种植": ActivityAction.PRODUCES,
        "安装": ActivityAction.PROVIDES_SERVICE,
        "维护": ActivityAction.PROVIDES_SERVICE,
        "修理": ActivityAction.PROVIDES_SERVICE,
        "租赁": ActivityAction.PROVIDES_SERVICE,
        "技术支持": ActivityAction.PROVIDES_SERVICE,
        "安调": ActivityAction.PROVIDES_SERVICE,
        "开发": ActivityAction.DEVELOPS,
    }
    verb = "|".join(sorted(actions, key=len, reverse=True))
    # Research/design in a shared verb list is kept as a boundary, not promoted to production.
    allverbs = verb + "|研发|设计|研究"
    result = []
    for cell in re.split(r"[；;。]", business):
        cell = cell.strip("，,、")
        if not cell or re.search(r"拟|计划|未开展|尚未|不销售|不生产", cell):
            continue
        # Embedded explicit verb/object clauses are separated by a Chinese comma.
        for clause in re.split(r"[，,](?!高档)|(?<=生产)及(?=装饰)", cell):
            clause = re.sub(r"的中日合资企业$|等$", "", clause)
            clause = (
                clause.replace("加工销售", "加工、销售")
                .replace("的种植", "种植")
                .removeprefix("进出口")
            )
            prefix = re.match(
                r"(?P<verbs>(?:"
                + allverbs
                + r")(?:(?:、|及|与|和)(?:"
                + allverbs
                + r"))*)的?(?P<name>.+)",
                clause,
            )
            suffix = re.match(
                r"(?P<name>.+?)(?:的)?(?P<verbs>(?:"
                + allverbs
                + r")(?:(?:、|及|与|和)(?:"
                + allverbs
                + r"))*)(?:自产产品|产品)?$",
                clause,
            )
            match = prefix or suffix
            if not match:
                continue
            name = match["name"].strip("的、，,：:")
            if (
                not name
                or name in {"产品", "自产产品"}
                or re.search(allverbs + "|建设|实施", name)
                or re.match(r"技术转让|技术咨询", name)
            ):
                continue
            # A compound list remains one source object unless its own repeated
            # production clause explicitly enumerates separately marketed products.
            names = list(dict.fromkeys([name, *re.split(r"、|及(?=LED)", name)]))
            if (
                name.startswith(("季节性、", "金属、非金属制品", "制冷、空调设备"))
                or "中、高档" in name
            ):
                names = [name]
            if name == "精毛纺织制品、服装及辅料":
                names = ["精毛纺织制品", "服装", "辅料"]
            for n in names:
                n = n.strip("及等")
                if n:
                    for v in re.findall(allverbs, match["verbs"]):
                        if v in actions:
                            result.append((n, actions[v], v))
    return list(dict.fromkeys(result))


def _native_branch_action_bindings(excerpt: str) -> list[dict[str, Any]]:
    """Current actions stay with the native subsidiary or marketed product list."""
    # Remove printed page furniture before joining a word across a page break.
    native_text = re.sub(
        r"(?m)^.*年度报告[^\n]*$|^\s*\d+(?:\s*/\s*\d+)?\s*$", "", excerpt
    )
    text = re.sub(r"\s+", "", native_text)
    bindings = _native_product_matrix_bindings(excerpt)

    def add(name, action, actor, verb, header=None):
        bindings.append(
            {
                "name": name,
                "action": action,
                "actor": actor,
                "verb": verb,
                "header": header,
                "subject_basis": SubjectBasis.DIRECT_SOURCE_WORDING,
                "qualifier": "原文开发，不推已销售"
                if action == ActivityAction.DEVELOPS
                else header
                if action == ActivityAction.OPERATES
                else None,
            }
        )

    if re.search(r"公司主要从事[^。]+产销及贸易经营", text):
        m = re.search(r"主要产品为([^。]+?)等产品[，,]", text)
        if m:
            cell = re.sub(r'[“"]([^”"]+)[”"]系列', "", m[1])
            for name in cell.split("、"):
                for action, verb in [
                    (ActivityAction.PRODUCES, "产销/生产"),
                    (ActivityAction.SELLS, "产销/销售"),
                ]:
                    add(name, action, "公司及合并子公司", verb, "本期主要产品/产销")
    for m in re.finditer(
        r"([\u4e00-\u9fff]{2,20})主要(?:从事)?(生产和销售|生产及销售|制造及分销)([^。]+?)。",
        text,
    ):
        actor = m[1]
        names = re.sub(r"等系列产品$|等$", "", m[3])
        for n in re.split(r"、|及(?=舞台)", names):
            for action, v in [
                (ActivityAction.PRODUCES, "生产/制造"),
                (ActivityAction.SELLS, "销售/分销"),
            ]:
                add(n, action, actor, v, "具名主体产品矩阵")
    for m in re.finditer(
        r"([\u4e00-\u9fff]{2,20})主要从事([^。]+?)的开发、制造和销售", text
    ):
        for n in m[2].split("、"):
            for action, v in [
                (ActivityAction.PRODUCES, "制造"),
                (ActivityAction.SELLS, "销售"),
            ]:
                add(n, action, m[1], v, "具名主体产品矩阵")
    if "知识服务" in text and "盈利模式以机构订阅为主" in text:
        for m in re.finditer(r"核心产品包括([^。]+?)等。", text):
            for n in re.split(r"、|及", m[1]):
                add(
                    n.removeprefix("定制化的"),
                    ActivityAction.PROVIDES_SERVICE,
                    "公司及合并子公司",
                    "提供",
                    "原数智服务产品",
                )
        m = re.search(r"提供(学术资源检索[^。]+?)等服务", text)
        if m:
            for n in re.split(r"、|及", m[1]):
                add(
                    n,
                    ActivityAction.PROVIDES_SERVICE,
                    "公司及合并子公司",
                    "提供",
                    "原知识服务",
                )
        m = re.search(r"提供基于[^。]+?的(智能检查系统[^。]+?)。", text)
        if m:
            for n in re.split(r"、|及", m[1]):
                add(
                    n,
                    ActivityAction.PROVIDES_SERVICE,
                    "公司及合并子公司",
                    "提供",
                    "原公共安全服务",
                )
    m = re.search(
        r"开发(热泵装备[^。]+?)，通过([^。]+?)等方式，为用户提供[^。]+?(一体化解决方案与运维服务)",
        text,
    )
    if m:
        for n in re.split(r"、|和", m[1]):
            for name in (
                ["储" + t + "系统" for t in re.search(r"储(.+?)系统", n)[1].split("/")]
                if re.fullmatch(r"多种储.+?系统", n)
                else [n]
            ):
                add(
                    name,
                    ActivityAction.DEVELOPS,
                    "公司及合并子公司",
                    "开发",
                    "原能源技术开发",
                )
        for n in m[2].split("、"):
            add(
                n,
                ActivityAction.PROVIDES_SERVICE,
                "公司及合并子公司",
                "通过",
                "原能源服务方式",
            )
        add(
            m[3],
            ActivityAction.PROVIDES_SERVICE,
            "公司及合并子公司",
            "提供",
            "原能源服务",
        )
    m = re.search(r"提供涵盖([^。]+?)等全场景产品", text)
    if m:
        for n in re.split(r"、|及", m[1]):
            add(
                n,
                ActivityAction.PROVIDES_SERVICE,
                "公司及合并子公司",
                "提供",
                "本期场景产品交付",
            )
    m = re.search(r"提供([^。]+?)的全面加固与智慧升级", text)
    if m:
        add(
            m[1],
            ActivityAction.PROVIDES_SERVICE,
            "公司及合并子公司",
            "升级",
            "本期智慧升级",
        )
    if re.search(r"智能研学工具网络平台服务\d", text):
        add(
            "智能研学工具网络平台",
            ActivityAction.PROVIDES_SERVICE,
            "公司及合并子公司",
            "服务",
            "当前网络服务",
        )
    if re.search(r"数据产品挂牌", text):
        add(
            "数据产品",
            ActivityAction.OPERATES,
            "公司及合并子公司",
            "挂牌",
            "实际挂牌，不是签约订单",
        )
    if re.search(r"大温差机组全部投运", text):
        add(
            "大温差机组",
            ActivityAction.OPERATES,
            "公司及合并子公司",
            "投运",
            "本期全部投运",
        )
    if re.search(r"大体量大温差机组[^。]+成功应用", text):
        add(
            "大体量大温差机组",
            ActivityAction.OPERATES,
            "公司及合并子公司",
            "应用",
            "本期成功应用",
        )
    quantity = re.search(r"产销量情况分析表([\s\S]+?)(?:产销量情况说明|$)", native_text)
    if quantity and re.search(r"[√✓]\s*适用\s*□\s*不适用", quantity[1]):
        block = quantity[1]
        header = re.search(r"(?m)^.*产品\s+位\s+生产量\s+销售量.*$", block)
        if header:
            label_end = header[0].find("位") - 1
            cells = []
            current = None
            before = ""
            for line in block[header.end() :].splitlines():
                if re.search(r"年度报告|上年|增减|^\s*[（(]?%|^\s*\d+\s*/", line):
                    continue
                if re.match(r"\s*合计", line):
                    break
                amounts = list(re.finditer(r"\d[\d,]*\.\d{2}", line))
                label = re.sub(r"\s+", "", line[:label_end])
                if not re.fullmatch(r"[\u4e00-\u9fff]+", label):
                    label = ""
                if len(amounts) >= 3:
                    if current:
                        cells.append(current)
                    current = [before + label, amounts[0].group(), amounts[1].group()]
                    before = ""
                elif label:
                    if "件/" in line:
                        if current:
                            cells.append(current)
                        current = None
                        before = label
                    elif current:
                        current[0] += label
                    else:
                        before += label
            if current:
                cells.append(current)
            for name, produced, sold in cells:
                if not name:
                    continue
                for value, action, verb in [
                    (produced, ActivityAction.PRODUCES, "生产"),
                    (sold, ActivityAction.SELLS, "销售"),
                ]:
                    if Decimal(value.replace(",", "")) > 0:
                        add(
                            name,
                            action,
                            "公司及合并子公司",
                            verb,
                            "原产销量正值/" + verb,
                        )
    # Named operating-company narratives supply their own full aliases elsewhere.
    for m in re.finditer(r"([\u4e00-\u9fff]{2,20})主要从事([^。]+)[。]", text):
        actor = m[1]
        if actor.startswith(("公司", "本公司", "集团")):
            continue
        if re.match(r"制造及分销", m[2]):
            continue
        for name, action, verb in _native_business_verb_objects(m[2]):
            add(name, action, actor, verb, "具名公司主要业务")
    for m in re.finditer(
        r"([\u4e00-\u9fff]{2,40}有限公司)[(（]以下简称[“\"]([^”\"]+)[”\"][)）][^。]+。主要从事([^。]+)。",
        text,
    ):
        actor = m[2]
        associated = any(
            name == actor and associate
            for name, _, associate in _native_equity_business_rows(excerpt)
        )
        for n in re.split(r"和(?=股权投资)", m[3]):
            add(n, ActivityAction.OPERATES, actor, "从事", "原具名投资经营")
            if associated:
                bindings[-1].update(
                    subject_scope=SubjectScope.BUSINESS_SEGMENT,
                    qualifier="原参股主体，不并表；原主体：" + actor,
                )
    # Apparel parent paragraph explicitly binds the complete product matrix to
    # its current full-chain production and terminal-sales business.
    if "公司在国内开展服装全链条业务" in text and "涵盖生产加工与终端销售" in text:
        male = re.search(r"男装品类齐全，包含([^。]+?)等，", text)
        female = re.search(r"女装则分为([^。]+?)四大系列", text)
        for m in (male, female):
            if m:
                for name in re.split(r"、|及", m[1]):
                    for action, v in [
                        (ActivityAction.PRODUCES, "生产加工"),
                        (ActivityAction.SELLS, "终端销售"),
                    ]:
                        add(name, action, "公司及合并子公司", v, "原服装全链条产品矩阵")
        trade = re.search(r"外贸加工业务主要采用([^。]+?)三种运营模式", text)
        if trade:
            for n in re.split(r"、|和", trade[1]):
                add(
                    "外贸" + n,
                    ActivityAction.OPERATES,
                    "公司及合并子公司",
                    "经营",
                    "原外贸运营模式",
                )
        if "团购定制主要承接" in text:
            add(
                "团购定制",
                ActivityAction.OPERATES,
                "公司及合并子公司",
                "承接",
                "原经营模式",
            )
    # Segment descriptions have explicit scopes distinct from group turnover.
    for m in re.finditer(r"([^。：]{2,20}报告分部)：([^。]+)。", text):
        actor = m[1].lstrip("①②③")
        body = m[2].removeprefix("组织")
        body = body.replace("生产销售", "生产、销售")
        for clause in body.split("，"):
            if clause.startswith("提供"):
                add(
                    clause.removeprefix("提供"),
                    ActivityAction.PROVIDES_SERVICE,
                    actor,
                    "提供",
                    "报告分部原经营",
                )
                bindings[-1]["subject_scope"] = SubjectScope.BUSINESS_SEGMENT
            else:
                for name, action, verb in _native_business_verb_objects(clause):
                    for n in re.split(r"及|、", name):
                        add(n, action, actor, verb, "报告分部原经营")
                        bindings[-1]["subject_scope"] = SubjectScope.BUSINESS_SEGMENT
    note = re.search(
        r"注\d+：([^。]+?)成立于\d{4}年，是一家从事([^。]+?)的高新技术企业", text
    )
    if note and re.search(
        r"截至报告日[^。]+" + re.escape(note[1]) + r"[^。]+参股项目[^。]+未纳入合并",
        text,
    ):
        actor = note[1]
        association = "报告披露日参股企业业务，未纳入合并，不视为集团本期经营"
        add(note[2], ActivityAction.PROVIDES_SERVICE, actor, "从事", "参股企业原业务")
        if "提供SaaS服务" in text:
            add(
                "SaaS服务",
                ActivityAction.PROVIDES_SERVICE,
                actor,
                "提供",
                "参股企业原业务",
            )
        chips = re.search(r"自主研发([^。]+?)芯片", text)
        if chips:
            for name in chips[1].split("与"):
                add(
                    name + "芯片",
                    ActivityAction.DEVELOPS,
                    actor,
                    "自主研发",
                    "参股企业原研发",
                )
        for binding in bindings:
            if binding.get("actor") == actor:
                binding.update(
                    subject_scope=SubjectScope.BUSINESS_SEGMENT, qualifier=association
                )
    for m in re.finditer(
        r"([^。：；，]+?)深化自有品牌[^。]+加强([^。]+?)等优势产品研发生产", text
    ):
        actor = m[1].split("电子通讯产业")[-1]
        for name in m[2].split("、"):
            add(name, ActivityAction.PRODUCES, actor, "研发生产", "本期具名子公司产品")
    for m in re.finditer(
        r"报告期，([^。]+?)的营业收入[^。]+(?:光模块产品销售同比增加)", text
    ):
        add("光模块", ActivityAction.SELLS, m[1], "产品销售", "本期具名子公司销售")
    if "国内木竹片采购定价主要采取挂牌采购" in text:
        for name in ("木片", "竹片"):
            add(name, ActivityAction.PURCHASES, "本公司", "挂牌采购", "母公司原料采购")
            bindings[-1]["subject_scope"] = SubjectScope.ISSUER
    m = re.search(r"大宗([^。]+?)等主要采用公开招标", text)
    if m:
        for name in m[1].split("、"):
            add(
                "大宗" + name if name == "原材料" else name,
                ActivityAction.PURCHASES,
                "公司及合并子公司",
                "公开招标采购",
            )
    m = re.search(
        r"本公司主营业务包含开展([^。]+?)等，通过下属全资子公司([^。]+?)开展上述业务",
        text,
    )
    if m:
        for name in m[1].split("、"):
            add(
                name.removeprefix("提供").removesuffix("业务"),
                ActivityAction.PROVIDES_SERVICE,
                m[2],
                "开展",
                "日常经营投资；非营业收入",
            )
    m = re.search(
        r"公司控股子公司([^。]+?)基于算力业务[^。]+?采购先进计算技术服务，包括但不限于([^。]+?)，",
        text,
    )
    if m:
        for name in ["算力服务", "存储服务"]:
            if name.removesuffix("服务") in m[2]:
                add(name, ActivityAction.PURCHASES, m[1], "采购", "先进计算技术服务")
    if "本公司向客户销售房地产" in text:
        add("房地产", ActivityAction.SELLS, "公司及合并子公司", "销售")
    for m in re.finditer(r"本公司向客户提供([^。]+?)，该服务", text):
        for name in m[1].split("、"):
            add(
                "物业服务" if name == "物业管理服务" else name,
                ActivityAction.PROVIDES_SERVICE,
                "公司及合并子公司",
                "提供",
            )
    for row in _real_estate_settlement_rows(excerpt):
        if (
            row[3] == "房地产销售和结转/结转收入金额"
            and Decimal(row[2].replace(",", "")) > 0
        ):
            add(row[1], ActivityAction.SELLS, "公司及合并子公司", "本期结转", row[3])
            associated = re.search(r"不含联营([^、，）)]+?)项目", text)
            if associated and associated[1] in row[1]:
                bindings[-1].update(
                    actor=associated[1] + "联营项目",
                    subject_scope=SubjectScope.BUSINESS_SEGMENT,
                    qualifier="联营项目，不含在集团结转合计内",
                )
    if "经营业态" in excerpt and "出租房地产的租" in text:
        for row in _real_estate_settlement_rows(excerpt):
            if row[3] != "房地产出租/租金收入":
                continue
            add(
                row[1],
                ActivityAction.PROVIDES_SERVICE,
                "公司及合并子公司",
                "出租",
                "房地产出租/经营业态",
            )
            bindings[-1]["qualifier"] = row[5]

    def current(clause):
        return not re.search(
            r"第三方|拟|计划|不销售|未销售|不采购|未采购|尚未|未开展|未常态化|不常态化|将销售",
            clause,
        )

    def business_actions(actor, business, header):
        if not current(business):
            return
        for name, action, verb in _native_business_verb_objects(business):
            add(name, action, actor, verb, header)
        if business.startswith("房地产开发"):
            add("房地产开发", ActivityAction.OPERATES, actor, "开发", header)
        if business.startswith("商品销售业务"):
            add("商品销售业务", ActivityAction.SELLS, actor, "销售", header)
        if business.startswith("物业服务"):
            add("物业服务", ActivityAction.PROVIDES_SERVICE, actor, "服务", header)
        if business.startswith("远洋捕捞"):
            add("远洋捕捞", ActivityAction.OPERATES, actor, "捕捞", header)
            if "食品加工" in business:
                add("食品加工业", ActivityAction.OPERATES, actor, "食品加工", header)
        if business.startswith("交易鱼类和鱼产品"):
            for name in ("鱼类", "鱼产品"):
                add(name, ActivityAction.SELLS, actor, "交易", header)
        if business.startswith("水产品加工及销售"):
            add("水产品", ActivityAction.PROCESSES, actor, "加工", header)
            add("水产品", ActivityAction.SELLS, actor, "销售", header)
        if business.startswith("罐头食品加工"):
            add("罐头食品", ActivityAction.PROCESSES, actor, "加工", header)
        if business.startswith("海上运输"):
            add("海上运输", ActivityAction.PROVIDES_SERVICE, actor, "运输", header)
        if business.startswith("收购、加工销售鱼产品"):
            for action, verb in (
                (ActivityAction.PURCHASES, "收购"),
                (ActivityAction.PROCESSES, "加工"),
                (ActivityAction.SELLS, "销售"),
            ):
                add("鱼产品", action, actor, verb, header)
        if business.startswith("渔货贸易"):
            add("渔货", ActivityAction.SELLS, actor, "贸易", header)

    for actor, business, associate in _native_equity_business_rows(excerpt):
        for name, action, verb in _native_business_verb_objects(business):
            add(
                name,
                action,
                actor,
                verb,
                "原权益法主体业务性质" if associate else "原子公司业务性质",
            )
            if associate:
                bindings[-1].update(
                    subject_scope=SubjectScope.BUSINESS_SEGMENT,
                    qualifier="合营/联营权益法主体，不并表；原主体：" + actor,
                )
        if not associate:
            business_actions(actor, business, "原子公司业务性质")
        for m in re.finditer(r"(药品|外用溶液剂)生产销售", business):
            for action, verb in [
                (ActivityAction.PRODUCES, "生产"),
                (ActivityAction.SELLS, "销售"),
            ]:
                add(m[1], action, actor, verb, "原子公司业务性质")
        if "技术服务、开发、转让" in business:
            add(
                "技术服务",
                ActivityAction.PROVIDES_SERVICE,
                actor,
                "技术服务",
                "原子公司业务性质",
            )
        if associate and "生产显示器及LCD电视机" in business:
            for name in ["显示器", "LCD电视机"]:
                add(
                    name, ActivityAction.PRODUCES, actor, "生产", "原权益法主体业务性质"
                )
                bindings[-1]["subject_scope"] = SubjectScope.BUSINESS_SEGMENT
        if associate and "基金募集、基金销售、特定客户资产管理" in business:
            for name in ["基金募集", "基金销售", "特定客户资产管理"]:
                add(
                    name,
                    ActivityAction.PROVIDES_SERVICE,
                    actor,
                    "原业务服务",
                    "原权益法主体业务性质",
                )
                bindings[-1]["subject_scope"] = SubjectScope.BUSINESS_SEGMENT

    # Enumerated native verbs share their noun. Business labels, raw-material
    # explanations and research clauses are not products with those verb names.
    for actor, kind, business, _ in _native_company_columns(excerpt) or []:
        if kind == "子公司":
            business_actions(actor, business, "控股参股公司原业务")
        if not current(business):
            continue
        if kind == "子公司" and "母子公司" in excerpt and "产销及贸易经营" in text:
            matrix = re.split(
                r"\d+、公司的主要经营模式", excerpt.split("母子公司", 1)[1], maxsplit=1
            )[0]
            for name in re.split(r"、|和", business):
                if (
                    name
                    and (
                        name
                        in {
                            b["name"]
                            for b in _native_product_matrix_bindings(
                                "公司及子公司主要产品及用途如下：\n"
                                + "母子公司"
                                + matrix
                            )
                        }
                        or "药业" in actor
                        and "医药行业" in matrix
                    )
                    and not re.search(r"原料|贸易|研发|服务|维修|制造", name)
                ):
                    add(
                        name,
                        ActivityAction.PRODUCES,
                        actor,
                        "本期产销/生产",
                        "原产品矩阵与子公司业务",
                    )
        if kind == "子公司":
            if "机械维修、制造" in business:
                add(
                    "机械维修",
                    ActivityAction.PROVIDES_SERVICE,
                    actor,
                    "维修",
                    "原子公司业务",
                )
                add("机械", ActivityAction.PRODUCES, actor, "制造", "原子公司业务")
            if "污水处理服务" in business:
                add(
                    "污水处理服务",
                    ActivityAction.PROVIDES_SERVICE,
                    actor,
                    "污水处理",
                    "原子公司业务",
                )
            if "森林培育" in business:
                add(
                    "森林培育",
                    ActivityAction.PROVIDES_SERVICE,
                    actor,
                    "培育",
                    "原子公司业务",
                )
            timber = re.search(r"(木竹|竹材)采运", business)
            if timber:
                add(timber[1], ActivityAction.PRODUCES, actor, "采运", "原子公司业务")
                bindings[-1]["qualifier"] = (
                    "原主体：" + actor + "；原文采运，不反推本期销售"
                )
        rules = (
            (
                r"^(.+?)采选、销售",
                [(ActivityAction.PROCESSES, "采选"), (ActivityAction.SELLS, "销售")],
            ),
            (
                r"^生产、销售([^，；]+)",
                [(ActivityAction.PRODUCES, "生产"), (ActivityAction.SELLS, "销售")],
            ),
            (
                r"^生产、经营([^，；]+)",
                [(ActivityAction.PRODUCES, "生产"), (ActivityAction.OPERATES, "经营")],
            ),
            (
                r"^(.+?)生产销售",
                [(ActivityAction.PRODUCES, "生产"), (ActivityAction.SELLS, "销售")],
            ),
        )
        for pattern, actions in rules:
            m = re.search(pattern, business)
            if not m:
                continue
            for name in re.split(
                r"、|和|及", re.sub(r"等(?:产品)?$", "", m[1]).removesuffix("的")
            ):
                for action, verb in actions:
                    add(name, action, actor, verb, "控股参股公司原业务")
                    if kind == "参股公司":
                        bindings[-1]["subject_scope"] = SubjectScope.BUSINESS_SEGMENT

    # Current park services and fishing operations are stated independently
    # from general industry descriptions and future development plans.
    if "工业园区运营" in text and "核心主业" in text and "产业投资方面，公司" in text:
        add("工业园区", ActivityAction.OPERATES, "公司及合并子公司", "运营")
        add("产业投资", ActivityAction.OPERATES, "公司及合并子公司", "产业投资")
    m = re.search(r"旗下([^。]+?孵化器)为在孵企业提供([^。]+?)等专业化服务", text)
    if m and current(
        text[
            max(text.rfind("。", 0, m.start()), text.rfind("；", 0, m.start()))
            + 1 : m.end()
        ]
    ):
        for name in m[2].split("、"):
            add(name, ActivityAction.PROVIDES_SERVICE, m[1], "提供服务")
            bindings[-1]["subject_scope"] = SubjectScope.NAMED_SUBSIDIARY
    m = re.search(r"常态化开展([^。]+?)等服务", text)
    if m and current(
        text[
            max(text.rfind("。", 0, m.start()), text.rfind("；", 0, m.start()))
            + 1 : m.end()
        ]
    ):
        for name in m[1].split("、"):
            add(name, ActivityAction.PROVIDES_SERVICE, "公司及合并子公司", "开展服务")
    m = re.search(r"为在孵企业提供政策咨询服务[^。]+提升([^。]+?)服务水平", text)
    if m and current(
        text[
            max(text.rfind("。", 0, m.start()), text.rfind("；", 0, m.start()))
            + 1 : m.end()
        ]
    ):
        actor = re.sub(r"国家级", "", m[1])
        add("政策咨询", ActivityAction.PROVIDES_SERVICE, actor, "提供政策咨询")
        bindings[-1]["subject_scope"] = SubjectScope.NAMED_SUBSIDIARY
    if "房产销售成交量增长，房产销售收入增加" in text:
        add("房产", ActivityAction.SELLS, "公司及合并子公司", "房产销售")
    if (
        "公司房产租赁规模有所增加" in text
        or "房产租赁收入增加" in text
        or "房产租赁收入有所增加" in text
        or "公司房产租赁业务增加" in text
    ):
        add("房产租赁", ActivityAction.PROVIDES_SERVICE, "公司及合并子公司", "租赁")
    m = re.search(r"公司金枪鱼围网船队[^。]+开展生产作业，产品以([^，。]+?)为主", text)
    if m and current(
        text[
            max(text.rfind("。", 0, m.start()), text.rfind("；", 0, m.start()))
            + 1 : m.end()
        ]
    ):
        for name in ["金枪鱼", *m[1].split("、")]:
            add(name, ActivityAction.PRODUCES, "公司及合并子公司", "捕捞生产")
    m = re.search(r"与([^；。]+?有限公司)开展合作经营，在[^；。]+捕捞(磷虾)", text)
    if m and current(
        text[
            max(text.rfind("。", 0, m.start()), text.rfind("；", 0, m.start()))
            + 1 : m.end()
        ]
    ):
        add(
            m[2],
            ActivityAction.PRODUCES,
            "公司及合并子公司",
            "合作捕捞",
            "合作经营：" + m[1],
        )
    m = re.search(r"西班牙([^。]+?公司)加工产品主要以([^。]+?)为主", text)
    if m and current(
        text[
            max(text.rfind("。", 0, m.start()), text.rfind("；", 0, m.start()))
            + 1 : m.end()
        ]
    ):
        for name in m[2].split("和"):
            add(name, ActivityAction.PROCESSES, m[1], "加工")
    m = re.search(
        r"公司国内([^。]+?加工厂)加工([^，。]+)，产品以([^，。]+?)为主，主要销往国外市场",
        text,
    )
    if m and current(
        text[
            max(text.rfind("。", 0, m.start()), text.rfind("；", 0, m.start()))
            + 1 : m.end()
        ]
    ):
        add(m[2], None, m[1], "加工投入", "实际加工原料")
        add(m[3], ActivityAction.PROCESSES, m[1], "加工")
        add(m[3], ActivityAction.SELLS, m[1], "销往国外")
    m = re.search(r"冷藏运输船队[^。]+承担了([^。]+?)，并积极拓展", text)
    if m and current(
        text[
            max(text.rfind("。", 0, m.start()), text.rfind("；", 0, m.start()))
            + 1 : m.end()
        ]
    ):
        for name in m[1].split("、"):
            add(
                name,
                ActivityAction.PROVIDES_SERVICE,
                "公司及合并子公司",
                "承担运输转运",
            )
    m = re.search(
        r"(ALBO公司)围绕品牌升级[^。]+。[\s\S]+?沙丁鱼、鱿鱼等罐头产品保持[^；。]+；黄鳍金枪鱼[^。]+；国际市场销售额",
        text,
    )
    if m and current(
        text[
            max(text.rfind("。", 0, m.start()), text.rfind("；", 0, m.start()))
            + 1 : m.end()
        ]
    ):
        for name in ("沙丁鱼", "鱿鱼", "黄鳍金枪鱼"):
            add(name, ActivityAction.SELLS, m[1], "罐头销售", "已实现市场销售")
    m = re.search(
        r"(Estelas)贸易公司[^。]+。[\s\S]+?推动([^。]+?)等原料产品的跨境流通", text
    )
    if m and current(
        text[
            max(text.rfind("。", 0, m.start()), text.rfind("；", 0, m.start()))
            + 1 : m.end()
        ]
    ):
        for name in m[2].split("、"):
            add(name, ActivityAction.SELLS, "ESTELAS公司", "跨境流通")
    if "本公司根据合同协议完成销售磷虾及磷虾粉" in text:
        for name in ("磷虾", "磷虾粉"):
            add(name, ActivityAction.SELLS, "公司及合并子公司", "完成销售")
    m = re.search(r"加工(磷虾粉)\d[\d,.]*吨（捕捞磷虾", text)
    if m:
        add(m[1], ActivityAction.PRODUCES, "公司及合并子公司", "加工生产", "本期产量")

    for m in re.finditer(r"公司生产销售([^。]+?)等产品。", text):
        if current(m.group()):
            for name in m[1].split("、"):
                for action, verb in [
                    (ActivityAction.PRODUCES, "生产"),
                    (ActivityAction.SELLS, "销售"),
                ]:
                    add(name, action, "公司及合并子公司", verb)
    if "公司开采自有磷矿资源" in text:
        add("磷矿石", ActivityAction.PRODUCES, "公司及合并子公司", "开采生产")
        if "对外采购部分磷矿石" in text:
            add("磷矿石", ActivityAction.PURCHASES, "公司及合并子公司", "采购")
    for m in re.finditer(r"以自产的([^。]+?)和外购的([^。]+?)为主要原料", text):
        for name in m[2].split("、"):
            add(name, ActivityAction.PURCHASES, "公司及合并子公司", "外购")
    for m in re.finditer(r"公司生产([^。]+?)产品，生产基地", text):
        for name in re.split(r"、|和", m[1]):
            add(name, ActivityAction.PRODUCES, "公司及合并子公司", "生产")
    if "公司水富基地采购煤作为原料生产甲醇" in text:
        add("煤", ActivityAction.PURCHASES, "公司及合并子公司", "采购")
        if "部分直接对外销售" in text:
            add("甲醇", ActivityAction.SELLS, "公司及合并子公司", "部分对外销售")
    if "原料甲醇对外采购" in text:
        add("甲醇", ActivityAction.PURCHASES, "公司及合并子公司", "对外采购")
    m = re.search(
        r"([^。]+?)产品主要通过子公司直销、各级经销商进行分销、出口的模式实现销售", text
    )
    if m:
        for name in m[1].split("、"):
            add(name, ActivityAction.SELLS, "公司及合并子公司", "直销分销出口")
    if "公司子公司化肥贸易采取大宗采购，分批销售模式" in text:
        for action, verb in [
            (ActivityAction.PURCHASES, "大宗采购"),
            (ActivityAction.SELLS, "分批销售"),
        ]:
            add("化肥", action, "公司及合并子公司", verb)
    if "公司子公司开展大豆国际贸易" in text and "并向国内压榨企业销售" in text:
        for action, verb in [
            (ActivityAction.PURCHASES, "来源南美"),
            (ActivityAction.SELLS, "向国内压榨企业销售"),
        ]:
            add(
                "大豆", action, "公司及合并子公司", verb, "本期贸易/2025年9月后已不开展"
            )
    if "全程物流运营体系" in text and "公司物流业务以公司内部原料和产品" in text:
        for name in ("运输", "仓储", "工厂发运", "港口中转", "区域销售配送"):
            if name in text:
                add(
                    name,
                    ActivityAction.PROVIDES_SERVICE,
                    "公司及合并子公司",
                    "物流服务",
                )
    if "公司房地产业务" in text and "业务范围涵盖" in text:
        m = re.search(r"业务范围涵盖([^。]+?)等", text)
        if m:
            for name in m[1].split("、"):
                add(
                    name,
                    ActivityAction.PROVIDES_SERVICE,
                    "公司及合并子公司",
                    "业务范围",
                )
    if "市政业务是公司传统主营" in text:
        m = re.search(r"主要从事([^。]+?)等业务", text)
        if m:
            for name in re.split(r"、|，|以及|及", m[1]):
                name = "园区管理" if name == "监理，园区管理" else name
                if name not in {"服务"}:
                    add(
                        name,
                        ActivityAction.PROVIDES_SERVICE,
                        "公司及合并子公司",
                        "主要从事",
                    )
    if "污水处理业务认真做好园区水处理工作" in text:
        add(
            "污水处理",
            ActivityAction.PROVIDES_SERVICE,
            "公司及合并子公司",
            "园区水处理",
        )
    # Positive production and sales quantities carry separate directions.
    if "产销量情况分析表" in text and "生产量销售量" in text:
        table = re.split(
            r"产销量情况说明|[（(]3[)）]",
            excerpt.split("产销量情况分析表", 1)[1],
            maxsplit=1,
        )[0]
        table = re.sub(r"(\.\d{2})(?=\d)", r"\1 ", table)
        for m in re.finditer(
            r"(?m)^\s*([^\s]+(?:[ \t]+[\u4e00-\u9fffA-Za-z]+)*?)\s+(?:万吨|吨|万罐|万只|万瓶)\s+(\d[\d,]*\.\d+)\s+(\d[\d,]*\.\d+)",
            table,
        ):
            if m[1] in {"合计", "小计"}:
                continue
            for value, action, verb in [
                (m[2], ActivityAction.PRODUCES, "生产量"),
                (m[3], ActivityAction.SELLS, "销售量"),
            ]:
                if Decimal(value.replace(",", "")) > 0:
                    name = re.sub(r"\s+", "", m[1])
                    name = name + "产品" if name.endswith("系列") else name
                    add(name, action, "公司及合并子公司", verb, "产销量/本期")

    # Native service enumerations bind the current operation to each object;
    # project/trial language elsewhere remains narrative evidence only.
    for pattern, action, verb in (
        (r"公司经营([^。]+?)，主要提供旅游观光", ActivityAction.OPERATES, "经营"),
        (
            r"公司拥有([^。]+?)，主要提供客运观光服务",
            ActivityAction.OPERATES,
            "拥有并运营",
        ),
        (r"主要提供(住宿餐饮)等旅宿服务", ActivityAction.PROVIDES_SERVICE, "提供"),
        (r"主要提供(徽菜餐饮)等服务", ActivityAction.PROVIDES_SERVICE, "提供"),
    ):
        for match in re.finditer(pattern, text):
            if current(match.group()):
                names = (
                    ["住宿", "餐饮"]
                    if match[1] == "住宿餐饮"
                    else re.split(r"、|和|及", match[1])
                )
                for name in names:
                    add(name, action, "公司及合并子公司", verb)
    if re.search(r"主要业务涵盖[^。]+旅游产品和活动策划", text):
        add(
            "旅游产品和活动策划",
            ActivityAction.PROVIDES_SERVICE,
            "公司及合并子公司",
            "涵盖",
        )
    if re.search(r"AI旅行助手SaaS平台已成功对外拓展外部部分景区", text):
        add(
            "AI旅行助手SaaS平台",
            ActivityAction.PROVIDES_SERVICE,
            "公司及合并子公司",
            "已拓展部分景区",
        )
    if re.search(r"公司是一家集葡萄种植、生产、销售为一体", text):
        add("葡萄", ActivityAction.PRODUCES, "公司及合并子公司", "种植")
    if re.search(r"公司按照合同约定的原料检验标准采购[^。]+酿酒葡萄原料", text):
        add("酿酒葡萄", ActivityAction.PURCHASES, "公司及合并子公司", "采购")
    if re.search(r"公司为种植单位或农户提供生产管理及技术指导服务", text):
        add(
            "生产管理及技术指导",
            ActivityAction.PROVIDES_SERVICE,
            "公司及合并子公司",
            "提供",
        )
    if "产销量情况分析表" in text and "生产量销售量库存量" in text:
        table = re.split(
            r"产销量情况说明|[（(]3[)）]",
            excerpt.split("产销量情况分析表", 1)[1],
            maxsplit=1,
        )[0]
        table = re.sub(r"(\.\d{2})(?=\d)", r"\1 ", table)
        for match in re.finditer(
            r"(?m)^\s*([^\s]+(?:[ \t]+[\u4e00-\u9fffA-Za-z]+)*?)\s+(千升|吨|台|辆)\s+(\d[\d,]*\.\d+)\s+(\d[\d,]*\.\d+)",
            table,
        ):
            if match[1] in {"合计", "小计"}:
                continue
            for amount, action, verb in [
                (match[3], ActivityAction.PRODUCES, "生产量"),
                (match[4], ActivityAction.SELLS, "销售量"),
            ]:
                if Decimal(amount.replace(",", "")) > 0:
                    add(
                        re.sub(r"\s+", "", match[1]),
                        action,
                        "公司及合并子公司",
                        verb,
                        "产销量/本期" + verb,
                    )
    if "产品档次" in text and "产销率" in text and "销售收入" in text:
        for match in re.finditer(
            r"(?:^|\n)\s*(高档|中低档)\s+(\d[\d,]*\.\d+)\s+-?\d+(?:\.\d+)?\s+(\d[\d,]*\.\d+)",
            excerpt,
        ):
            for amount, action, verb in [
                (match[2], ActivityAction.PRODUCES, "产量"),
                (match[3], ActivityAction.SELLS, "销量"),
            ]:
                if Decimal(amount.replace(",", "")) > 0:
                    add(
                        match[1],
                        action,
                        "公司及合并子公司",
                        verb,
                        "产品档次/本期" + verb,
                    )
    if "原料类别当期采购金额上期采购金额" in text:
        for match in re.finditer(r"(?m)^\s*(包装材料)\s+(\d[\d,]*\.\d{2})", excerpt):
            if Decimal(match[2].replace(",", "")) > 0:
                add(
                    match[1],
                    ActivityAction.PURCHASES,
                    "公司及合并子公司",
                    "采购",
                    "原料/当期采购金额",
                )
    for actor, kind, business, _ in _native_company_columns(excerpt) or []:
        if kind != "子公司" or not current(business):
            continue
        manufactured = re.search(r"^([^，。]{2,40}?)的生产加工和销售$", business)
        if manufactured:
            name = manufactured[1].split("植、")[-1]
            for action, verb in [
                (ActivityAction.PRODUCES, "生产"),
                (ActivityAction.PROCESSES, "加工"),
                (ActivityAction.SELLS, "销售"),
            ]:
                add(name, action, actor, verb, "控股公司原业务")
        for match in re.finditer(r"(葡萄|农作物|林木)的?种植", business):
            add(match[1], ActivityAction.PRODUCES, actor, "种植", "控股公司原业务")
        if "农副产品的购销" in business:
            add("农副产品", ActivityAction.PURCHASES, actor, "购", "控股公司原业务")
            add("农副产品", ActivityAction.SELLS, actor, "销", "控股公司原业务")
        for match in re.finditer(
            r"销售(葡萄酒)|(?:预包装食品)(?:销售|的批发)", business
        ):
            add(
                match[1] or "预包装食品",
                ActivityAction.SELLS,
                actor,
                "销售",
                "控股公司原业务",
            )
    # In the group composition table the explicitly declared sales activity
    # qualifies the goods in that same subsidiary's operating-business row.
    if "企业集团的构成" in text and "业务性质" in text:
        for match in re.finditer(
            r"([\u4e00-\u9fff]+酒业销售有限公司)[^。]{0,100}?销售100(?:\.00)?设立", text
        ):
            actor = match[1].split("设立")[-1]
            add("酒类", ActivityAction.SELLS, actor, "销售", "企业集团/业务性质")
    if re.search(r"作为出租人的经营租赁[\s\S]+?租赁收入\s+\d[\d,]*\.\d{2}", excerpt):
        add(
            "租赁",
            ActivityAction.PROVIDES_SERVICE,
            "公司及合并子公司",
            "出租",
            "作为出租人的经营租赁",
        )
    for title, action in [
        ("采购商品/接受劳务情况表", ActivityAction.PURCHASES),
        ("出售商品/提供劳务情况表", ActivityAction.PROVIDES_SERVICE),
    ]:
        if title not in excerpt:
            continue
        table = excerpt.split(title, 1)[1]
        table = re.split(
            r"出售商品/提供劳务情况表|购销商品、提供和接受劳务", table, maxsplit=1
        )[0]
        if not re.search(r"√适用\s*□不适用", table):
            continue
        for name, pattern, actual in [
            ("垃圾清运", r"垃圾清运收入\s+\d", action),
            ("软件", r"房餐费、软件\s+\d", action),
            ("酒水", r"酒水销售\s+\d", ActivityAction.SELLS),
            ("茶叶", r"茶叶款\s+\d", ActivityAction.PURCHASES),
        ]:
            if re.search(pattern, table):
                add(
                    name,
                    actual,
                    "公司及合并子公司",
                    "采购"
                    if actual == ActivityAction.PURCHASES
                    else "销售"
                    if actual == ActivityAction.SELLS
                    else "提供",
                    title,
                )

    # Each named business branch explicitly binds its own manufacturing,
    # toll processing and sales; merely operating a business is insufficient.
    for m in re.finditer(
        r"全资子公司(?P<actor>[\u4e00-\u9fff]{2,20}公司)[^。]+。[^。]+。其[^。]+主要从事(?P<name>[\u4e00-\u9fff]{2,12})的制造、受托加工及(?P<sale>不销售|拟销售|销售)业务",
        text,
    ):
        if current(m.group().replace(m["sale"], "销售")):
            for action, verb in [
                (ActivityAction.PRODUCES, "制造"),
                (ActivityAction.PROCESSES, "受托加工"),
                (ActivityAction.SELLS, "销售"),
            ]:
                if action != ActivityAction.SELLS or m["sale"] == "销售":
                    add(m["name"], action, m["actor"], verb)
    for m in re.finditer(
        r"全资子公司(?P<actor>[\u4e00-\u9fff]{2,20}公司)作为增量配网售电企业[^。]+批发采购电量交付用户[^。]+。",
        text,
    ):
        if current(m.group()):
            add("电力", ActivityAction.PURCHASES, m["actor"], "批发采购")
            add("电力", ActivityAction.SELLS, m["actor"], "交付用户")
    for m in re.finditer(
        r"子公司(?P<actor>[\u4e00-\u9fff]{2,20}公司)[^。]{0,20}每年[^。]{0,20}购煤[^。]+。",
        text,
    ):
        if current(m.group()):
            add("煤", ActivityAction.PURCHASES, m["actor"], "购煤")
    for m in re.finditer(
        r"子公司(?P<actor>[\u4e00-\u9fff]{2,20}公司)[^。]{0,80}进口(?P<name>煤炭)销售量[^。]+。",
        text,
    ):
        if current(m.group()):
            add(m["name"], ActivityAction.SELLS, m["actor"], "销售")
    for m in re.finditer(
        r"子公司(?P<actors>[\u4e00-\u9fff]{2,12}公司及[\u4e00-\u9fff]{2,12}公司)于本报告期销售(?P<name>存量房)",
        text,
    ):
        if current(m.group()):
            for actor in m["actors"].split("及"):
                add(m["name"], ActivityAction.SELLS, actor, "销售")
    for m in re.finditer(
        r"全资子公司(?P<actor>[\u4e00-\u9fff]{2,15}公司)继续做好[^。]+?(?P<names>商品房|住宅及住宅底商)的?(?:尾房)?销售[^。]+。",
        text,
    ):
        if current(m.group()):
            for name in m["names"].split("及"):
                add(name, ActivityAction.SELLS, m["actor"], "销售")
    # Explicit completed electricity/heat sales in the same named plant branch.
    if re.search(r"完成售电量[^。]+完成售热量", text) and not re.search(
        r"未完成售电|拟完成售电", text
    ):
        actor = re.search(r"全资子公司([\u4e00-\u9fff]{2,15}公司)严格落实", text)
        if actor:
            for name in ["电力", "蒸汽"]:
                add(name, ActivityAction.SELLS, actor[1], "完成销售")
    if "购煤成本" in text and re.search(r"电力、?热力生产和供应业购煤成本\d", text):
        add(
            "煤",
            ActivityAction.PURCHASES,
            None,
            "购煤",
            "电力热力生产供应业/购煤成本",
        )
    if "报告期内电量、收入及成本情况" in text and re.search(r"火电[^。]+煤\d", text):
        actor = re.search(r"全资子公司([\u4e00-\u9fff]{2,20}公司)总装机容量", text)
        if actor:
            add("煤", None, actor[1], "火电耗用", "能源")
    # The marketed production/sales table has actual positive sale quantities;
    # product forms/specifications remain evidence, not extra role identities.
    if "产销量情况分析表" in text and "销售量" in text:
        table = re.split(
            r"[（(]3[)）]", excerpt.split("产销量情况分析表", 1)[1], maxsplit=1
        )[0]
        for line in table.splitlines():
            m = re.match(
                r"\s*(?P<name>[^（）()\n]+)[（(][^）)]+[)）]\s+万(?:盒|支)\s+\d[\d,]*\s+(?P<sale>\d[\d,]*)",
                line,
            )
            if m and int(m["sale"].replace(",", "")) > 0 and current(m["name"]):
                add(
                    re.sub(r"\s+", "", m["name"]),
                    ActivityAction.SELLS,
                    "公司及合并子公司",
                    "销售",
                    "产销量/本期销售量",
                )
    if "医疗机构的合计实际采购量" in text:
        table = excerpt.split("医疗机构的合计实际采购量", 1)[1]
        for line in table.splitlines():
            m = re.match(
                r"\s*(?P<name>[^（）()\n]+)[（(].+?\s+[^\n]*元\s+(?P<sale>\d[\d,]*\.\d{2})",
                line,
            )
            if m and current(m["name"]) and Decimal(m["sale"].replace(",", "")) > 0:
                add(
                    re.sub(r"\s+", "", m["name"]),
                    ActivityAction.SELLS,
                    "公司及合并子公司",
                    "实际销售",
                    "医疗机构实际采购/公司销售",
                )
    # Current core drug list plus a present sales model governs those listed
    # products, not research projects later on the page.
    if (
        "主要业务" in text
        and re.search(r"主要业务为药品的研发、生产及销售", text)
        and "销售模式" in text
    ):
        section = text.split("（二）经营模式", 1)[0]
        if current(section):
            for m in re.finditer(
                r"[\u4e00-\u9fff]{2,15}(?:胶囊|糖浆|口服溶液|口服液|开塞露)", section
            ):
                name = re.sub(
                    r"^(?:公司主导产品|主要包括|普药系列主要包括|儿童系列用药包括)",
                    "",
                    m.group(),
                )
                if name.endswith("开塞露"):
                    name = "开塞露"
                add(
                    name,
                    ActivityAction.SELLS,
                    "公司及合并子公司",
                    "销售",
                    "已上市主要产品/销售模式",
                )
    # Marketed product/form column: clinical purchasing is the issuer's sale.
    if "公司药（产）品销售情况" in text and "主要产品" in text:
        section = text.split("主要销售模式分析", 1)[0]
        if current(section):
            for name in re.findall(
                r"[\u4e00-\u9fff]{2,15}(?:胶囊|口服溶液|口服液|开塞露)", section
            ):
                name = re.sub(r"^(?:公司主导产品|主要包括)", "", name)
                add(
                    name,
                    ActivityAction.SELLS,
                    "公司及合并子公司",
                    "销售",
                    "主要产品实际销售",
                )
    if re.search(r"营业利润\s+净利润", excerpt):
        for row in _native_company_table_rows(excerpt):
            actor = row[1]
            # The native row supplies an actual income, while its own business
            # cell establishes the object and sale direction.
            prefix = actor[: min(len(actor), 8)]
            line = next(
                (
                    l
                    for l in excerpt.splitlines()
                    if prefix in re.sub(r"\s+", "", l)
                    and re.search(r"子公司|参股公", l)
                ),
                "",
            )
            index = excerpt.splitlines().index(line) if line else -1
            branch = line + (
                " " + excerpt.splitlines()[index + 1]
                if index >= 0 and index + 1 < len(excerpt.splitlines())
                else ""
            )
            compact_branch = re.sub(r"\s+", "", branch)
            if current(compact_branch) and (
                "药品销售" in compact_branch
                or "医疗器械" in compact_branch
                and "产与销售" in compact_branch
            ):
                add(
                    "药品" if "药品销售" in compact_branch else "医疗器械",
                    ActivityAction.SELLS,
                    actor,
                    "销售",
                    "控股参股公司原业务",
                )
                if row[5].startswith("参股公司"):
                    bindings[-1]["subject_scope"] = SubjectScope.BUSINESS_SEGMENT
    return bindings


def _financial_entity_business_rows(excerpt: str) -> list[tuple[str, str, bool]]:
    """Bind wrapped entity/business cells in the currency-and-capital layout."""
    lines = excerpt.splitlines()
    header = next(
        (
            i
            for i, l in enumerate(lines)
            if "业务性质" in l and "注册资本" in l and "币种" in l
        ),
        None,
    )
    if header is None:
        return []
    rows = []
    active = lines[header + 1 :]
    data = [l for l in active if re.search(r"人民币|美元|英镑|泰铢|印尼卢", l)]
    if not data:
        return []
    first = re.search(r"(?P<business>[^\s\d]+)\s{2,}(?P<ratio>\d{1,3}\.\d{2})", data[0])
    if not first:
        return []
    left, right = first.start("business"), first.start("ratio")
    name_end = lines[header].index("币种") - 1
    actor = business = pending = ""

    def complete(cell):
        return bool(
            re.search(
                r"(?:销售|服务|研发|加工|贸易|等|[)）]|金融|咨询|业务|管理|活动|物流|进出口)$",
                cell,
            )
        )

    for line in active:
        if re.search(r"其他说明|在子公司的持股比例|重要的非全资子公司", line):
            break
        if "年度报告" in line or re.match(r"^\s*\d+\s*/\s*\d+", line):
            continue
        currency = re.search(r"人民币|美元|英镑|泰铢|印尼卢", line)
        cell = re.sub(r"\s+", "", line[left:right])
        if currency and currency.start() < left:
            name = re.sub(r"\s+", "", line[: currency.start()])
            if actor and not actor.endswith(("公司", "合伙)", "合伙）")):
                actor += name
                business += pending + cell
            else:
                if actor:
                    rows.append((actor, business, False))
                actor = name
                business = pending + cell
            pending = ""
        elif actor:
            name = re.sub(r"\s+", "", line[:name_end])
            if name and not re.search(r"名称|直接|间接", name):
                if actor.endswith(("公司", "合伙)", "合伙）")):
                    rows.append((actor, business, False))
                    actor = name
                    business = pending + cell
                    pending = ""
                    continue
                actor += name
            if cell:
                if complete(business) and not (
                    cell == "服务" and business.endswith("咨询")
                ):
                    pending += cell
                else:
                    business += cell
    if actor:
        rows.append((actor, business, False))
    return rows


def _owned_energy_vehicle_bindings(excerpt: str) -> list[dict[str, Any]]:
    """Bind native operating modes and production/sales tables to their actors."""
    text = re.sub(
        r"\s+", "", re.sub(r"(?m)^.*年度报告[^\n]*$|^\s*\d+\s*/\s*\d+\s*$", "", excerpt)
    )
    result = []

    def add(
        name, action, actor="公司及合并子公司", header="原经营模式", qualifier=None
    ):
        if name:
            result.append(
                {
                    "name": name,
                    "action": action,
                    "verb": action.value,
                    "actor": actor,
                    "header": header,
                    "qualifier": qualifier,
                    "subject_basis": SubjectBasis.DIRECT_SOURCE_WORDING,
                }
            )

    modes = re.search(r"生产运营：公司(.+?)主要通过所属[^。]+生产。", text)
    if modes:
        for name in re.split(r"、|和", modes[1]):
            add(name, ActivityAction.PRODUCES)
    procurement = re.search(r"采购模式：公司(.+?)等通过外部采购", text)
    if procurement:
        for name in re.split(r"、|和", procurement[1]):
            add(name, ActivityAction.PURCHASES)
    sale = re.search(r"销售模式：公司(.+?)。", text)
    if sale:
        first = re.match(r"(.+?)主要通过", sale[1])
        if first:
            add(first[1], ActivityAction.SELLS)
        second = re.search(r"；(.+?)等通过", sale[1])
        if second:
            for name in re.split(r"、|和", second[1]):
                add(name, ActivityAction.SELLS)
    service = re.search(r"同时提供(.+?)装卸、运输和储存服务", text)
    if service:
        for name in re.split(r"、|和", service[1]):
            add(name + "装卸、运输和储存", ActivityAction.PROVIDES_SERVICE)
    if "能源管理服务" in text and "为广大客户提供" in text:
        add("能源管理服务", ActivityAction.PROVIDES_SERVICE)
    service = re.search(r"提供([^。]+?)等一体化服务", text)
    if service:
        for name in service[1].split("、"):
            add(name, ActivityAction.PROVIDES_SERVICE)
    if "具体分部情况如下" in text:
        block = text.split("具体分部情况如下", 1)[1].split("分部间转移价格", 1)[0]
        for m in re.finditer(r"分部：([^；。]+)", block):
            b = m[1]
            generation = re.search(r"(.+?)发电(?:、(.+?)发电)?及销售", b)
            if generation:
                for base in [generation[1], generation[2]]:
                    if base:
                        for a in [ActivityAction.PRODUCES, ActivityAction.SELLS]:
                            add(base + "发电", a, header="原报告分部经营")
            if "储能业务" in b:
                add("储能业务", ActivityAction.PROVIDES_SERVICE)
            if "城市燃气管道建设" in b:
                add("城市燃气管道建设", ActivityAction.PROVIDES_SERVICE)
            lease = re.search(r"及([^；。]+)的租赁", b)
            if lease:
                add(lease[1] + "租赁", ActivityAction.PROVIDES_SERVICE)
    # The source explicitly labels current sales before current production.
    if "整车产销量" in text and "车型类别" in text and "产量" in text:
        block = excerpt.split("整车产销量", 1)[1].split("按地区", 1)[0]
        for line in block.splitlines():
            m = re.match(
                r"\s*([^\d]+?)\s+(\d[\d,]*)\s+\d[\d,]*\s+-?[\d.]+\s+(\d[\d,]*)\s+", line
            )
            if m:
                name = re.sub(r"\s+", "", m[1])
                if name in {"总计", "合计"}:
                    continue
                for action, value in [
                    (ActivityAction.SELLS, m[2]),
                    (ActivityAction.PRODUCES, m[3]),
                ]:
                    if Decimal(value.replace(",", "")) > 0:
                        add(name, action, header="整车产销量/本年累计")
    if "新能源汽车产销量" in text:
        block = excerpt.split("新能源汽车产销量", 1)[1].split("新能源汽车收入", 1)[0]
        for line in block.splitlines():
            m = re.match(
                r"\s*(乘用车|商用车)\s+(\d[\d,]*)\s+\d[\d,]*\s+-?[\d.]+\s+(\d[\d,]*)",
                line,
            )
            if m:
                for a, v in [
                    (ActivityAction.SELLS, m[2]),
                    (ActivityAction.PRODUCES, m[3]),
                ]:
                    if Decimal(v.replace(",", "")) > 0:
                        add("新能源汽车" + m[1], a, header="新能源汽车产销量/本年累计")
    if "产销量情况说明" in text and "辆" in text:
        block = excerpt.split("产销量情况说明", 1)[0]
        for m in re.finditer(
            r"(?m)^\s*(\S+(?:公司|分公司))\s+辆\s+(\d[\d,]*)\s+(\d[\d,]*)", block
        ):
            for a, v in [(ActivityAction.PRODUCES, m[2]), (ActivityAction.SELLS, m[3])]:
                if Decimal(v.replace(",", "")) > 0:
                    add("汽车", a, m[1], "具名企业本期汽车产销")
    if "本集团生产整车及零部件等产品并销售" in text:
        for name in ["整车", "零部件"]:
            for a in [ActivityAction.PRODUCES, ActivityAction.SELLS]:
                add(name, a, header="原当期产品产销")
    if ("汽车金融业务情况" in text or "主要经营指标" in text) and "子公司名称" in text:
        for m in re.finditer(r"子公司名称([^\n]+)", excerpt):
            add(
                "汽车金融",
                ActivityAction.PROVIDES_SERVICE,
                re.sub(r"\s+", "", m[1]),
                "原子公司汽车金融业务",
            )
    sale = re.search(r"实现([^。]+?)等销售量", text)
    if sale:
        for n in sale[1].split("、"):
            add(n, ActivityAction.SELLS)
    if "落地供应链服务业务" in text and "煤炭业务" in text:
        add("煤炭供应链服务", ActivityAction.PROVIDES_SERVICE)
    if "危化品仓储业务" in text:
        add("危化品仓储", ActivityAction.PROVIDES_SERVICE)
    if "燃气保险、燃气具销售额" in text:
        add("燃气具", ActivityAction.SELLS, "燃气集团")
        add("燃气保险", ActivityAction.PROVIDES_SERVICE, "燃气集团")
    if "国际航运业务实现营业收入" in text:
        add("国际航运", ActivityAction.PROVIDES_SERVICE)
    sale = re.search(r"通过境外平台([^。]+?)全年进口煤销售", text)
    if sale:
        add("进口煤", ActivityAction.SELLS, sale[1])
    if re.search(r"Robotaxi[^。]+商业化运营", text):
        add("Robotaxi", ActivityAction.PROVIDES_SERVICE)
    if "安吉物流自营远洋滚装船" in text and "全链国际物流能力" in text:
        add("国际物流", ActivityAction.PROVIDES_SERVICE, "安吉物流")
    return result


def _business_nature_action_bindings(
    actor: str, business: str, associate: bool = False
) -> list[dict[str, Any]]:
    """Bind shared verbs to their noun cell; separate clauses retain direction."""
    result = []

    def add(name, action):
        name = name.removesuffix("等").strip("、，的《》")
        if name:
            result.append(
                {
                    "name": name,
                    "action": action,
                    "verb": action.value,
                    "actor": actor,
                    "header": "原主体业务性质",
                    "subject_basis": SubjectBasis.DIRECT_SOURCE_WORDING,
                    "subject_scope": SubjectScope.BUSINESS_SEGMENT
                    if associate
                    else SubjectScope.NAMED_SUBSIDIARY,
                }
            )

    if re.search(r"拟|计划|尚未|注销", business):
        return result
    if "中、高档西服" in business:
        for name, action, verb in _native_business_verb_objects(business):
            add(name, action)
        return result
    if business.endswith("的中日合资企业"):
        business = business.removesuffix("的中日合资企业")
        for name, action, verb in _native_business_verb_objects(business):
            add(name, action)
        return result
    verbs = {
        "生产": ActivityAction.PRODUCES,
        "制造": ActivityAction.PRODUCES,
        "组装": ActivityAction.PRODUCES,
        "销售": ActivityAction.SELLS,
        "供应": ActivityAction.SELLS,
        "零售": ActivityAction.SELLS,
        "批发": ActivityAction.SELLS,
        "经营": ActivityAction.OPERATES,
        "采购": ActivityAction.PURCHASES,
        "研发": ActivityAction.DEVELOPS,
        "开发": ActivityAction.DEVELOPS,
        "设计": ActivityAction.DEVELOPS,
        "加工": ActivityAction.PROCESSES,
        "建设": ActivityAction.PROVIDES_SERVICE,
    }
    if business == "电力供应":
        add(business, ActivityAction.PROVIDES_SERVICE)
        return result
    if business == "燃气管网建设、燃气销售":
        add("燃气管网建设", ActivityAction.PROVIDES_SERVICE)
        add("燃气", ActivityAction.SELLS)
        return result
    if business == "风力、光伏发电、充电桩":
        for name in ["风力发电", "光伏发电"]:
            add(name, ActivityAction.PRODUCES)
        add("充电桩", ActivityAction.PROVIDES_SERVICE)
        return result
    if business.endswith("服务") and not re.search(r"销售|生产|采购|制造", business):
        add(business, ActivityAction.PROVIDES_SERVICE)
        return result
    if business in {"汽车金融", "客房、餐饮等", "汽车保险及相关财产保险业务等"}:
        add(business.removesuffix("等"), ActivityAction.PROVIDES_SERVICE)
        return result
    publication = re.fullmatch(r"《(.+?)》出版发行等", business)
    if publication:
        add(publication[1], ActivityAction.PROVIDES_SERVICE)
        return result
    if re.fullmatch(
        r"技术(?:服务|开发|咨询|交流|转让|推广)(?:、技术(?:服务|开发|咨询|交流|转让|推广))*等?",
        business,
    ):
        for name in business.removesuffix("等").split("、"):
            add(name, ActivityAction.PROVIDES_SERVICE)
        return result
    verbpat = "(?:" + "|".join(verbs) + ")"
    # 'X的设计、生产和销售' shares X; 'X建设、Y销售' has two subjects.
    suffix = re.fullmatch(
        r"(.+?)(?:的)?(" + verbpat + r"(?:(?:、|和|及)?" + verbpat + r")*)", business
    )
    prefix = re.fullmatch(
        r"(" + verbpat + r"(?:(?:、|和|及)?" + verbpat + r")*)(.+)", business
    )
    parts = (
        (suffix[1].removesuffix("的"), suffix[2])
        if suffix
        else (prefix[2], prefix[1])
        if prefix
        else None
    )
    if parts and re.search(verbpat, parts[0]):
        parts = None
    if parts:
        names, vs = parts
        for name in dict.fromkeys([names, *names.split("、")]):
            for verb in re.findall(verbpat, vs):
                add(name, verbs[verb])
    else:
        for clause in re.split(
            r"[，；]|、(?=[^、]*(?:销售|建设|服务)(?:、|$))", business
        ):
            if clause != business:
                result.extend(
                    _business_nature_action_bindings(actor, clause, associate)
                )
    return result


def _explicit_current_commodity_bindings(excerpt: str) -> list[dict[str, Any]]:
    """Current owned sales/purchases/use, keeping actual action and source actor."""
    text = re.sub(r"\s+", "", excerpt)
    physical = re.search(
        r"(?:采购商品/接受劳务|出售商品/提供劳务)情况表", excerpt
    ) and re.search(r"关联方\s{2,}关联交易(?:内)?", excerpt)
    if physical:
        return _related_current_goods_bindings(excerpt)
    registered_rows = _native_company_columns(excerpt) or []
    if registered_rows and "经营范围" in text and "许可项目" in text:
        # This is the registered-permission column, even where a row's opening
        # label is vertically wrapped above its company name. Actual operations
        # must have a separate current business disclosure.
        return []
    entity_rows = _financial_entity_business_rows(excerpt)
    if entity_rows:
        return [
            binding
            for actor, business, associated in entity_rows
            for binding in _business_nature_action_bindings(actor, business, associated)
        ]
    bindings = [
        *_owned_energy_vehicle_bindings(excerpt),
        *_native_branch_action_bindings(excerpt),
        *_owned_goods_bindings(excerpt),
        *_owned_product_action_bindings(excerpt),
        *_related_current_goods_bindings(excerpt),
    ]

    def add(name, action, verb, actor="本公司", header=None):
        bindings.append(
            {
                "name": name,
                "action": action,
                "verb": verb,
                "actor": actor,
                "header": header,
            }
        )

    for actor, business, associate in _financial_entity_business_rows(excerpt):
        bindings.extend(_business_nature_action_bindings(actor, business, associate))
    for actor, kind, business, _ in _native_company_columns(excerpt) or []:
        bindings.extend(
            _business_nature_action_bindings(actor, business, kind != "子公司")
        )

    def native_action(
        name,
        action,
        verb,
        actor="公司及合并子公司",
        header="本期经营原句",
        qualifier=None,
    ):
        add(name, action, verb, actor, header)
        bindings[-1].update(
            subject_basis=SubjectBasis.DIRECT_SOURCE_WORDING, qualifier=qualifier
        )

    if "网内水力自发电量全部上网销售" in text:
        native_action("电力", ActivityAction.PRODUCES, "自发电")
        native_action("电力", ActivityAction.SELLS, "上网销售")
        purchase = re.search(r"从([^。]+?公司)购买销售", text)
        if purchase:
            native_action(
                "电力",
                ActivityAction.PURCHASES,
                "购买",
                header="本期采购电力",
                qualifier="交易对方：" + purchase[1],
            )
    water = re.search(
        r"全资子公司([^。]+?有限公司)拥有独立的城市供水网络。主要通过[^。]+趸购清水[^。]+销售",
        text,
    )
    if water:
        for action, verb in [
            (ActivityAction.PURCHASES, "趸购"),
            (ActivityAction.SELLS, "销售"),
        ]:
            native_action(
                "自来水",
                action,
                verb,
                water[1],
                "本期采购商品"
                if action == ActivityAction.PURCHASES
                else "本期供水经营模式",
                "趸购销售为主；四座水厂停止常规生产，保留当期生产量",
            )
    services = re.search(r"综合能源服务主要包括：([^。]+?)等。", text)
    if services:
        for name in services[1].split("、"):
            native_action(name, ActivityAction.PROVIDES_SERVICE, "提供")
    for m in re.finditer(r"全资子公司([^。]+?)(?:建成投运|投运)([^。]+)。", text):
        actor = m[1].split("首获", 1)[0]
        for name in m[2].split("、"):
            name = re.sub(r"^首(?:座|个)|[“”]", "", name)
            native_action(
                name,
                ActivityAction.OPERATES,
                "投运",
                actor,
                "本期已投运项目",
                "原句建成投运，不推销售",
            )
    if "本集团从事的安装工程业务是提供电力与自来水相关工程的安装业务" in text:
        for name in ["电力安装工程", "自来水安装工程"]:
            native_action(name, ActivityAction.PROVIDES_SERVICE, "安装")
    for pattern in [
        r"包括(电力工程设计)收入及(水务工程设计)收入",
        r"提供(餐饮)、(住宿)及(会议)等服务",
        r"提供的(物业管理)服务",
        r"提供(带电作业)、(电气试验)、(智能维保)、(新能源服务)等",
    ]:
        for m in re.finditer(pattern, text):
            for name in m.groups():
                native_action(name, ActivityAction.PROVIDES_SERVICE, "提供")
    crops = re.search(r"种植作物覆盖([^。]+?)等。", text)
    if crops:
        for name in crops[1].split("、"):
            native_action(name, ActivityAction.PRODUCES, "种植")
    processing = re.search(r"加工业板块[^。]+主要涵盖([^。]+?)及相应工程服务。", text)
    if processing:
        for name in processing[1].split("、"):
            native_action(name.removesuffix("加工"), ActivityAction.PROCESSES, "加工")
    sale = re.search(r"所属([^。]+?公司)[^。]+加快销售([^。]+?)，", text)
    if sale:
        native_action(sale[2], ActivityAction.SELLS, "销售", sale[1])
    for m in re.finditer(r"(农产品|滴灌材料)加工(?:销售)?", text):
        if "本公司主要从事农产品生产种植" in text:
            native_action(m[1], ActivityAction.PROCESSES, "加工")
            native_action(
                m[1], ActivityAction.SELLS, "贸易销售" if m[1] == "农产品" else "销售"
            )
    if "滴灌工程实施" in text and "本公司主要从事农产品生产种植" in text:
        native_action("滴灌工程", ActivityAction.PROVIDES_SERVICE, "实施")
    if "零部件产销量" in text and "销量产量" in text:
        table = re.split(r"零部件产销量", excerpt.replace("\r", ""), maxsplit=1)[1]
        table = re.split(r"产品销售|其他说明", table, maxsplit=1)[0]
        # The six headed cells are sales/current, sales/prior, sales/change,
        # production/current, production/prior, production/change. An empty
        # change cell after a zero does not move the production column.
        table = re.sub(
            r"(?m)^([\u4e00-\u9fffA-Za-z \t]{2,30})\n\s*([\u4e00-\u9fff]{1,15})\s*\n\s*(?=\d)",
            lambda m: re.sub(r"\s+", "", m[1] + m[2]) + " ",
            table,
        )
        table = re.sub(
            r"(?m)^([\u4e00-\u9fffA-Za-z \t]{2,30})\n(?=[\u4e00-\u9fff]+\s+\d)",
            lambda m: re.sub(r"\s+", "", m[1]),
            table,
        )
        for line in table.splitlines():
            m = re.match(
                r"\s*(?P<name>[\u4e00-\u9fffA-Za-z \t]{2,30}?)\s+(?P<cells>\d[^\n]*)$",
                line,
            )
            if not m:
                continue
            cells = m["cells"].split()
            if len(cells) < 5:
                continue
            name = re.sub(r"\s+", "", m["name"])
            if Decimal(cells[0].replace(",", "")) > 0:
                add(
                    name,
                    ActivityAction.SELLS,
                    "销量",
                    "公司及合并子公司",
                    "零部件产销量/本年销量",
                )
                bindings[-1]["subject_basis"] = SubjectBasis.DIRECT_SOURCE_WORDING
            if Decimal(cells[3].replace(",", "")) > 0:
                add(
                    name,
                    ActivityAction.PRODUCES,
                    "产量",
                    "公司及合并子公司",
                    "零部件产销量/本年产量",
                )
                bindings[-1]["subject_basis"] = SubjectBasis.DIRECT_SOURCE_WORDING
    if "热水供应服务" in text and "公司子公司" in text:
        owned = re.search(r"公司子公司(?P<actors>[^。]+?)专注于校园市场", text)
        if owned and "向学生收取用水费用" in text:
            for actor in owned["actors"].split("及"):
                add(
                    "热水供应",
                    ActivityAction.PROVIDES_SERVICE,
                    "提供",
                    actor,
                    "热水供应服务",
                )
                bindings[-1]["subject_basis"] = SubjectBasis.DIRECT_SOURCE_WORDING
        services = re.search(
            r"校园增值业务：包括(?P<names>[^。]+?)等高频生活服务", text
        )
        if services:
            for name in services["names"].split("、"):
                add(
                    name,
                    ActivityAction.PROVIDES_SERVICE,
                    "提供",
                    "公司及合并子公司",
                    "校园增值业务",
                )
                bindings[-1]["subject_basis"] = SubjectBasis.DIRECT_SOURCE_WORDING
        rental = re.search(
            r"公司依托校园场景资源，提供(?P<names>[^。]+?)等设备租赁服务", text
        )
        if rental:
            for name in rental["names"].split("、"):
                add(
                    name,
                    ActivityAction.PROVIDES_SERVICE,
                    "租赁",
                    "公司及合并子公司",
                    "少量院校设备租赁",
                )
                bindings[-1]["subject_basis"] = SubjectBasis.DIRECT_SOURCE_WORDING
    if "贸易业务开展情况" in text and "本期营业收入" in text:
        trade = re.split(r"贸易业务开展情况", excerpt, maxsplit=1)[1]
        for row in _native_note_income_rows(
            "√适用 □不适用\n贸易业务开展情况\n" + trade, "贸易业务收入"
        ):
            if Decimal(row[2].replace(",", "")) > 0:
                native_action(
                    row[1], ActivityAction.SELLS, "销售", header="贸易业务/本期营业收入"
                )
    if "贸易业务开展情况" in text and "本期营业收入" in text:
        table = re.split(r"贸易业务开展情况", excerpt, maxsplit=1)[1]
        for m in re.finditer(
            r"(?m)^\s*([\u4e00-\u9fff]{1,20})销售\s+(\d[\d,]*\.\d+)\s+\d", table
        ):
            if Decimal(m[2].replace(",", "")) > 0:
                add(
                    m[1],
                    ActivityAction.SELLS,
                    "销售",
                    "公司及合并子公司",
                    "贸易业务/本期营业收入",
                )
                bindings[-1]["subject_basis"] = SubjectBasis.DIRECT_SOURCE_WORDING
    if "关联交易金额" in text and "关联交易内容" in text:
        for m in re.finditer(
            r"购买商品采购(?P<name>机具)市场定价(?P<amount>\d[\d,]*\.\d+)", text
        ):
            if Decimal(m["amount"].replace(",", "")) > 0:
                add(
                    m["name"],
                    ActivityAction.PURCHASES,
                    "购买",
                    "公司及合并子公司",
                    "实际关联购买",
                )
                bindings[-1]["subject_basis"] = SubjectBasis.DIRECT_SOURCE_WORDING
        if re.search(r"提供劳务光伏发电(?:收入)?市场定价\d[\d,]*\.\d+", text):
            add(
                "光伏发电",
                ActivityAction.PROVIDES_SERVICE,
                "提供劳务",
                "公司及合并子公司",
                "个别项目实际劳务收入/模式验证",
            )
            bindings[-1]["subject_basis"] = SubjectBasis.DIRECT_SOURCE_WORDING
    if "业务性质" in text or "权益法" in text:
        owners = list(
            re.finditer(
                r"(?m)^\s*(?P<actor>[\u4e00-\u9fff（）()]{2,50}有限公司)\s+(?P<row>[^\n]+)",
                excerpt,
            )
        )
        for index, m in enumerate(owners):
            end = owners[index + 1].start() if index + 1 < len(owners) else len(excerpt)
            row = re.sub(
                r"\s+",
                "",
                re.split(
                    r"在合营企业|[（(]\d+[)）]\.", excerpt[m.start() : end], maxsplit=1
                )[0],
            )
            if "汽车零部件生产及销售" in row and "权益法" in row:
                add(
                    "汽车零部件",
                    ActivityAction.SELLS,
                    "销售",
                    m["actor"],
                    "原权益法参股主体业务性质",
                )
                bindings[-1].update(
                    subject_basis=SubjectBasis.DIRECT_SOURCE_WORDING,
                    subject_scope=SubjectScope.BUSINESS_SEGMENT,
                )
            elif "摩托车化油器、汽车配件销售" in row:
                for name in ["摩托车化油器", "汽车配件"]:
                    add(
                        name,
                        ActivityAction.SELLS,
                        "销售",
                        m["actor"],
                        "原子公司业务性质",
                    )
                    bindings[-1]["subject_basis"] = SubjectBasis.DIRECT_SOURCE_WORDING
    main = re.search(
        r"公司主要从事[^。]+研发、生产和销售[^。]+。主要产品包括(?P<names>[^。]+)", text
    )
    if main and not re.search(r"尚未|不从事|未销售|拟|计划|将销售", main.group()):
        for name in main["names"].split("、"):
            if name.endswith("复合集装箱地板"):
                add(name, ActivityAction.SELLS, "销售", "公司", "主要业务及产品")
    for match in re.finditer(r"富余(?P<name>[^，。]{2,20})对外销售", text):
        prefix = text[max(0, text.rfind("。", 0, match.start()) + 1) : match.start()]
        if not re.search(r"第三方|未|不|拟|计划|将", prefix):
            add(match["name"], ActivityAction.SELLS, "对外销售", "公司")
    # These are the current deduction explanation cells, not the preceding
    # list of possible non-core businesses in the standard table label.
    for match in (
        list(re.finditer(r"\d[\d,]*\.\d+主要系(?P<cell>[^\d]+)", text))[:1]
        if "本年度具体扣除情况上年度具体扣除情况" in text
        else ()
    ):
        cell = match["cell"]
        for branch in cell.split("、"):
            if re.search(r"尚未|未销售|不销售|拟|计划|将", branch):
                continue
            sale = re.fullmatch(
                r"(?P<name>[\u4e00-\u9fff]{2,8})销售|出售(?P<other>[\u4e00-\u9fff]{2,8})",
                branch,
            )
            if sale:
                add(
                    sale["name"] or sale["other"],
                    ActivityAction.SELLS,
                    "销售",
                    "公司及合并子公司",
                    "本年度其他业务收入",
                )
    for match in re.finditer(
        r"\d[\d,]*\.\d+木方收入及(?P<actor>[\u4e00-\u9fff]{2,10})木质材料收入", text
    ):
        add(
            "木方",
            ActivityAction.SELLS,
            "收入",
            "公司及合并子公司",
            "本年度其他业务收入",
        )
        add(
            "木质材料",
            ActivityAction.SELLS,
            "收入",
            match["actor"],
            "本年度其他业务收入",
        )
    subsidiary = re.search(
        r"(?P<actor>[\u4e00-\u9fff]{2,40}有限公司)100[.]00生产销售：[\s\S]+?(?=\d[\d,]*\.\d+)",
        text,
    )
    if subsidiary and not re.search(r"尚未|未销售|拟|计划|将", subsidiary.group()):
        names = subsidiary.group().split("生产销售：", 1)[1]
        for name in names.split("、"):
            if re.fullmatch(r"[\u4e00-\u9fff]{2,20}", name):
                add(
                    name,
                    ActivityAction.SELLS,
                    "生产销售",
                    subsidiary["actor"],
                    "原子公司主要业务",
                )
                bindings[-1]["subject_basis"] = SubjectBasis.DIRECT_SOURCE_WORDING
    purchase = re.search(
        r"采购商品/接受劳务情况表(?P<table>[\s\S]+?)(?=出售商品/提供劳务|$)", excerpt
    )
    if purchase and not re.search(r"拟采购|计划采购|未采购|不采购", purchase.group()):
        for match in re.finditer(
            r"(?m)^\s*[^\n]+?\s+(?P<name>箱板)\s+(?P<amount>\d[\d,]*\.\d+)",
            purchase["table"],
        ):
            if Decimal(match["amount"].replace(",", "")) > 0:
                add(
                    match["name"],
                    ActivityAction.PURCHASES,
                    "采购",
                    "公司及合并子公司",
                    "采购商品/接受劳务/本期发生额",
                )
    sales = re.search(r"出售商品/提供劳务(?P<table>[\s\S]+)", excerpt)
    if sales and not re.search(r"拟出售|计划出售|未出售|不出售", sales.group()):
        for match in re.finditer(
            r"(?m)^\s*[^\n]+?\s+(?P<name>木结构产品)\s+(?P<amount>-?\d[\d,]*\.\d+)",
            sales["table"],
        ):
            if Decimal(match["amount"].replace(",", "")) > 0:
                add(
                    match["name"],
                    ActivityAction.SELLS,
                    "出售",
                    "公司及合并子公司",
                    "出售商品/提供劳务/本期发生额",
                )
    for match in re.finditer(
        r"(?:^|[。；;])(?:报告期内，)?本公司[^。]{0,40}销售电力产品和热力产品", text
    ):
        if not re.search(r"尚未|未销售|拟|计划|将销售", match.group()):
            for name in ("电力", "热力"):
                add(name, ActivityAction.SELLS, "销售")
    for match in re.finditer(
        r"本公司及其子公司[（(]以下简称[“\"]本集团[”\"][)）]主要从事(?P<activities>[^。]+)",
        text,
    ):
        # An action modifier governs its enumerated branch, not the whole page.
        # The group definition proves the actor, but cannot affirm a planned sale.
        for branch in re.split(r"[、，,；;]|以及|及", match["activities"]):
            sale = re.search(r"煤炭销售", branch)
            if sale and not re.search(
                r"不|未|没有|拟|计划|将|未来|预计|准备|打算",
                branch[: sale.start()],
            ):
                add("煤炭", ActivityAction.SELLS, "销售", "本集团")
                bindings[-1]["subject_basis"] = SubjectBasis.DIRECT_SOURCE_WORDING
                break
    for m in re.finditer(
        r"\d{4}年，本公司向[^。]+?(采购|购买)(煤炭|燃料)的实际发生总金额[^。]+。", text
    ):
        if not re.search(r"拟|计划|尚未|未购买|未采购|将购买|将采购", m.group()):
            add(m[2], ActivityAction.PURCHASES, m[1])
    for m in re.finditer(r"\d{4}年，本公司向[^。]+实际发生总金额[^。]+。", text):
        if re.search(
            r"向[^。]+出售燃料及提供服务的实际发生总金额", m.group()
        ) and not re.search(r"拟|计划|尚未|未出售|将出售", m.group()):
            add("燃料", ActivityAction.SELLS, "出售")
    if re.search(r"报告期内，本公司供电煤耗累计完成", text):
        add("煤炭", None, "耗用", header="能源")
    if re.search(r"报告期内，本公司发电厂用电率完成", text):
        add("电力", None, "耗用", header="能源")
    if re.search(r"其他业务：主要为绿证交易业务，本期交易量[^。]+营业收入", text):
        add("绿证", ActivityAction.SELLS, "交易", header="当期绿证交易收入")
    # Table category labels need the owned bus context, not the industry label.
    table_prefix = re.split(r"整车产销量|新能源汽车产销量", text)[0][-150:]
    if re.search(r"子公司|第三方|拟|计划|尚未|将销售", table_prefix):
        return bindings
    if "整车产销量" in text or "新能源汽车产销量" in text:
        for section in re.split(r"按地区|按销售模式|新能源汽车收入", excerpt):
            if "销量（辆）" not in re.sub(r"\s+", "", section):
                continue
            for line in section.replace("\r", "").splitlines():
                m = re.match(
                    r"\s*(大型|中型|轻型|纯电动|插电式|燃料电池)\s+\d[\d,]*\s+\d", line
                )
                if m:
                    add(m[1] + "客车", ActivityAction.SELLS, "销售", "公司", "当期销量")
    return bindings


def _related_current_goods_bindings(excerpt: str) -> list[dict[str, Any]]:
    """Direct current objects in related transactions and subsidiary disclosures."""
    # A table header is not part of its first subsidiary's grammatical actor.
    table_excerpt = re.split(r"营业利润\s*净利润", excerpt, maxsplit=1)[-1]
    text = re.sub(r"\s+", "", table_excerpt)
    text = text.replace("销售商品提供劳务", "关联交易动作")
    bindings = []

    def add(name, action, actor="公司及合并子公司", header=None, qualifier=None):
        bindings.append(
            {
                "name": name,
                "action": action,
                "actor": actor,
                "verb": "销售"
                if action == ActivityAction.SELLS
                else "采购"
                if action == ActivityAction.PURCHASES
                else "出租"
                if header == "本期出租服务"
                else "提供",
                "header": header,
                "qualifier": qualifier,
                "subject_basis": SubjectBasis.DIRECT_SOURCE_WORDING,
            }
        )

    physical_tables = False
    seller = re.search(
        r"出售商品/提供劳务情况表([\s\S]+?)(?=购销商品、提供和接受劳务的关联交易说明|$)",
        excerpt,
    )
    if seller:
        native = _native_related_sales_columns(seller[1])
        if native is not None:
            physical_tables = True
            for row in native:
                if Decimal(row[2].replace(",", "")) <= 0:
                    continue
                goods = row[1]
                if goods in {"合计", "小计", "总计"}:
                    continue
                if goods == "其他" or re.search(r"工程施工[/／].*材料", goods):
                    # The mixed table establishes income, not whether this
                    # native row is a good, service, or a mixture. Retain its
                    # financial records and original Evidence without adding
                    # a definite Activity or an answer-supporting service.
                    continue
                mixed = re.fullmatch(r"销售(水电汽)(?:、提供(客运服务))?", goods)
                if mixed:
                    for n in mixed[1]:
                        add(
                            n,
                            ActivityAction.SELLS,
                            header="本期销售商品",
                            qualifier=row[5],
                        )
                    if mixed[2]:
                        add(
                            mixed[2],
                            ActivityAction.PROVIDES_SERVICE,
                            header="本期提供服务",
                            qualifier=row[5],
                        )
                    continue
                if re.search("取消补偿", goods):
                    # Cancellation compensation establishes a receipt, not
                    # delivery of the originally contracted commodity.
                    continue
                if re.search(
                    "服务|劳务|租赁|回租|仓储|工程(?!材料)|代输费|运费|技术提成|技术转让|市场化售电|水电费",
                    goods,
                ):
                    add(
                        goods,
                        ActivityAction.PROVIDES_SERVICE,
                        header="出售商品/提供劳务/本期发生额",
                        qualifier=row[5],
                    )
                elif goods.endswith("检测费"):
                    add(
                        goods.removesuffix("费"),
                        ActivityAction.PROVIDES_SERVICE,
                        header="出售商品/提供劳务/本期发生额",
                        qualifier=row[5],
                    )
                elif not re.search(r"费用|费$|租金|劳保", goods):
                    add(
                        goods,
                        ActivityAction.SELLS,
                        header="出售商品/提供劳务/本期发生额",
                        qualifier=row[5],
                    )
                for name in re.split(r"、|，|(?<=费用)及", goods.removesuffix("等")):
                    name = name.removeprefix("销售").removesuffix("等")
                    if re.fullmatch(r"[\u4e00-\u9fff]{1,20}", name) and not re.search(
                        r"服务|提供|费用|费$|维修$|工程(?!材料)|市场化售电|仓储|回租|技术提成|技术转让|管理|代理|收入|劳务|合计|小计|商标|劳保|租金",
                        name,
                    ):
                        add(
                            name,
                            ActivityAction.SELLS,
                            header="出售商品/提供劳务/本期发生额",
                            qualifier=row[5],
                        )
    for m in re.finditer(r"购买商品([^。]+?)市场价(?:格)?([\d,]+\.\d{2})", text):
        if Decimal(m[2].replace(",", "")) > 0:
            for name in m[1].split("、"):
                if re.fullmatch(r"[\u4e00-\u9fff]{1,20}", name):
                    add(name, ActivityAction.PURCHASES, header="本期购买商品")
    purchase = re.search(
        r"采购商品/接受劳务情况表([\s\S]+?)(?=出售商品/提供劳务情况表|$)", excerpt
    )
    if purchase:
        # Services and construction remain purchases, with their native category.
        # Use the same content rule for whole cells and enumerated objects.
        purchase_service = re.compile(
            r"服务|劳务|工程|检测|维修|维护|检修|咨询|招聘测试|建设项目|水电费"
        )
        native = _native_related_sales_columns(purchase[1])
        if native is not None:
            physical_tables = True
            for row in native:
                if Decimal(row[2].replace(",", "")) <= 0:
                    continue
                if row[1] in {"采购商品/接受劳务", "其他"}:
                    add(
                        row[1],
                        ActivityAction.PURCHASES,
                        header="本期采购原内容",
                        qualifier=row[5],
                    )
                    continue
                if re.search(r"利息支出|新增使用权资产", row[1]):
                    continue
                # Enumerated goods keep each original object; retain the whole
                # cell only when its service or qualifier is inseparable.
                if (
                    purchase_service.search(row[1])
                    or re.search("原料和商品", row[1])
                    or row[1].endswith("等")
                    or re.search(r"电费|水电费|长期资产", row[1])
                    or not re.search(r"、|，|及(?!精矿)", row[1])
                ) and (
                    not row[1].endswith("费")
                    or purchase_service.search(row[1])
                    or re.search(r"电费|水电费", row[1])
                ):
                    add(
                        "研发劳务"
                        if row[1] == "接受劳务-研发支出"
                        else row[1].removeprefix("购买").removeprefix("采购")
                        if row[1] not in {"采购商品", "接受劳务", "接受服务"}
                        else row[1],
                        ActivityAction.PURCHASES,
                        header=(
                            "本期采购原内容"
                            if re.search(
                                r"商品、材料及劳务|服务费、操作费、电费|生产电费、物业管理费",
                                row[1],
                            )
                            else "本期采购公用事业"
                            if re.fullmatch(r"生产(?:用水)?电费", row[1])
                            else "本期购置资产"
                            if row[1].removeprefix("购买") == "长期资产"
                            else "本期采购服务"
                            if "租赁费用" in row[1]
                            else "本期采购服务"
                            if purchase_service.search(row[1])
                            else "本期采购商品"
                        ),
                        qualifier=row[5],
                    )
                if row[1] in {"接受劳务", "采购商品", "接受服务"}:
                    # Labour type belongs to the explicit named supplier's service;
                    # its full source row and amount stay in Evidence.
                    if row[1] == "采购商品":
                        add(
                            "商品",
                            ActivityAction.PURCHASES,
                            header="本期采购商品",
                            qualifier=row[5],
                        )
                    elif row[1] == "接受劳务" and "物业" in row[5]:
                        add(
                            "物业服务",
                            ActivityAction.PURCHASES,
                            header="本期接受劳务",
                            qualifier=row[5],
                        )
                elif row[1].endswith("等") or row[1].endswith("检测费"):
                    add(
                        row[1].removesuffix("等").removesuffix("费"),
                        ActivityAction.PURCHASES,
                        header=(
                            "本期采购服务"
                            if purchase_service.search(row[1])
                            else "本期采购原内容"
                        ),
                        qualifier=row[5],
                    )
                for name in re.split(r"、|，|及(?!精矿)", row[1].removesuffix("等")):
                    name = (
                        name.removeprefix("采购")
                        .removeprefix("购买")
                        .removesuffix("等")
                    )
                    name = name.split("等", 1)[0]
                    if re.fullmatch(r"[\u4e00-\u9fff]{1,20}", name) and not re.search(
                        r"服务|费$|费用$|维保|工程|作业|餐饮|劳务|管理|劳保|维修|维护|检修|^开发$|长期资产|使用权资产",
                        name,
                    ):
                        add(
                            name,
                            ActivityAction.PURCHASES,
                            header=(
                                "本期采购服务"
                                if purchase_service.search(name)
                                else "本期采购商品"
                            ),
                            qualifier=row[5],
                        )
    if "本公司作为出租方" in excerpt:
        rental = re.split(
            r"本公司作为承租方|关联租赁情况说明",
            excerpt.split("本公司作为出租方", 1)[1],
            maxsplit=1,
        )[0]
        for row in _lessor_income_rows(rental):
            if Decimal(row[2].replace(",", "")) > 0:
                add(
                    row[1] + "租赁" if not row[1].endswith("租赁") else row[1],
                    ActivityAction.PROVIDES_SERVICE,
                    header="本期出租服务",
                    qualifier=row[5].replace("承租方：：", "承租方："),
                )
    if physical_tables:
        return bindings
    table = re.search(
        r"(?:采购商品/接受劳务情况表|出售商品/提供劳务情况表|关联交易动作)[\s\S]+", text
    )
    if table:
        for m in re.finditer(
            r"(?P<verb>销售|采购)(?P<names>[^。；\d/]{1,100}?)(?=，提供|、提供|，接受|、接受|，供应|、供应|协议价格|\d[\d,]*\.)",
            table.group(),
        ):
            position = table.start() + m.start()
            prefix = text[max(0, position - 12) : position]
            if re.search(r"尚未|不从事|未|不|拟|计划|将", prefix):
                continue
            for name in re.split(r"[、，]|及", m["names"]):
                name = re.sub(r"等.*$", "", name)
                if not re.fullmatch(r"[\u4e00-\u9fffA-Za-z]{1,20}", name) or name in {
                    "辅助原料",
                    "辅助原材料",
                    "材料",
                    "辅助材料",
                    "商品",
                    "原料",
                    "其他服务",
                }:
                    continue
                if name.endswith("费") or re.search(
                    r"公司|研发|采购|固定资产|不适用|是否|获批|额度", name
                ):
                    continue
                add(
                    name,
                    ActivityAction.SELLS
                    if m["verb"] == "销售"
                    else ActivityAction.PURCHASES,
                )
        purchase = re.split(r"出售商品/提供劳务情况表", table.group(), maxsplit=1)[0]
        if table.group().startswith("采购商品"):
            for m in re.finditer(r"(?:工程物资|电费)\d[\d,]*\.", purchase):
                add(
                    "工程物资" if m.group().startswith("工程物资") else "电",
                    ActivityAction.PURCHASES,
                )
    for m in re.finditer(
        r"(?P<actor>[\u4e00-\u9fff]{2,12})子公司(?P<products>[^\d。]{1,60}?)的?生产(?:和|与)?销售\d",
        text,
    ):
        if not re.search(r"未|拟|计划|将|尚未", m["products"]):
            products = re.split(r"在内的", m["products"])[-1]
            products = re.split(r"的研发", products)[0]
            for name in re.split(r"[、，]|及", products):
                name = name.removesuffix("的")
                if name and not name.endswith("等"):
                    add(name, ActivityAction.SELLS, m["actor"].removeprefix("名称型"))
    for m in re.finditer(
        r"(?P<name>[^。\d；]{1,12})系(?P<actor>[\u4e00-\u9fff]{2,12})生产后向[^。]+对外销售",
        text,
    ):
        name = re.split(r"[，、]", m["name"])[-1].lstrip(".．")
        if not re.search(r"尚未|未|拟|计划|将", m.group()):
            add(name, ActivityAction.SELLS, m["actor"])
    if "公司生产的产品在满足自身" in text:
        m = re.search(r"富余的([^。]+?)，凭借[^。]+，销售给其使用", text)
        if m and not re.search(r"不|未|拟|计划|将", m.group()):
            for name in re.split(r"[、，]", m[1]):
                if name.endswith("等工业废气"):
                    name = name.removesuffix("等工业废气")
                add(name.removeprefix("工业"), ActivityAction.SELLS)
    if "产销量情况说明" in text and re.search(
        r"电、蒸汽系除供应[^。]+自身耗用外", text
    ):
        for name in ["电", "蒸汽"]:
            bindings.append(
                {
                    "name": name,
                    "action": None,
                    "verb": "耗用",
                    "header": "能源",
                    "actor": "公司及合并子公司",
                }
            )
    return bindings
