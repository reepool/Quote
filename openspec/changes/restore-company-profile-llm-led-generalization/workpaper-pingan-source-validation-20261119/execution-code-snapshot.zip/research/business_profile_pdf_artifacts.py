"""Auditable page artifacts for archived company business-profile PDFs."""

from __future__ import annotations

import gzip
import hashlib
import json
import logging
import os
import re
import threading
import time
import unicodedata
from contextlib import contextmanager
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence


BUSINESS_PROFILE_PDF_ARTIFACT_SCHEMA_VERSION = "business_profile_pdf_artifact.v2"
# v3 detects valid-Unicode mojibake (for example a broken ToUnicode map), not
# only replacement/control characters.  The version invalidates old manifests
# whose page-level diagnostics under-reported these pages.
BUSINESS_PROFILE_PDF_EXTRACTOR_VERSION = "business_profile_pdfium_recovery.v4"
DEFAULT_LOW_TEXT_CHARACTER_THRESHOLD = 40
DEFAULT_GLYPH_DECODING_RATIO_THRESHOLD = 0.05
DEFAULT_GLYPH_DECODING_MIN_CHARACTERS = 3
DEFAULT_HEADING_ALIASES: Dict[str, Sequence[str]] = {
    "principal_business": ("主要业务", "主营业务", "principal business"),
    "business_model": ("经营模式", "business model"),
    "segment_information": (
        "分部信息",
        "分行业",
        "分产品",
        "segment information",
    ),
    "revenue_cost_analysis": (
        "营业收入和营业成本",
        "收入和成本分析",
        "revenue and cost",
    ),
    "production_sales_inventory": (
        "产销量",
        "生产量",
        "销售量",
        "库存量",
        "production and sales",
    ),
    "cost_composition": ("成本构成", "成本分析", "cost composition"),
    "resources_and_reserves": ("资源储量", "矿产资源", "resources and reserves"),
    "major_projects": ("重大项目", "在建工程", "major projects"),
    "derivatives_and_hedging": (
        "套期保值",
        "期货和衍生品",
        "衍生工具",
        "hedging",
        "derivatives",
    ),
}
_SAFE_COMPONENT_RE = re.compile(r"[^0-9A-Za-z_.-]+")
logger = logging.getLogger(__name__)
DERIVED_ARTIFACT_DIRECTORIES = {
    "page_text": "derived",
    "tables": "tables",
    "ocr": "ocr",
}
PARSER_DIAGNOSTIC_STAGES = {
    "document": {
        "encrypted",
        "malformed",
        "unsupported",
    },
    "page_text": {
        "glyph_decoding",
        "native_text_extraction_failure",
        "ocr_required",
    },
    "table": {"table_parse_failure"},
    "template": {"unsupported_template"},
    "field": {"not_disclosed"},
}


@dataclass(frozen=True)
class BusinessProfileParserDiagnostic:
    """One typed parser outcome that remains distinct from disclosure absence."""

    stage: str
    outcome: str
    page_numbers: List[int] = field(default_factory=list)
    field_name: Optional[str] = None
    retryable: bool = False
    blocks_numeric_candidates: bool = True
    detail: Optional[str] = None

    def __post_init__(self) -> None:
        allowed = PARSER_DIAGNOSTIC_STAGES.get(self.stage)
        if allowed is None or self.outcome not in allowed:
            raise ValueError(
                f"unsupported parser diagnostic: stage={self.stage} "
                f"outcome={self.outcome}"
            )
        normalized_pages = sorted({int(page) for page in self.page_numbers})
        if any(page < 1 for page in normalized_pages):
            raise ValueError("diagnostic page numbers must be positive and one-based")
        object.__setattr__(self, "page_numbers", normalized_pages)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


def build_table_parse_failure_diagnostic(
    *,
    page_numbers: Iterable[int],
    detail: str,
    field_name: Optional[str] = None,
) -> BusinessProfileParserDiagnostic:
    """Record a detected table that could not be parsed by the table layer."""
    if not str(detail or "").strip():
        raise ValueError("table parse failure detail is required")
    normalized_pages = list(page_numbers)
    if not normalized_pages:
        raise ValueError("table parse failure requires evidence pages")
    return BusinessProfileParserDiagnostic(
        stage="table",
        outcome="table_parse_failure",
        page_numbers=normalized_pages,
        field_name=field_name,
        retryable=True,
        detail=str(detail).strip(),
    )


def build_unsupported_template_diagnostic(
    *,
    detail: str,
    page_numbers: Iterable[int] = (),
    field_name: Optional[str] = None,
) -> BusinessProfileParserDiagnostic:
    """Record a structurally valid disclosure not covered by parser templates."""
    if not str(detail or "").strip():
        raise ValueError("unsupported template detail is required")
    return BusinessProfileParserDiagnostic(
        stage="template",
        outcome="unsupported_template",
        page_numbers=list(page_numbers),
        field_name=field_name,
        detail=str(detail).strip(),
    )


def build_not_disclosed_diagnostic(
    *,
    field_name: str,
    section_parse_succeeded: bool,
    page_numbers: Iterable[int],
    detail: Optional[str] = None,
) -> BusinessProfileParserDiagnostic:
    """Record disclosure absence only after the expected section parsed cleanly."""
    if not str(field_name or "").strip():
        raise ValueError("field_name is required")
    if not section_parse_succeeded:
        raise ValueError(
            "not_disclosed requires a successfully parsed expected section"
        )
    normalized_pages = list(page_numbers)
    if not normalized_pages:
        raise ValueError("not_disclosed requires section evidence pages")
    return BusinessProfileParserDiagnostic(
        stage="field",
        outcome="not_disclosed",
        page_numbers=normalized_pages,
        field_name=str(field_name).strip(),
        detail=None if detail is None else str(detail).strip() or None,
    )


@dataclass(frozen=True)
class BusinessProfileHeadingMatch:
    """One deterministic heading alias match."""

    heading_type: str
    alias: str
    page_number: int
    line_number: int
    text: str


@dataclass(frozen=True)
class BusinessProfilePdfPageArtifact:
    """Native-text diagnostics for one PDF page."""

    page_number: int
    width_points: Optional[float]
    height_points: Optional[float]
    text: str
    text_hash: str
    text_character_count: int
    non_whitespace_character_count: int
    text_density_per_square_inch: Optional[float]
    native_text_status: str
    suspicious_glyph_count: int
    suspicious_glyph_ratio: float
    field_relevant: bool
    ocr_required: bool
    heading_matches: List[BusinessProfileHeadingMatch] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)
    page_artifact_hash: str = ""
    extraction_method: str = "native_text"
    ocr_confidence: Optional[float] = None
    extraction_provenance: List[Dict[str, Any]] = field(default_factory=list)
    pdf_page_label: Optional[str] = None
    printed_page_label: Optional[str] = None
    bookmark_title: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        payload = asdict(self)
        payload["heading_matches"] = [asdict(item) for item in self.heading_matches]
        return payload


@dataclass(frozen=True)
class BusinessProfilePdfArtifact:
    """Reproducible PDF extraction result and derived-artifact manifest."""

    schema_version: str
    extractor_version: str
    source_file_id: Optional[str]
    source_pdf_path: Optional[str]
    source_content_hash: str
    parameter_hash: str
    status: str
    encrypted: bool
    page_count: int
    pages: List[BusinessProfilePdfPageArtifact]
    heading_index: List[BusinessProfileHeadingMatch]
    low_text_pages: List[int]
    ocr_required_pages: List[int]
    parser_diagnostics: List[BusinessProfileParserDiagnostic]
    diagnostics: Dict[str, Any]
    artifact_hash: str
    recovery_state: str = "native_ready"

    def to_dict(self) -> Dict[str, Any]:
        payload = asdict(self)
        payload["pages"] = [item.to_dict() for item in self.pages]
        payload["heading_index"] = [asdict(item) for item in self.heading_index]
        payload["parser_diagnostics"] = [
            item.to_dict() for item in self.parser_diagnostics
        ]
        return payload

    @classmethod
    def from_dict(
        cls,
        value: Mapping[str, Any],
        *,
        source_file_id: Optional[str] = None,
        source_pdf_path: Optional[str] = None,
    ) -> "BusinessProfilePdfArtifact":
        """Hydrate a stored immutable artifact into its typed runtime form."""

        payload = dict(value)
        pages = []
        for raw_page in payload.get("pages") or []:
            page = dict(raw_page)
            page["heading_matches"] = [
                BusinessProfileHeadingMatch(**dict(item))
                for item in page.get("heading_matches") or []
            ]
            pages.append(BusinessProfilePdfPageArtifact(**page))
        payload["pages"] = pages
        payload["heading_index"] = [
            BusinessProfileHeadingMatch(**dict(item))
            for item in payload.get("heading_index") or []
        ]
        payload["parser_diagnostics"] = [
            BusinessProfileParserDiagnostic(**dict(item))
            for item in payload.get("parser_diagnostics") or []
        ]
        if source_file_id is not None:
            payload["source_file_id"] = source_file_id
        if source_pdf_path is not None:
            payload["source_pdf_path"] = source_pdf_path
        return cls(**payload)


@dataclass(frozen=True)
class BusinessProfilePdfArtifactWriteResult:
    """Immutable derived-artifact write outcome."""

    artifact_path: str
    artifact_hash: str
    status: str


class BusinessProfilePdfArtifactExtractor:
    """Validate a PDF and extract deterministic native page artifacts."""

    def __init__(
        self,
        *,
        extractor_version: str = BUSINESS_PROFILE_PDF_EXTRACTOR_VERSION,
        engine_profile: str | None = None,
        low_text_character_threshold: int = DEFAULT_LOW_TEXT_CHARACTER_THRESHOLD,
        glyph_decoding_ratio_threshold: float = (
            DEFAULT_GLYPH_DECODING_RATIO_THRESHOLD
        ),
        glyph_decoding_min_characters: int = DEFAULT_GLYPH_DECODING_MIN_CHARACTERS,
        heading_aliases: Optional[Mapping[str, Sequence[str]]] = None,
    ) -> None:
        self.extractor_version = str(extractor_version).strip()
        if not self.extractor_version:
            raise ValueError("extractor_version is required")
        if engine_profile is None:
            from research.document_processing.pdf import resolve_profile
            self.engine_profile = resolve_profile().name
        else:
            self.engine_profile = str(engine_profile).strip() or "pypdf_native"
        self.low_text_character_threshold = max(0, int(low_text_character_threshold))
        self.glyph_decoding_ratio_threshold = float(glyph_decoding_ratio_threshold)
        if not 0 <= self.glyph_decoding_ratio_threshold <= 1:
            raise ValueError("glyph_decoding_ratio_threshold must be between 0 and 1")
        self.glyph_decoding_min_characters = max(1, int(glyph_decoding_min_characters))
        aliases = heading_aliases or DEFAULT_HEADING_ALIASES
        self.heading_aliases = {
            str(heading_type): tuple(
                str(alias).strip() for alias in values if str(alias).strip()
            )
            for heading_type, values in aliases.items()
        }

    def extract_file(
        self,
        path: str | Path,
        *,
        source_file_id: Optional[str] = None,
        target_page_numbers: Iterable[int] = (),
    ) -> BusinessProfilePdfArtifact:
        """Read one archived PDF and extract its page artifacts."""
        source_path = Path(path)
        return self.extract_bytes(
            source_path.read_bytes(),
            source_file_id=source_file_id,
            source_pdf_path=str(source_path),
            target_page_numbers=target_page_numbers,
        )

    def extract_bytes(
        self,
        content: bytes,
        *,
        source_file_id: Optional[str] = None,
        source_pdf_path: Optional[str] = None,
        target_page_numbers: Iterable[int] = (),
        ocr_mode: str = "none",
        recovery_policy: str = "native_first",
        cache_backend: Any | None = None,
        mode_budget: Any | None = None,
    ) -> BusinessProfilePdfArtifact:
        """Extract an artifact without writing it to disk."""
        content_bytes = bytes(content or b"")
        content_hash = hashlib.sha256(content_bytes).hexdigest()
        target_pages = self._normalize_target_pages(target_page_numbers)
        parameter_hash = self._parameter_hash(
            target_pages, ocr_mode=ocr_mode, recovery_policy=recovery_policy
        )
        if not content_bytes.lstrip().startswith(b"%PDF-"):
            return self._failure_artifact(
                source_file_id=source_file_id,
                source_pdf_path=source_pdf_path,
                source_content_hash=content_hash,
                parameter_hash=parameter_hash,
                failure_class="invalid_pdf_signature",
            )
        from research.document_processing.pdf import DEFAULT_PROFILES, PdfParseRequest, build_router

        profile = DEFAULT_PROFILES.get(self.engine_profile)
        if profile is None:
            return self._failure_artifact(
                source_file_id=source_file_id,
                source_pdf_path=source_pdf_path,
                source_content_hash=content_hash,
                parameter_hash=parameter_hash,
                failure_class="unsupported_engine_profile",
            )
        result = build_router(profile).parse(
            PdfParseRequest(
                content=content_bytes,
                profile=profile,
                target_pages=tuple(sorted(target_pages)),
                ocr_mode=ocr_mode,
                recovery_policy=recovery_policy,
                cache_backend=cache_backend,
                mode_budget=mode_budget,
            )
        )
        if result.status == "failed":
            code = result.diagnostics[0].code if result.diagnostics else "malformed_pdf"
            failure_class = {
                "native_runtime_unavailable": "pypdf_unavailable",
                "encrypted_password_required": "encrypted_password_required",
                "empty_pdf": "empty_pdf",
                "malformed_page_tree": "malformed_page_tree",
                "invalid_pdf_signature": "invalid_pdf_signature",
            }.get(code, "malformed_pdf")
            return self._failure_artifact(
                source_file_id=source_file_id,
                source_pdf_path=source_pdf_path,
                source_content_hash=content_hash,
                parameter_hash=parameter_hash,
                failure_class=failure_class,
                encrypted=code == "encrypted_password_required",
                error=RuntimeError(result.diagnostics[0].message if result.diagnostics else code),
            )

        encrypted = any(item.code == "encrypted_password_required" for item in result.diagnostics)
        page_count = result.page_count
        if page_count < 1:
            return self._failure_artifact(
                source_file_id=source_file_id,
                source_pdf_path=source_pdf_path,
                source_content_hash=content_hash,
                parameter_hash=parameter_hash,
                failure_class="empty_pdf",
                encrypted=encrypted,
            )

        pages: List[BusinessProfilePdfPageArtifact] = []
        heading_index: List[BusinessProfileHeadingMatch] = []
        parser_diagnostics: List[BusinessProfileParserDiagnostic] = []
        extraction_error_pages: List[int] = []
        glyph_decoding_pages: List[int] = []
        for shared_page in result.pages:
            page_number = shared_page.page_number
            page_errors: List[str] = []
            text = shared_page.text or ""
            native_candidate_text = next(
                (
                    candidate.text
                    for candidate in shared_page.candidates
                    if candidate.method == "native_text"
                ),
                "",
            )
            diagnostic_text = native_candidate_text or text
            native_text_status = (
                "ocr" if shared_page.extraction_method == "ocr"
                else "extracted" if diagnostic_text.strip() else "empty"
            )
            if shared_page.quality_status == "native_text_mapping_error":
                native_text_status = "glyph_decoding_error"
                glyph_decoding_pages.append(page_number)
                page_errors.extend(item.message or item.code for item in shared_page.diagnostics if item.code == "native_text_mapping_error")
            elif shared_page.quality_status == "ocr_failure":
                native_text_status = "extraction_error"
                extraction_error_pages.append(page_number)
                page_errors.extend(item.message or item.code for item in shared_page.diagnostics)
            width, height = shared_page.width_points, shared_page.height_points
            non_whitespace = len(re.sub(r"\s+", "", diagnostic_text))
            suspicious_glyphs = self._suspicious_glyph_count(diagnostic_text)
            diagnostic_control_count = max(
                (
                    int(item.details.get("controls", 0)) + int(item.details.get("replacement", 0))
                    for item in shared_page.diagnostics
                    if isinstance(item.details, Mapping)
                ),
                default=0,
            )
            suspicious_glyphs = max(suspicious_glyphs, diagnostic_control_count)
            suspicious_glyph_ratio = (
                suspicious_glyphs / non_whitespace if non_whitespace else 0.0
            )
            if (
                native_text_status == "extracted"
                and suspicious_glyphs >= self.glyph_decoding_min_characters
                and suspicious_glyph_ratio >= self.glyph_decoding_ratio_threshold
            ):
                native_text_status = "glyph_decoding_error"
                glyph_decoding_pages.append(page_number)
                page_errors.append(
                    "suspicious_glyphs:" f"{suspicious_glyphs}/{non_whitespace}"
                )
            matches = self._heading_matches(text, page_number)
            heading_index.extend(matches)
            low_text = non_whitespace < self.low_text_character_threshold
            field_relevant = bool(matches) or page_number in target_pages
            # A glyph-decoding failure is unsafe regardless of whether the
            # heading matcher could recognize the page.  Requiring a heading
            # here would leave garbled table-of-contents pages out of OCR and
            # prevent section discovery entirely.
            ocr_required = (
                native_text_status in {"extraction_error", "glyph_decoding_error"}
                or field_relevant and low_text
            )
            page_payload = {
                "page_number": page_number,
                "width_points": width,
                "height_points": height,
                "text_hash": self._hash_text(text),
                "text_character_count": len(text),
                "non_whitespace_character_count": non_whitespace,
                "text_density_per_square_inch": self._text_density(
                    non_whitespace,
                    width,
                    height,
                ),
                "native_text_status": native_text_status,
                "suspicious_glyph_count": suspicious_glyphs,
                "suspicious_glyph_ratio": round(suspicious_glyph_ratio, 6),
                "field_relevant": field_relevant,
                "ocr_required": ocr_required,
                "heading_matches": [asdict(item) for item in matches],
                "errors": page_errors,
                "extraction_method": shared_page.extraction_method,
                "ocr_confidence": shared_page.confidence,
                "extraction_provenance": [dict(item) for item in shared_page.provenance],
                "pdf_page_label": shared_page.pdf_page_label,
                "printed_page_label": shared_page.printed_page_label,
                "bookmark_title": shared_page.bookmark_title,
            }
            pages.append(
                BusinessProfilePdfPageArtifact(
                    text=text,
                    page_artifact_hash=self._stable_hash(page_payload),
                    **{
                        key: value
                        for key, value in page_payload.items()
                        if key != "heading_matches"
                    },
                    heading_matches=matches,
                )
            )

        low_text_pages = [
            item.page_number
            for item in pages
            if item.non_whitespace_character_count < self.low_text_character_threshold
        ]
        ocr_required_pages = [item.page_number for item in pages if item.ocr_required]
        if extraction_error_pages:
            parser_diagnostics.append(
                BusinessProfileParserDiagnostic(
                    stage="page_text",
                    outcome="native_text_extraction_failure",
                    page_numbers=extraction_error_pages,
                    retryable=True,
                )
            )
        if glyph_decoding_pages:
            parser_diagnostics.append(
                BusinessProfileParserDiagnostic(
                    stage="page_text",
                    outcome="glyph_decoding",
                    page_numbers=glyph_decoding_pages,
                    retryable=True,
                )
            )
        if ocr_required_pages:
            parser_diagnostics.append(
                BusinessProfileParserDiagnostic(
                    stage="page_text",
                    outcome="ocr_required",
                    page_numbers=ocr_required_pages,
                    retryable=True,
                )
            )
        status = (
            "partial"
            if extraction_error_pages
            else "ocr_required" if ocr_required_pages else "parsed"
        )
        diagnostics = {
            "failure_class": None,
            "low_text_character_threshold": self.low_text_character_threshold,
            "glyph_decoding_ratio_threshold": self.glyph_decoding_ratio_threshold,
            "glyph_decoding_min_characters": self.glyph_decoding_min_characters,
            "target_page_numbers": sorted(target_pages),
            "native_text_page_count": sum(
                item.native_text_status == "extracted" for item in pages
            ),
            "empty_text_page_count": sum(
                item.native_text_status == "empty" for item in pages
            ),
            "extraction_error_pages": extraction_error_pages,
            "glyph_decoding_pages": glyph_decoding_pages,
            "heading_match_count": len(heading_index),
            "engine_profile": self.engine_profile,
            "extraction_methods": sorted({item.extraction_method for item in pages}),
            "ocr_page_count": sum(item.extraction_method == "ocr" for item in pages),
            "ocr_mode": ocr_mode,
            "recovery_policy": recovery_policy,
        }
        recovery_state = (
            "partial_ocr"
            if any(item.extraction_method == "ocr" for item in pages)
            and any(item.ocr_required for item in pages)
            else "native_ready"
            if not ocr_required_pages
            else "section_ocr_required"
        )
        payload = self._artifact_payload(
            source_file_id=source_file_id,
            source_pdf_path=source_pdf_path,
            source_content_hash=content_hash,
            parameter_hash=parameter_hash,
            status=status,
            encrypted=encrypted,
            page_count=page_count,
            pages=pages,
            heading_index=heading_index,
            low_text_pages=low_text_pages,
            ocr_required_pages=ocr_required_pages,
            parser_diagnostics=parser_diagnostics,
            diagnostics=diagnostics,
            recovery_state=recovery_state,
        )
        return BusinessProfilePdfArtifact(
            **payload,
            artifact_hash=self._artifact_hash(payload),
        )

    def _failure_artifact(
        self,
        *,
        source_file_id: Optional[str],
        source_pdf_path: Optional[str],
        source_content_hash: str,
        parameter_hash: str,
        failure_class: str,
        error: Optional[Exception] = None,
        encrypted: bool = False,
    ) -> BusinessProfilePdfArtifact:
        diagnostics = {
            "failure_class": failure_class,
            "error": None if error is None else f"{type(error).__name__}: {error}",
            "low_text_character_threshold": self.low_text_character_threshold,
            "glyph_decoding_ratio_threshold": self.glyph_decoding_ratio_threshold,
            "glyph_decoding_min_characters": self.glyph_decoding_min_characters,
        }
        parser_diagnostic = self._document_failure_diagnostic(
            failure_class,
            detail=diagnostics["error"],
        )
        payload = self._artifact_payload(
            source_file_id=source_file_id,
            source_pdf_path=source_pdf_path,
            source_content_hash=source_content_hash,
            parameter_hash=parameter_hash,
            status="parse_failed",
            encrypted=encrypted,
            page_count=0,
            pages=[],
            heading_index=[],
            low_text_pages=[],
            ocr_required_pages=[],
            parser_diagnostics=[parser_diagnostic],
            diagnostics=diagnostics,
            recovery_state="source_unrecoverable",
        )
        return BusinessProfilePdfArtifact(
            **payload,
            artifact_hash=self._artifact_hash(payload),
        )

    def _artifact_payload(self, **kwargs: Any) -> Dict[str, Any]:
        return {
            "schema_version": BUSINESS_PROFILE_PDF_ARTIFACT_SCHEMA_VERSION,
            "extractor_version": self.extractor_version,
            **kwargs,
        }

    @staticmethod
    def _serializable_payload(payload: Mapping[str, Any]) -> Dict[str, Any]:
        output = dict(payload)
        output["pages"] = [item.to_dict() for item in payload.get("pages") or []]
        output["heading_index"] = [
            asdict(item) for item in payload.get("heading_index") or []
        ]
        output["parser_diagnostics"] = [
            item.to_dict() for item in payload.get("parser_diagnostics") or []
        ]
        return output

    def _artifact_hash(self, payload: Mapping[str, Any]) -> str:
        return _artifact_hash(payload)

    def _parameter_hash(
        self,
        target_pages: set[int],
        *,
        ocr_mode: str = "none",
        recovery_policy: str = "native_first",
    ) -> str:
        return self._stable_hash(
            {
                "extractor_version": self.extractor_version,
                "low_text_character_threshold": self.low_text_character_threshold,
                "glyph_decoding_ratio_threshold": self.glyph_decoding_ratio_threshold,
                "glyph_decoding_min_characters": self.glyph_decoding_min_characters,
                "heading_aliases": {
                    key: list(self.heading_aliases[key])
                    for key in sorted(self.heading_aliases)
                },
                "engine_profile": self.engine_profile,
                "target_page_numbers": sorted(target_pages),
                "ocr_mode": ocr_mode,
                "recovery_policy": recovery_policy,
            }
        )

    @staticmethod
    def _normalize_target_pages(values: Iterable[int]) -> set[int]:
        pages: set[int] = set()
        for value in values:
            try:
                page = int(value)
            except (TypeError, ValueError) as exc:
                raise ValueError("target page numbers must be integers") from exc
            if page < 1:
                raise ValueError("target page numbers must be positive and one-based")
            pages.add(page)
        return pages

    def _heading_matches(
        self,
        text: str,
        page_number: int,
    ) -> List[BusinessProfileHeadingMatch]:
        matches: List[BusinessProfileHeadingMatch] = []
        for line_number, line in enumerate(text.splitlines(), start=1):
            normalized = self._normalize_text(line)
            if not normalized:
                continue
            for heading_type, aliases in self.heading_aliases.items():
                for alias in aliases:
                    if self._normalize_text(alias) in normalized:
                        matches.append(
                            BusinessProfileHeadingMatch(
                                heading_type=heading_type,
                                alias=alias,
                                page_number=page_number,
                                line_number=line_number,
                                text=line.strip(),
                            )
                        )
                        break
        return matches

    @staticmethod
    def _normalize_text(value: str) -> str:
        return re.sub(r"\s+", "", str(value or "")).lower()

    @staticmethod
    def _hash_text(value: str) -> str:
        return hashlib.sha256(str(value).encode("utf-8")).hexdigest()

    @staticmethod
    def _suspicious_glyph_count(value: str) -> int:
        text = str(value or "")
        suspicious = 0
        for character in text:
            if character.isspace():
                continue
            category = unicodedata.category(character)
            if character == "\ufffd" or category in {"Cc", "Co", "Cs"}:
                suspicious += 1
        # Broken ToUnicode maps often produce letters from unrelated scripts
        # (e.g. Kannada, Georgian, or Ethiopic) rather than replacement
        # characters.  Chinese annual reports normally contain CJK text; a
        # page with several non-ASCII alphabetic glyphs and no CJK glyphs is a
        # strong, parser-local signal of mojibake.  Keep ASCII/English pages
        # valid and avoid treating numeric tables as encoding failures.
        cjk_count = sum(
            0x3400 <= ord(character) <= 0x9FFF for character in text
        )
        non_ascii_letters = sum(
            character.isalpha() and ord(character) > 127 and not (
                0x3400 <= ord(character) <= 0x9FFF
            )
            for character in text
        )
        if cjk_count == 0 and non_ascii_letters >= 3:
            suspicious += non_ascii_letters
        return suspicious

    @staticmethod
    def _document_failure_diagnostic(
        failure_class: str,
        *,
        detail: Optional[str],
    ) -> BusinessProfileParserDiagnostic:
        if failure_class == "encrypted_password_required":
            outcome = "encrypted"
        elif failure_class in {"invalid_pdf_signature", "pypdf_unavailable"}:
            outcome = "unsupported"
        else:
            outcome = "malformed"
        return BusinessProfileParserDiagnostic(
            stage="document",
            outcome=outcome,
            retryable=failure_class == "pypdf_unavailable",
            detail=failure_class if not detail else f"{failure_class}: {detail}",
        )

    @staticmethod
    def _stable_hash(value: Any) -> str:
        encoded = json.dumps(
            value,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
        return hashlib.sha256(encoded).hexdigest()

    @staticmethod
    def _page_dimensions(page: Any) -> tuple[Optional[float], Optional[float]]:
        try:
            return float(page.mediabox.width), float(page.mediabox.height)
        except (AttributeError, TypeError, ValueError):
            return None, None

    @staticmethod
    def _text_density(
        character_count: int,
        width_points: Optional[float],
        height_points: Optional[float],
    ) -> Optional[float]:
        if not width_points or not height_points:
            return None
        square_inches = (width_points * height_points) / (72.0 * 72.0)
        if square_inches <= 0:
            return None
        return round(character_count / square_inches, 6)


class BusinessProfilePdfArtifactStore:
    """Write compressed, immutable page artifacts beside the archived original."""

    def page_cache(self) -> "BusinessProfilePdfPageCache":
        """Return the content-addressed page cache used by the shared router."""
        return BusinessProfilePdfPageCache(Path("data/derived/business_profile/page_cache"))

    def artifact_path(
        self,
        source_pdf_path: str | Path,
        *,
        source_content_hash: str,
        extractor_version: str,
        parameter_hash: Optional[str] = None,
        artifact_kind: str = "page_text",
    ) -> Path:
        source_path = Path(source_pdf_path)
        document_root = (
            source_path.parent.parent
            if source_path.parent.name == "original"
            else source_path.parent
        )
        safe_version = _SAFE_COMPONENT_RE.sub("_", extractor_version).strip("._")
        if not safe_version:
            raise ValueError("extractor_version is invalid for artifact path")
        directory = DERIVED_ARTIFACT_DIRECTORIES.get(str(artifact_kind))
        if directory is None:
            raise ValueError(f"unsupported derived artifact kind: {artifact_kind}")
        parameter_suffix = f"_{parameter_hash[:16]}" if parameter_hash else ""
        return (
            document_root
            / directory
            / safe_version
            / f"{source_content_hash}{parameter_suffix}.json.gz"
        )

    def write(
        self,
        artifact: BusinessProfilePdfArtifact,
        *,
        source_pdf_path: Optional[str | Path] = None,
    ) -> BusinessProfilePdfArtifactWriteResult:
        path_value = source_pdf_path or artifact.source_pdf_path
        if not path_value:
            raise ValueError("source_pdf_path is required")
        path = self.artifact_path(
            path_value,
            source_content_hash=artifact.source_content_hash,
            extractor_version=artifact.extractor_version,
            parameter_hash=artifact.parameter_hash,
            artifact_kind="page_text",
        )
        stored_payload = artifact.to_dict()
        stored_payload["source_file_id"] = None
        stored_payload["source_pdf_path"] = None
        raw = json.dumps(
            stored_payload,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
        compressed = gzip.compress(raw, compresslevel=9, mtime=0)
        if path.exists():
            existing = self.read(path)
            if existing.get("artifact_hash") != artifact.artifact_hash:
                raise RuntimeError(f"immutable derived artifact hash mismatch: {path}")
            return BusinessProfilePdfArtifactWriteResult(
                artifact_path=str(path),
                artifact_hash=artifact.artifact_hash,
                status="unchanged",
            )
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = path.with_name(
            f".{path.name}.{os.getpid()}.{threading.get_ident()}."
            f"{time.monotonic_ns()}.part"
        )
        temporary.write_bytes(compressed)
        try:
            stored = self.read(temporary)
            if stored.get("artifact_hash") != artifact.artifact_hash:
                raise RuntimeError("derived artifact write verification failed")
            try:
                os.link(temporary, path)
                status = "written"
            except FileExistsError:
                existing = self.read(path)
                if existing.get("artifact_hash") != artifact.artifact_hash:
                    raise RuntimeError(
                        f"immutable derived artifact hash mismatch: {path}"
                    )
                status = "unchanged"
        finally:
            temporary.unlink(missing_ok=True)
        return BusinessProfilePdfArtifactWriteResult(
            artifact_path=str(path),
            artifact_hash=artifact.artifact_hash,
            status=status,
        )

    @staticmethod
    def read(path: str | Path) -> Dict[str, Any]:
        return json.loads(gzip.decompress(Path(path).read_bytes()).decode("utf-8"))

    def read_artifact(
        self,
        path: str | Path,
        *,
        source_file_id: Optional[str] = None,
        source_pdf_path: Optional[str] = None,
        expected_content_hash: Optional[str] = None,
        expected_extractor_version: Optional[str] = None,
        expected_parameter_hash: Optional[str] = None,
    ) -> BusinessProfilePdfArtifact:
        """Read and fully validate one immutable page artifact."""

        payload = self.read(path)
        expected = {
            "schema_version": BUSINESS_PROFILE_PDF_ARTIFACT_SCHEMA_VERSION,
            "source_content_hash": expected_content_hash,
            "extractor_version": expected_extractor_version,
            "parameter_hash": expected_parameter_hash,
        }
        for field_name, expected_value in expected.items():
            if expected_value is not None and payload.get(field_name) != expected_value:
                raise RuntimeError(
                    "immutable derived artifact identity mismatch: "
                    f"field={field_name} path={path}"
                )
        stored_hash = str(payload.get("artifact_hash") or "")
        hashable = dict(payload)
        hashable.pop("artifact_hash", None)
        hashable.pop("source_file_id", None)
        hashable.pop("source_pdf_path", None)
        calculated_hash = hashlib.sha256(
            json.dumps(
                hashable,
                ensure_ascii=False,
                sort_keys=True,
                separators=(",", ":"),
            ).encode("utf-8")
        ).hexdigest()
        if not stored_hash or stored_hash != calculated_hash:
            raise RuntimeError(f"immutable derived artifact hash mismatch: {path}")
        return BusinessProfilePdfArtifact.from_dict(
            payload,
            source_file_id=source_file_id,
            source_pdf_path=source_pdf_path,
        )


class _PypdfWarningFilter(logging.Filter):
    """Aggregate handled pypdf warnings in the parsing thread."""

    local = threading.local()

    def filter(self, record: logging.LogRecord) -> bool:
        collector = getattr(self.local, "collector", None)
        if (
            collector is None
            or record.levelno < logging.WARNING
            or not record.name.startswith("pypdf")
        ):
            return True
        if not getattr(record, "_business_profile_warning_counted", False):
            record._business_profile_warning_counted = True
            collector["count"] += 1
            if len(collector["samples"]) < 3:
                collector["samples"].append(record.getMessage()[:240])
        return False


_PYPDF_WARNING_FILTER = _PypdfWarningFilter()
_PYPDF_FILTER_LOCK = threading.Lock()


def _artifact_hash(payload: Mapping[str, Any]) -> str:
    """Calculate the immutable artifact hash without source-path identity."""
    hashable = dict(payload)
    hashable["pages"] = [
        item.to_dict() if hasattr(item, "to_dict") else dict(item)
        for item in hashable.get("pages") or []
    ]
    hashable["heading_index"] = [
        asdict(item) if hasattr(item, "__dataclass_fields__") else dict(item)
        for item in hashable.get("heading_index") or []
    ]
    hashable["parser_diagnostics"] = [
        item.to_dict() if hasattr(item, "to_dict") else dict(item)
        for item in hashable.get("parser_diagnostics") or []
    ]
    hashable.pop("artifact_hash", None)
    hashable.pop("source_pdf_path", None)
    hashable.pop("source_file_id", None)
    return hashlib.sha256(
        json.dumps(
            hashable,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
    ).hexdigest()


class BusinessProfilePdfPageCache:
    """Small file-backed adapter for the shared PDF page-cache protocol."""

    def __init__(self, root: str | Path):
        self.root = Path(root)

    @staticmethod
    def _key(identity: Mapping[str, Any]) -> str:
        return hashlib.sha256(
            json.dumps(dict(identity), ensure_ascii=False, sort_keys=True, separators=(",", ":"))
            .encode("utf-8")
        ).hexdigest()

    def get(self, identity: Mapping[str, Any]) -> Optional[Mapping[str, Any]]:
        path = self.root / f"{self._key(identity)}.json.gz"
        if not path.is_file():
            return None
        try:
            return json.loads(gzip.decompress(path.read_bytes()).decode("utf-8"))
        except (OSError, ValueError, gzip.BadGzipFile, json.JSONDecodeError):
            logger.warning("business-profile page cache entry unreadable path=%s", path)
            return None

    def put(self, identity: Mapping[str, Any], page: Any) -> None:
        payload = asdict(page) if hasattr(page, "__dataclass_fields__") else dict(page)
        path = self.root / f"{self._key(identity)}.json.gz"
        path.parent.mkdir(parents=True, exist_ok=True)
        raw = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
        temporary = path.with_name(f".{path.name}.{os.getpid()}.{time.monotonic_ns()}.part")
        temporary.write_bytes(gzip.compress(raw, compresslevel=6, mtime=0))
        try:
            os.replace(temporary, path)
        finally:
            temporary.unlink(missing_ok=True)


def merge_business_profile_pdf_artifacts(
    base: BusinessProfilePdfArtifact,
    recovered: BusinessProfilePdfArtifact,
) -> BusinessProfilePdfArtifact:
    """Merge targeted recovery pages into a full native artifact."""
    pages_by_number = {page.page_number: page for page in base.pages}
    replaced: list[int] = []
    for page in recovered.pages:
        current = pages_by_number.get(page.page_number)
        recovered_usable = bool(page.text.strip()) and page.extraction_method in {
            "native_text", "alternate_native", "ocr"
        } and page.native_text_status not in {"glyph_decoding_error", "extraction_error", "empty"}
        current_usable = bool(current and current.text.strip()) and current.native_text_status in {
            "extracted", "ocr"
        }
        if current is None or (recovered_usable and not current_usable):
            pages_by_number[page.page_number] = page
            replaced.append(page.page_number)
    pages = [pages_by_number[number] for number in sorted(pages_by_number)]
    headings = [match for page in pages for match in page.heading_matches]
    ocr_required = [page.page_number for page in pages if page.ocr_required]
    low_text = [page.page_number for page in pages if page.non_whitespace_character_count < DEFAULT_LOW_TEXT_CHARACTER_THRESHOLD]
    diagnostics = dict(base.diagnostics)
    diagnostics.update(
        {
            "recovered_page_numbers": sorted(set(replaced)),
            "extraction_methods": sorted({page.extraction_method for page in pages}),
            "ocr_page_count": sum(page.extraction_method == "ocr" for page in pages),
        }
    )
    parser_diagnostics = list(base.parser_diagnostics)
    for item in recovered.parser_diagnostics:
        if item.to_dict() not in [existing.to_dict() for existing in parser_diagnostics]:
            parser_diagnostics.append(item)
    payload = {
        "schema_version": base.schema_version,
        "extractor_version": recovered.extractor_version,
        "source_file_id": base.source_file_id,
        "source_pdf_path": base.source_pdf_path,
        "source_content_hash": base.source_content_hash,
        "parameter_hash": recovered.parameter_hash,
        "status": "partial" if any(page.ocr_required for page in pages) else "parsed",
        "encrypted": base.encrypted or recovered.encrypted,
        "page_count": base.page_count,
        "pages": pages,
        "heading_index": headings,
        "low_text_pages": low_text,
        "ocr_required_pages": ocr_required,
        "parser_diagnostics": parser_diagnostics,
        "diagnostics": diagnostics,
        "recovery_state": recovered.recovery_state,
    }
    payload["artifact_hash"] = _artifact_hash(
        {
            **payload,
            "pages": [page.to_dict() for page in pages],
            "heading_index": [asdict(item) for item in headings],
            "parser_diagnostics": [item.to_dict() for item in parser_diagnostics],
        }
    )
    return BusinessProfilePdfArtifact(**payload)


@contextmanager
def _aggregate_pypdf_warnings():
    collector: Dict[str, Any] = {"count": 0, "samples": []}
    with _PYPDF_FILTER_LOCK:
        for handler in logging.getLogger().handlers:
            if _PYPDF_WARNING_FILTER not in handler.filters:
                handler.addFilter(_PYPDF_WARNING_FILTER)
    previous = getattr(_PYPDF_WARNING_FILTER.local, "collector", None)
    _PYPDF_WARNING_FILTER.local.collector = collector
    try:
        yield collector
    finally:
        _PYPDF_WARNING_FILTER.local.collector = previous


def ensure_archived_pdf_page_artifact(
    manifest: Mapping[str, Any],
    *,
    extractor: Optional[BusinessProfilePdfArtifactExtractor] = None,
    store: Optional[BusinessProfilePdfArtifactStore] = None,
    target_page_numbers: Iterable[int] = (),
    ocr_mode: str = "none",
    recovery_policy: str = "native_first",
    mode_budget: Any | None = None,
    cache_backend: Any | None = None,
    retry_failed_artifact: bool = False,
) -> Dict[str, Any]:
    """Create or reuse native page artifacts for one verified archived PDF."""

    archive_path = Path(str(manifest.get("archive_path") or ""))
    expected_hash = str(manifest.get("content_hash") or "").strip()
    if not archive_path.is_file():
        raise FileNotFoundError(archive_path)
    if not re.fullmatch(r"[0-9a-f]{64}", expected_hash):
        raise ValueError("manifest content_hash must be a sha256 hex digest")
    started = time.monotonic()
    content = archive_path.read_bytes()
    hash_completed = time.monotonic()
    actual_hash = hashlib.sha256(content).hexdigest()
    if actual_hash != expected_hash:
        raise RuntimeError(f"archived PDF hash mismatch: {archive_path}")
    active_extractor = extractor or BusinessProfilePdfArtifactExtractor()
    active_store = store or BusinessProfilePdfArtifactStore()
    source_file_id = str(manifest.get("source_file_id") or "") or None
    target_pages = active_extractor._normalize_target_pages(target_page_numbers)
    parameter_hash = active_extractor._parameter_hash(
        target_pages, ocr_mode=ocr_mode, recovery_policy=recovery_policy
    )
    artifact_path = active_store.artifact_path(
        archive_path,
        source_content_hash=expected_hash,
        extractor_version=active_extractor.extractor_version,
        parameter_hash=parameter_hash,
    )
    if artifact_path.is_file():
        artifact = active_store.read_artifact(
            artifact_path,
            source_file_id=source_file_id,
            source_pdf_path=str(archive_path),
            expected_content_hash=expected_hash,
            expected_extractor_version=active_extractor.extractor_version,
            expected_parameter_hash=parameter_hash,
        )
        if artifact.status == "parse_failed" and retry_failed_artifact:
            retained = artifact_path.with_name(
                f"{artifact_path.name}.parse_failed.{int(time.time())}"
            )
            artifact_path.replace(retained)
            logger.info(
                "business-profile pdf parse_failed artifact retained for retry "
                "source_file_id=%s retained=%s",
                source_file_id,
                retained,
            )
        else:
            completed = time.monotonic()
            timings = {
                "hash_read_seconds": round(hash_completed - started, 6),
                "cache_read_seconds": round(completed - hash_completed, 6),
                "extract_seconds": 0.0,
                "write_seconds": 0.0,
                "total_seconds": round(completed - started, 6),
            }
            logger.info(
                "business-profile pdf artifact cache hit source_file_id=%s "
                "bytes=%s pages=%s timings=%s path=%s",
                source_file_id,
                len(content),
                artifact.page_count,
                timings,
                artifact_path,
            )
            return {
                "artifact": artifact,
                "artifact_path": str(artifact_path),
                "artifact_hash": artifact.artifact_hash,
                "status": "unchanged",
                "cache_status": "hit",
                "timings": timings,
                "pypdf_warning_count": 0,
            }
    extract_started = time.monotonic()
    with _aggregate_pypdf_warnings() as warning_summary:
        artifact = active_extractor.extract_bytes(
            content,
            source_file_id=source_file_id,
            source_pdf_path=str(archive_path),
            target_page_numbers=target_pages,
            ocr_mode=ocr_mode,
            recovery_policy=recovery_policy,
            mode_budget=mode_budget,
            cache_backend=cache_backend,
        )
    extract_completed = time.monotonic()
    write_result = active_store.write(artifact)
    completed = time.monotonic()
    timings = {
        "hash_read_seconds": round(hash_completed - started, 6),
        "cache_read_seconds": 0.0,
        "extract_seconds": round(extract_completed - extract_started, 6),
        "write_seconds": round(completed - extract_completed, 6),
        "total_seconds": round(completed - started, 6),
    }
    if warning_summary["count"]:
        logger.warning(
            "business-profile pdf parser warnings aggregated source_file_id=%s "
            "count=%s samples=%s path=%s",
            source_file_id,
            warning_summary["count"],
            warning_summary["samples"],
            archive_path,
        )
    logger.info(
        "business-profile pdf artifact extracted source_file_id=%s bytes=%s "
        "pages=%s status=%s parser_warnings=%s timings=%s path=%s",
        source_file_id,
        len(content),
        artifact.page_count,
        artifact.status,
        warning_summary["count"],
        timings,
        write_result.artifact_path,
    )
    return {
        "artifact": artifact,
        "artifact_path": write_result.artifact_path,
        "artifact_hash": write_result.artifact_hash,
        "status": write_result.status,
        "cache_status": "miss",
        "timings": timings,
        "pypdf_warning_count": warning_summary["count"],
    }
